
package Server;

import dao.userDAO;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.User;

/**
 *
 * @author Tong Thuan
 */
public class processQuanLyTaiKhoan extends Thread {

	private Socket socket;

	public processQuanLyTaiKhoan(Socket socket) {
		this.socket = socket;
	}

	@Override
	public void run() {
		boolean isRun = true;
		while (isRun == true) {
			try {
				userDAO usdao = new userDAO();
				BufferedReader reader = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
				String messageFromClient = null;
				messageFromClient = reader.readLine();
				ObjectOutputStream ooutput = new ObjectOutputStream(this.socket.getOutputStream());
				if (messageFromClient.equals("DANGXUAT")) {
					isRun = false;
					this.socket.close();
					return;
				} else if (messageFromClient.equals("SEARCHALL")) {
					List<User> list = new ArrayList<User>();
					list = usdao.SelectAll();

					ooutput.writeObject(list);
					ooutput.flush();

				} else if (messageFromClient.equals("SEARCHBYID")) {

					String myID = reader.readLine();

					List<User> list = new ArrayList<User>();
					User us = usdao.selectByID(myID);
					if (us != null) {
						list.add(us);
					}

					ooutput.writeObject(list);
					ooutput.flush();

				} else if (messageFromClient.equals("EDIT")) {
					ObjectInputStream Oinput = new ObjectInputStream(this.socket.getInputStream());
					User us = (User) Oinput.readObject();

					if (usdao.UpdateByID(us.getEmail(), us.getPassWord()) != 0) {

						sendState send = new sendState(socket, "EDITSUCCESS");
						send.start();
					}

				} else if (messageFromClient.equals("DELETE")) {

					ObjectInputStream Oinput = new ObjectInputStream(this.socket.getInputStream());
					User us = (User) Oinput.readObject();

					if (usdao.DeleteByID(us.getEmail()) == true) {
						sendState send = new sendState(socket, "DELETESUCCESS");
						send.start();
					}

				}
			} catch (Exception e) {

				try {
					isRun = false;
					this.socket.close();
				} catch (IOException ex) {
					Logger.getLogger(processQuanLyTaiKhoan.class.getName()).log(Level.SEVERE, null, ex);
				}
			}
		}
	}

}
