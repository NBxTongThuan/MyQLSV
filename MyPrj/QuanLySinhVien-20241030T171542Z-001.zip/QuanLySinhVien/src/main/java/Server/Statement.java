/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Server;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Tong Thuan
 */
public class Statement {

    public static List<String> list = new ArrayList<String>();

    public static void online(String userName) {
        if (list.contains(userName) == false) {
            list.add(userName);
        }
    }

    public static void offline(String userName) {
        if (list.contains(userName) == true) {
            list.remove(userName);
        }
    }
}
