
package Server;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;

/**
 *
 * @author Tong Thuan
 */
public class sendState extends Thread {

	private Socket socket;
	private String message;

	public sendState(Socket socket, String message) {
		this.socket = socket;
		this.message = message;
	}

	@Override
	public void run() {

		try {
			PrintWriter writer = new PrintWriter(this.socket.getOutputStream());
			writer.println(this.message);
			writer.flush();
		} catch (Exception e) {
			try {
				this.socket.close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

		}

	}

}
