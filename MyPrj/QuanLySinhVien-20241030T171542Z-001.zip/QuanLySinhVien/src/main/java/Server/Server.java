package Server;

import java.net.ServerSocket;
import java.net.Socket;

public class Server {

    public static void main(String[] args) {

        try {

            ServerSocket serverSocket = new ServerSocket(1829);
            System.out.println("Dang mo ket noi");

            while (true) {
                Socket clientSocket = serverSocket.accept();
                process_ pr = new process_(clientSocket);
                pr.start();
                Thread.sleep(100);
            }
        } catch (Exception e) {

        }

    }

}
