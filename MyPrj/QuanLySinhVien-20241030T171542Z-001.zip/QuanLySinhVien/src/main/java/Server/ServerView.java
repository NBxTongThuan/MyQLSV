package Server;

import java.awt.EventQueue;
import java.net.ServerSocket;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import java.awt.BorderLayout;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JTable;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.table.DefaultTableModel;

import model.MySocket;

import java.awt.Color;
import javax.swing.JButton;

public class ServerView extends Thread implements ActionListener {

	private JFrame frame;
	private List<MySocket> list;
	private JTable table;
	private DefaultTableModel tbmodel;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		new ServerView();
	}

	/**
	 * Create the application.
	 */
	public ServerView() {

		this.tbmodel = new DefaultTableModel();

		initialize();
		this.start();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedLookAndFeelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(255, 250, 205));
		frame.setBounds(100, 100, 721, 489);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(0, 88, 707, 321);
		frame.getContentPane().add(panel);
		panel.setLayout(new BorderLayout(0, 0));

		JLabel lblNewLabel = new JLabel("SERVER");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 50));
		lblNewLabel.setBounds(239, 10, 185, 40);
		frame.getContentPane().add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("DANH SÁCH CÁC KẾT NỐI");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_1.setBounds(0, 60, 244, 33);
		frame.getContentPane().add(lblNewLabel_1);

		JButton BtnClose = new JButton("Đóng");
		BtnClose.setBounds(612, 419, 85, 21);
		frame.getContentPane().add(BtnClose);

		tbmodel.addColumn("Địa chỉ máy khách");
		tbmodel.addColumn("Cổng máy khách");
		tbmodel.addColumn("Đã kết nối");
		tbmodel.addColumn("Đã đóng");
		tbmodel.addColumn("Thời điểm kết nối");
		table = new JTable(tbmodel);
		table.setBackground(Color.WHITE);
		JScrollPane scrollPane = new JScrollPane(table);
		panel.add(scrollPane, BorderLayout.CENTER);
		frame.setVisible(true);
	}

	@Override
	public void run() {

		this.list = new ArrayList<MySocket>();

		try {

			ServerSocket serverSocket = new ServerSocket(1829);
			System.out.println("Dang mo ket noi");

			while (true) {
				Socket clientSocket = serverSocket.accept();
				Date currentDate = new Date();

				// Định dạng ngày tháng năm
				SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss.SSS");
				String formattedDate = sdf.format(currentDate);
				MySocket Socket = new MySocket(clientSocket, formattedDate);
				list.add(Socket);
				process_ pr = new process_(clientSocket);
				pr.start();
				Thread.sleep(1000);
				tbmodel.setRowCount(0);
				for (MySocket mysocket : list) {

					tbmodel.addRow(new Object[] { mysocket.getSocket().getInetAddress(), mysocket.getSocket().getPort(),
							mysocket.getSocket().isConnected(), mysocket.getSocket().isClosed(),
							mysocket.getCurrentTime() });

				}

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

	}
}
