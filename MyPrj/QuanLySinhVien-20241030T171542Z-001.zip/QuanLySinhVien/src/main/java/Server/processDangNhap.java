/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Server;

import dao.userDAO;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.User;

/**
 *
 * @author Tong Thuan
 */
public class processDangNhap extends Thread {

	private Socket socket;
	private User user;
	private String state;
	private ObjectInputStream oiutput;
	private String mymessage = "";

	public processDangNhap(Socket socket) {

		this.socket = socket;

	}

	@Override
	public void run() {

		boolean isRun = true;

		userDAO userdao = new userDAO();

		while (isRun) {

			try {
				Thread.sleep(10);

				if (this.user == null) {
					ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());

					this.user = (User) ois.readObject();
				}

				if (this.user != null) {
					state = user.getEmail();

					if (Statement.list.contains(state) && (userdao.Login(user) == true)) {
						sendState send = new sendState(socket, "DADANGNHAPONOIKHAC");
						send.start();
						mymessage = "DADANGNHAPONOIKHAC";
					} else {

						boolean result = userdao.Login(user);
						if (result) {
							Statement.online(state);
							sendState send = new sendState(socket, "DANGNHAPTHANHCONG");
							send.start();
							mymessage = "DANGNHAPTHANHCONG";
						} else {
							sendState send = new sendState(socket, "THONGTINKHONGDUNG");
							send.start();
							mymessage = "THONGTINKHONGDUNG";
						}
					}
				}

				this.user = null;
			} catch (Exception e) {

				try {
					this.socket.close();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				isRun = false;
				System.out.println("Ngat Ket Noi");
				if (Statement.list.size() > 0 && (state != null) && mymessage.equals("DANGNHAPTHANHCONG")) {
					Statement.list.remove(state);
				}

			}
		}

	}
}
