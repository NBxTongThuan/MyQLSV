/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Server;

import java.io.ObjectInputStream;
import java.net.Socket;
import dao.userDAO;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.User;

/**
 *
 * @author Tong Thuan
 */
public class processDangKy extends Thread {

	private Socket socket;
	private User user;

	public processDangKy(Socket socket) {
		this.socket = socket;
	}

	@Override
	public void run() {
		boolean isRun = true;
		while (isRun == true) {
			try {
				ObjectInputStream Oinput = new ObjectInputStream(this.socket.getInputStream());

				this.user = (User) Oinput.readObject();

				String emailregex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:gmail)\\.(?:com)$";

				userDAO userdao = new userDAO();

				if (this.user.getEmail().matches(emailregex) == true && userdao.CheckExist(user.getEmail()) == true) {
					sendState send = new sendState(socket, "taikhoandatontai");
					send.start();
				} else if (this.user.getEmail().equals("OUT")) {
					this.socket.close();
					isRun = false;

				} else {
					if (userdao.Register(user) == true) {
						sendState send = new sendState(socket, "dangkythanhcong");
						send.start();
						break;
					} else {
						sendState send = new sendState(socket, "dangkykhongthanhcong");
						send.start();
					}
				}

			} catch (Exception e) {

				e.printStackTrace();
				try {
					this.socket.close();
					isRun = false;
				} catch (IOException ex) {
					Logger.getLogger(processDangKy.class.getName()).log(Level.SEVERE, null, ex);
				}
			}
		}
	}

}
