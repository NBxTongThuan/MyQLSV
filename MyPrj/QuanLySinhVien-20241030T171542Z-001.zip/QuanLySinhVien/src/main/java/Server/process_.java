/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Tong Thuan
 */
public class process_ extends Thread {

	private Socket socket;

	public process_(Socket socket) {
		this.socket = socket;
	}

	@Override
	public void run() {

		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
			String messageString = null;
			PrintWriter writer = new PrintWriter(this.socket.getOutputStream());
			while (messageString == null) {
				messageString = reader.readLine();
			}
			if (messageString.equals("DANGNHAP")) {
				processDangNhap prdn = new processDangNhap(this.socket);
				prdn.start();

			} else if (messageString.equals("DANGKY")) {
				processDangKy prdk = new processDangKy(this.socket);
				prdk.start();
			} else if (messageString.equals("QUENMATKHAU")) {

				processQuenMatKhau prcqmk = new processQuenMatKhau(socket);
				prcqmk.start();

			} else if (messageString.equals("DOIMATKHAU")) {

				processDoiMatKhau prdmk = new processDoiMatKhau(socket);
				prdmk.start();

			} else if (messageString.equals("QUANLY")) {
				processQuanLy prql = new processQuanLy(this.socket);
				prql.start();

			} else if (messageString.equals("QUANLYTAIKHOAN")) {
				processQuanLyTaiKhoan prql = new processQuanLyTaiKhoan(this.socket);
				prql.start();

			}
		} catch (IOException e) {
			try {
				this.socket.close();
			} catch (IOException ex) {
				Logger.getLogger(process_.class.getName()).log(Level.SEVERE, null, ex);
			}
		}
	}
}
