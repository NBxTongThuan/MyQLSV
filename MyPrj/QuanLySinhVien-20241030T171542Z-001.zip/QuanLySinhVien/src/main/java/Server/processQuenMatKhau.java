package Server;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.Properties;
import java.util.Random;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import dao.userDAO;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class processQuenMatKhau extends Thread {

	private Socket socket;
	private String email;
	private String OTP;
	private String newpass;

	public processQuenMatKhau(Socket socket) {
		this.socket = socket;
	}

	@Override
	public void run() {
		boolean isRun = true;
		while (isRun == true) {
			try {
				BufferedReader reader = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
				email = reader.readLine();

				userDAO userdao = new userDAO();

				String emailregex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:gmail)\\.(?:com)$";

				if (email.matches(emailregex) == true && userdao.CheckExist(email) == false) {
					sendState send = new sendState(socket, "taikhoankhongtontai");
					send.start();
				} else if (email.equals("OUT")) {

					this.socket.close();
					isRun = false;

				} else {
					RanOTP();
					this.newpass = "Qlsv" + OTP + "@";
					int result = userdao.UpdateByID(email, newpass);
					if (result == 0) {
						sendState send = new sendState(socket, "khongthanhcong");
						send.start();
					} else {
						SendNewPass();
						sendState send = new sendState(socket, "capnhatthanhcong");
						send.start();
					}

				}

			} catch (Exception e) {
				try {
					this.socket.close();
					isRun = false;

				} catch (IOException ex) {
					Logger.getLogger(processQuenMatKhau.class.getName()).log(Level.SEVERE, null, ex);
				}
			}

		}
	}

	public String RanOTP() {
		OTP = "";
		Random random = new Random();
		for (int i = 0; i < 6; i++) {
			int value = random.nextInt(10);
			OTP += value;
		}
		return OTP;

	}

	public void SendNewPass() {
		final String from = "tongthuan15092003@gmail.com";
		final String passWord = "vplymroxjzluvxpx";
		// Thuộc tính
		Properties props = new Properties();
		props.put("mail.smtp.host", "smtp.gmail.com");// SMTP HOST
		props.put("mail.smtp.port", "587");// TSL 587, SSL 465
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.ssl.protocols", "TLSv1.2");

		// Create Authenticator
		Authenticator auth = new Authenticator() {
			@Override
			protected PasswordAuthentication getPasswordAuthentication() {
				// TODO Auto-generated method stub
				return new PasswordAuthentication(from, passWord);
			}

		};

		// phiên làm việc
		Session session = Session.getInstance(props, auth);

		// Gửi email
		final String to = email;

		// Tạo một tin nhắn
		MimeMessage msg = new MimeMessage(session);
		try {
			msg.addHeader("Content-type", "text/HTML; charset=UTF-8");
			msg.setFrom();
			msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to, false));

			// Tiêu đề
			msg.setSubject("Quản Lý Sinh Viên");

			// Nội dung email
			msg.setText("Mật khẩu mới cho tài khoản của bạn là : " + newpass + ", Vui lòng không để lộ mật khẩu này!",
					"UTF-8");

			Transport.send(msg);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
