
package Server;

import dao.GiangVienDAO;
import dao.MonHocDAO;
import dao.sinhVienDAO;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import model.GiangVien;
import model.MonHoc;
import model.SinhVien;

/**
 *
 * @author Tong Thuan
 */
public class processQuanLy extends Thread {

	private Socket socket;

	public processQuanLy(Socket socket) {
		this.socket = socket;
	}

	@Override
	public void run() {
		boolean isRun = true;
		while (isRun == true) {
			try {
				sinhVienDAO svdao = new sinhVienDAO();
				MonHocDAO mhdao = new MonHocDAO();
				GiangVienDAO gvdao = new GiangVienDAO();
				BufferedReader reader = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
				String messageFromClient = null;
				messageFromClient = reader.readLine();
				ObjectOutputStream ooutput = new ObjectOutputStream(this.socket.getOutputStream());
				if (messageFromClient.equals("DANGXUAT")) {
					isRun = false;
					this.socket.close();
					return;
				} else if (messageFromClient.equals("SEARCHALL")) {
					List<SinhVien> list = new ArrayList<SinhVien>();
					list = svdao.SelectAll();

					ooutput.writeObject(list);
					ooutput.flush();

				} else if (messageFromClient.equals("SEARCHALLMH")) {
					List<MonHoc> list = new ArrayList<MonHoc>();
					list = mhdao.SelectAll();

					ooutput.writeObject(list);
					ooutput.flush();

				} else if (messageFromClient.equals("SEARCHALLGV")) {
					List<GiangVien> list = new ArrayList<GiangVien>();
					list = gvdao.SelectAll();

					ooutput.writeObject(list);
					ooutput.flush();

				} else if (messageFromClient.equals("SEARCHBYNAME")) {

					String name = reader.readLine();
					List<SinhVien> list = new ArrayList<SinhVien>();
					list = svdao.SearchByFieldInput("Student_Name", name);

					ooutput.writeObject(list);
					ooutput.flush();

				} else if (messageFromClient.equals("SEARCHMHBYNAME")) {

					String name = reader.readLine();
					List<MonHoc> list = new ArrayList<MonHoc>();
					list = mhdao.SearchByName(name);

					ooutput.writeObject(list);
					ooutput.flush();

				} else if (messageFromClient.equals("SEARCHGVBYNAME")) {

					String name = reader.readLine();
					List<GiangVien> list = new ArrayList<GiangVien>();
					list = gvdao.SearchByName(name);

					ooutput.writeObject(list);
					ooutput.flush();

				} else if (messageFromClient.equals("SEARCHBYADDRESS")) {

					String address = reader.readLine();
					List<SinhVien> list = new ArrayList<SinhVien>();
					list = svdao.SearchByFieldInput("Student_Address", address);

					ooutput.writeObject(list);
					ooutput.flush();

				} else if (messageFromClient.equals("SEARCHBYID")) {

					String myID = reader.readLine();
					int id = Integer.parseInt(myID);

					List<SinhVien> list = new ArrayList<SinhVien>();
					SinhVien sv = svdao.selectByID(id);
					if (sv != null) {
						list.add(sv);
					}

					ooutput.writeObject(list);
					ooutput.flush();

				} else if (messageFromClient.equals("ADD")) {

					ObjectInputStream Oinput = new ObjectInputStream(this.socket.getInputStream());
					SinhVien sv = (SinhVien) Oinput.readObject();

					if (svdao.intsert(sv) == true) {

						sendState send = new sendState(socket, "ADDS");
						send.start();
					}

				} else if (messageFromClient.equals("ADDMH")) {

					ObjectInputStream Oinput = new ObjectInputStream(this.socket.getInputStream());
					MonHoc mh = (MonHoc) Oinput.readObject();

					if (mhdao.intsert(mh) == true) {

						sendState send = new sendState(socket, "ADDMHS");
						send.start();
					}

				} else if (messageFromClient.equals("ADDGV")) {

					ObjectInputStream Oinput = new ObjectInputStream(this.socket.getInputStream());
					GiangVien gv = (GiangVien) Oinput.readObject();

					if (gvdao.intsert(gv) == true) {

						sendState send = new sendState(socket, "ADDMHS");
						send.start();
					}

				} else if (messageFromClient.equals("EDIT")) {
					ObjectInputStream Oinput = new ObjectInputStream(this.socket.getInputStream());
					SinhVien sv = (SinhVien) Oinput.readObject();

					if (svdao.EditSinhVien(sv) == true) {

						sendState send = new sendState(socket, "EDITS");
						send.start();
					}

				} else if (messageFromClient.equals("EDITMH")) {
					ObjectInputStream Oinput = new ObjectInputStream(this.socket.getInputStream());
					MonHoc mh = (MonHoc) Oinput.readObject();

					if (mhdao.editMonHoc(mh) == true) {

						sendState send = new sendState(socket, "EDITS");
						send.start();
					}

				} else if (messageFromClient.equals("EDITGV")) {
					ObjectInputStream Oinput = new ObjectInputStream(this.socket.getInputStream());
					GiangVien gv = (GiangVien) Oinput.readObject();

					if (gvdao.editGiangVien(gv) == true) {

						sendState send = new sendState(socket, "EDITS");
						send.start();
					}

				} else if (messageFromClient.equals("DELETE")) {

					ObjectInputStream Oinput = new ObjectInputStream(this.socket.getInputStream());
					SinhVien sv = (SinhVien) Oinput.readObject();
					int id = sv.getStudent_ID();
					if (svdao.DeleteByID(id) == true) {

						sendState send = new sendState(socket, "DELETES");
						send.start();
					}

				} else if (messageFromClient.equals("DELETEMH")) {

					ObjectInputStream Oinput = new ObjectInputStream(this.socket.getInputStream());
					MonHoc mh = (MonHoc) Oinput.readObject();
					int id = mh.getId();
					if (mhdao.DeleteByID(id) == true) {

						sendState send = new sendState(socket, "DELETES");
						send.start();
					}

				} else if (messageFromClient.equals("DELETEGV")) {

					ObjectInputStream Oinput = new ObjectInputStream(this.socket.getInputStream());
					GiangVien gv = (GiangVien) Oinput.readObject();
					int id = gv.getMaGiangVien();
					if (mhdao.DeleteByID(id) == true) {

						sendState send = new sendState(socket, "DELETES");
						send.start();
					}

				}

			} catch (Exception e) {

				try {
					isRun = false;
					this.socket.close();
				} catch (IOException ex) {
					Logger.getLogger(processQuanLy.class.getName()).log(Level.SEVERE, null, ex);
				}
			}
		}
	}

}
