package Server;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.Socket;
import dao.userDAO;
import model.User;

public class processDoiMatKhau extends Thread {

	private Socket socket;
	private User user;

	public processDoiMatKhau(Socket socket) {

		this.socket = socket;

	}

	@Override
	public void start() {
		boolean isRun = true;
		while (isRun == true) {
			try {
				ObjectInputStream Oinput = new ObjectInputStream(this.socket.getInputStream());

				User user1 = (User) Oinput.readObject();

				String arrpass[] = user1.getPassWord().split(" ");
				String oldpass = arrpass[0];
				String newpass = arrpass[1];
				String email = user1.getEmail();

				this.user = new User(email, oldpass);

				String emailregex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:gmail)\\.(?:com)$";
				userDAO userdao = new userDAO();

				if (email.matches(emailregex) == true && userdao.Login(this.user) == false) {
					sendState send = new sendState(socket, "taikhoankhongchinhxac");
					send.start();
				} else if (email.equals("OUT") && oldpass.equals("OUT")) {
					this.socket.close();
					isRun = false;

				} else {
					int result = userdao.UpdateByID(email, newpass);
					if (result == 0) {
						sendState send = new sendState(socket, "doimatkhaukhongthanhcong");
						send.start();
					} else {
						sendState send = new sendState(socket, "doimatkhauthanhcong");
						send.start();
					}
				}

			} catch (Exception e) {

				try {
					this.socket.close();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				isRun = false;

				System.out.println("Ngat ket noi");

				break;
			}
		}

	}

}
