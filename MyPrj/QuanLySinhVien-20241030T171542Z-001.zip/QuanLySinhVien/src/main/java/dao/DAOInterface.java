package dao;

import java.util.List;

public interface DAOInterface<T> {

    public List<T> SelectAll();

    public boolean intsert(T t);

    public T selectByID(int id);

    public Boolean DeleteByID(int id);

}
