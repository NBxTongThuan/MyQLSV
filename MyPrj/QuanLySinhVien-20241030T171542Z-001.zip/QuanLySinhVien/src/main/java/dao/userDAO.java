package dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import Encoder.PasswordEncoder;
import model.User;
import util.HibernateUtil;

public class userDAO {

//	String passWord = PasswordEncoder.encode(item.getPassWord());

	public boolean Login(User user) {
		boolean result = false;
		try {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			if (sessionFactory != null) {
				Session session = sessionFactory.openSession();
				Transaction tr = session.beginTransaction();

				String hql = "from User u where u.email=:email";

				Query query = session.createQuery(hql);
				query.setParameter("email", user.getEmail());

				@SuppressWarnings("unchecked")
				List<User> list = (List<User>) query.getResultList();
				if (list.size() > 0) {

					User user2 = list.get(0);
					if (PasswordEncoder.matches(user.getPassWord(), user2.getPassWord())) {
						result = true;
					} else {
						result = false;
					}

				} else {
					result = false;
				}

				tr.commit();
				session.close();
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return result;
	}

	public boolean Register(User user) {
		boolean result = false;
		if (CheckExist(user.getEmail()) != true) {
			try {
				SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
				if (sessionFactory != null) {
					Session session = sessionFactory.openSession();
					Transaction transaction = session.beginTransaction();

					String passWord = PasswordEncoder.encode(user.getPassWord());

					user.setPassWord(passWord);

					session.save(user);

					transaction.commit();
					session.close();
					result = true;
				}
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
				result = false;
			}
		} else {
			result = false;
		}

		return result;
	}

	public boolean CheckExist(String email) {
		boolean result = false;
		try {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			if (sessionFactory != null) {
				Session session = sessionFactory.openSession();
				Transaction tr = session.beginTransaction();

				String hql = "from User u where u.email =:email";

				Query query = session.createQuery(hql);
				query.setParameter("email", email);

				@SuppressWarnings("unchecked")
				List<User> list = query.getResultList();
				if (list.size() > 0) {
					result = true;
				}
				tr.commit();
				session.close();
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return result;

	}

	public int UpdateByID(String ID, String pass) {
		int result = 0;

		try {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			if (sessionFactory != null) {
				Session session = sessionFactory.openSession();
				Transaction tran = session.beginTransaction();
				String hql = "UPDATE User SET passWord = :passWord WHERE email = :email";
				Query query = session.createQuery(hql);
				query.setParameter("passWord", PasswordEncoder.encode(pass));
				query.setParameter("email", ID);

				// Thực thi câu lệnh HQL
				result = query.executeUpdate();

				// Commit transaction
				tran.commit();
				session.close();
			}
		} catch (Exception e) {
			// TODO: handle exception
		}

		return result;

	}

	public List<User> SelectAll() {
		List<User> list = null;
		try {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			if (sessionFactory != null) {
				Session session = sessionFactory.openSession();
				Transaction tr = session.beginTransaction();

				String hql = "from User";
				Query query = session.createQuery(hql);

				list = query.getResultList();

				tr.commit();
				session.close();
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		}
		return list;
	}

	public User selectByID(String id) {

		User us = new User();
		List<User> result = new ArrayList<User>();
		try {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			if (sessionFactory != null) {
				Session session = sessionFactory.openSession();
				Transaction tr = session.beginTransaction();

				String hql = "FROM User s WHERE s.email = :email";
				Query query = session.createQuery(hql);
				query.setParameter("email", id);
				result = query.getResultList();
				if (result.size() > 0) {
					us = result.get(0);
				}

				tr.commit();
				session.close();
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return us;
	}

	public Boolean DeleteByID(String id) {
		boolean result = false;

		try {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			if (sessionFactory != null) {
				Session session = sessionFactory.openSession();
				Transaction tr = session.beginTransaction();

				String hql = "DELETE FROM User WHERE email = :email";
				Query query = session.createQuery(hql);
				query.setParameter("email", id);

				int rs = query.executeUpdate();

				if (rs != 0) {
					result = true;
				}

				tr.commit();
				session.close();

			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return result;
	}

	public static void main(String[] args) {
		userDAO dao = new userDAO();

	}

}
