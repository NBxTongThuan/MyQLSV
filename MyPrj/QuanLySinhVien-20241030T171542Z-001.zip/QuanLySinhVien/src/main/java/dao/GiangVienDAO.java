package dao;

import java.util.ArrayList;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import model.GiangVien;
import model.MonHoc;
import util.HibernateUtil;

public class GiangVienDAO implements DAOInterface<GiangVien> {

	public GiangVien selectByID(int id) {
		GiangVien giangVien = null;
		try {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			if (sessionFactory != null) {
				Session session = sessionFactory.openSession();
				Transaction tr = session.beginTransaction();
				giangVien = session.get(GiangVien.class, id);
				tr.commit();
				session.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return giangVien;
	}

	public boolean editGiangVien(GiangVien giangVien) {
		boolean result = false;
		try {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			if (sessionFactory != null) {
				Session session = sessionFactory.openSession();
				Transaction tr = session.beginTransaction();
				session.update(giangVien);
				tr.commit();
				session.close();
				result = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public List<GiangVien> SelectAll() {
		List<GiangVien> list = null;
		try {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			if (sessionFactory != null) {
				Session session = sessionFactory.openSession();
				Transaction tr = session.beginTransaction();
				String hql = "FROM GiangVien";
				Query<GiangVien> query = session.createQuery(hql);
				list = query.getResultList();
				tr.commit();
				session.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	public boolean intsert(GiangVien t) {
		boolean result = false;
		try {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			if (sessionFactory != null) {
				Session session = sessionFactory.openSession();
				Transaction tr = session.beginTransaction();
				session.save(t);
				tr.commit();
				session.close();
				result = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public Boolean DeleteByID(int id) {
		boolean result = false;
		try {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			if (sessionFactory != null) {
				Session session = sessionFactory.openSession();
				Transaction tr = session.beginTransaction();
				GiangVien giangVien = session.get(GiangVien.class, id);
				if (giangVien != null) {
					session.delete(giangVien);
					tr.commit();
					result = true;
				}
				session.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	public List<GiangVien> SearchByName(String item) {
		List<GiangVien> result = new ArrayList<GiangVien>();
		try {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			if (sessionFactory != null) {
				Session session = sessionFactory.openSession();
				Transaction tr = session.beginTransaction();

				String hql = "FROM GiangVien g WHERE g.tenGiangVien LIKE :item";
				Query query = session.createQuery(hql);
				query.setParameter("item", "%" + item + "%");
				result = query.getResultList();
				tr.commit();
				session.close();
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return result;
	}

	public static void main(String[] args) {
		GiangVienDAO gvdao = new GiangVienDAO();

		List<GiangVien> list = gvdao.SelectAll();

		for (GiangVien giangVien : list) {
			System.out.println(giangVien.toString());
		}
	}
}
