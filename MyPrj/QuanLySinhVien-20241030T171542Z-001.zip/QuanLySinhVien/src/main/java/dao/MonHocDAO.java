package dao;

import java.util.ArrayList;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import model.GiangVien;
import model.MonHoc;
import model.SinhVien;
import util.HibernateUtil;

public class MonHocDAO implements DAOInterface<MonHoc> {

	public MonHoc selectByID(int id) {
		MonHoc monHoc = null;
		try {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			if (sessionFactory != null) {
				Session session = sessionFactory.openSession();
				Transaction tr = session.beginTransaction();
				monHoc = session.get(MonHoc.class, id);
				tr.commit();
				session.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return monHoc;
	}

	public boolean editMonHoc(MonHoc monHoc) {
		boolean result = false;
		try {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			if (sessionFactory != null) {
				Session session = sessionFactory.openSession();
				Transaction tr = session.beginTransaction();
				session.update(monHoc);
				tr.commit();
				session.close();
				result = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	@Override
	public List<MonHoc> SelectAll() {
		List<MonHoc> list = null;
		try {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			if (sessionFactory != null) {
				Session session = sessionFactory.openSession();
				Transaction tr = session.beginTransaction();
				String hql = "FROM MonHoc";
				Query query = session.createQuery(hql);
				list = query.getResultList();
				tr.commit();
				session.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public boolean intsert(MonHoc t) {
		boolean result = false;
		try {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			if (sessionFactory != null) {
				Session session = sessionFactory.openSession();
				Transaction tr = session.beginTransaction();
				session.save(t);
				tr.commit();
				session.close();
				result = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public List<MonHoc> SearchByName(String item) {
		List<MonHoc> result = new ArrayList<MonHoc>();
		try {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			if (sessionFactory != null) {
				Session session = sessionFactory.openSession();
				Transaction tr = session.beginTransaction();

				String hql = "FROM MonHoc m WHERE m.tenMonHoc LIKE :item";
				Query query = session.createQuery(hql);
				query.setParameter("item", "%" + item + "%");
				result = query.getResultList();
				tr.commit();
				session.close();
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return result;
	}

	@Override
	public Boolean DeleteByID(int id) {
		boolean result = false;
		try {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			if (sessionFactory != null) {
				Session session = sessionFactory.openSession();
				Transaction tr = session.beginTransaction();
				MonHoc monHoc = session.get(MonHoc.class, id);
				if (monHoc != null) {
					session.delete(monHoc);
					tr.commit();
					result = true;
				}
				session.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

}
