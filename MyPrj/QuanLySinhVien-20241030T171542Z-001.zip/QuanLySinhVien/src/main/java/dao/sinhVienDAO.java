package dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import model.SinhVien;
import util.HibernateUtil;

public class sinhVienDAO implements DAOInterface<SinhVien> {

	public boolean intsert(SinhVien t) {
		boolean result = false;
		try {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			if (sessionFactory != null) {
				Session session = sessionFactory.openSession();
				Transaction tr = session.beginTransaction();

				session.save(t);

				result = true;

				tr.commit();
				session.close();

			}

		} catch (Exception e) {
			result = false;
		}

		return result;
	}

	public SinhVien selectByID(int id) {
		SinhVien sv = null;

		try {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			if (sessionFactory != null) {
				Session session = sessionFactory.openSession();
				Transaction tr = session.beginTransaction();

				sv = session.get(SinhVien.class, id);

				tr.commit();
				session.close();
			}

		} catch (Exception e) {
			// TODO: handle exception
		}
		return sv;
	}

	@SuppressWarnings("unchecked")
	public List<SinhVien> SearchByFieldInput(String FieldInput, String item) {
		List<SinhVien> result = new ArrayList<SinhVien>();
		try {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			if (sessionFactory != null) {
				Session session = sessionFactory.openSession();
				Transaction tr = session.beginTransaction();

				String hql = "FROM SinhVien s WHERE s." + FieldInput + " LIKE :item";
				Query query = session.createQuery(hql);
				query.setParameter("item", "%" + item + "%");
				result = query.getResultList();
				tr.commit();
				session.close();
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return result;
	}

	public boolean EditSinhVien(SinhVien student) {

		boolean result = false;

		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		if (sessionFactory != null) {
			try {
				Session session = sessionFactory.openSession();
				Transaction transaction = session.beginTransaction();

				// Câu lệnh HQL để cập nhật SinhVien
				String hql = "UPDATE SinhVien sv " + "SET sv.GPA = :gpa, " + "sv.Student_Address = :address, "
						+ "sv.Student_CumulativeNumberOfCredits = :cumulativeCredits, "
						+ "sv.Student_DateOfBirth = :dateOfBirth, " + "sv.Student_DayAdmission = :dayAdmission, "
						+ "sv.Student_Gender = :gender, " + "sv.Student_Major = :major, " + "sv.Student_Name = :name, "
						+ "sv.Student_NumberOfCredits = :numberOfCredits, " + "sv.Student_PhoneNumber = :phoneNumber, "
						+ "sv.email = :email " + "WHERE sv.Student_ID = :studentId";

				Query query = session.createQuery(hql);
				query.setParameter("gpa", student.getGPA());
				query.setParameter("address", student.getStudent_Address());
				query.setParameter("cumulativeCredits", student.getStudent_CumulativeNumberOfCredits());
				query.setParameter("dateOfBirth", student.getStudent_DateOfBirth());
				query.setParameter("dayAdmission", student.getStudent_DayAdmission());
				query.setParameter("gender", student.getStudent_Gender());
				query.setParameter("major", student.getStudent_Major());
				query.setParameter("name", student.getStudent_Name());
				query.setParameter("numberOfCredits", student.getStudent_NumberOfCredits());
				query.setParameter("phoneNumber", student.getStudent_PhoneNumber());
				query.setParameter("email", student.getEmail());
				query.setParameter("studentId", student.getStudent_ID());

				int rs = query.executeUpdate();
				transaction.commit();

				if (rs > 0) {
					result = true;
				}

			} catch (Exception e) {
				e.printStackTrace();
			}

		}

		return result;

	}

	public Boolean DeleteByID(int id) {
		boolean result = false;
		try {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			if (sessionFactory != null) {
				Session session = sessionFactory.openSession();
				Transaction tr = session.beginTransaction();

				String hql = "DELETE FROM SinhVien WHERE id = :id";
				Query query = session.createQuery(hql);
				query.setParameter("id", id);

				int rs = query.executeUpdate();

				if (rs != 0) {
					result = true;
				}

				tr.commit();
				session.close();

			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return result;

	}

	public List<SinhVien> SelectAll() {
		List<SinhVien> list = null;
		try {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			if (sessionFactory != null) {
				Session session = sessionFactory.openSession();
				Transaction tr = session.beginTransaction();

				String hql = "from SinhVien";
				Query query = session.createQuery(hql);

				list = query.getResultList();

				tr.commit();
				session.close();
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		}
		return list;
		// TODO Auto-generated method stub

	}

}
