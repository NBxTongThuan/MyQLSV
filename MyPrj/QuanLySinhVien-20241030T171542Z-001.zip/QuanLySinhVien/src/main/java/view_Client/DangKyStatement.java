/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view_Client;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.Socket;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author Tong Thuan
 */
public class DangKyStatement extends Thread {

    private Socket socket;
    private String message;
    private JFrame frame;

    public DangKyStatement(Socket socket, JFrame frame) {
        this.socket = socket;
        this.frame = frame;
    }

    @Override
    public void run() {

        try {
            BufferedReader read = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
            this.message = read.readLine();
            if (message.equals("taikhoandatontai")) {
                JOptionPane.showMessageDialog(this.frame, "Đăng ký không thành công, tài khoản đã tồn tại!", "Chú Ý!", JOptionPane.ERROR_MESSAGE);
            } else if (message.equals("dangkythanhcong")) {

                JOptionPane.showMessageDialog(this.frame, "Đăng ký thành công, trở lại để đăng nhập", "Thành công", JOptionPane.ERROR_MESSAGE);

            }else if (message.equals("dangkykhongthanhcong")) {

                JOptionPane.showMessageDialog(this.frame, "Đăng ký không thành công, lỗi máy chủ!", "Thành công", JOptionPane.ERROR_MESSAGE);

            }
        } catch (Exception e) {
                
        }
    }

}
