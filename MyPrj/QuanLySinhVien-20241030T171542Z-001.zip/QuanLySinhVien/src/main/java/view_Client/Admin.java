package view_Client;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.Socket;

import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import model.User;

import javax.swing.JPasswordField;
import javax.swing.JButton;

public class Admin extends Thread implements ActionListener {

	private JFrame frame;
	private JTextField textFieldUserName;
	private JPasswordField textFieldPassWord;
	private Socket socket;
	private static final String url = "localhost";
	private static final int PORT = 1829;
	private User user;
	private PrintWriter writer;
	private BufferedReader read;
	private JLabel serverStateLB;
	private JButton BtnLogin, BtnExit;

	/**
	 * Launch the application.
	 */

	/**
	 * Create the application.
	 */
	public Admin() {
		initialize();

		this.start();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {

		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedLookAndFeelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		frame = new JFrame();
		frame.setBounds(100, 100, 436, 260);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 240));
		panel.setBounds(10, 10, 404, 201);
		frame.getContentPane().add(panel);
		panel.setLayout(null);

		JLabel lblNewLabel_1 = new JLabel("Tài khoản");
		lblNewLabel_1.setBounds(60, 63, 51, 13);
		panel.add(lblNewLabel_1);

		textFieldUserName = new JTextField();
		textFieldUserName.setBounds(121, 60, 195, 19);
		panel.add(textFieldUserName);
		textFieldUserName.setColumns(10);

		JLabel lblNewLabel_1_1 = new JLabel("Mật khẩu");
		lblNewLabel_1_1.setBounds(60, 104, 51, 13);
		panel.add(lblNewLabel_1_1);

		textFieldPassWord = new JPasswordField();
		textFieldPassWord.setBounds(121, 101, 195, 19);
		panel.add(textFieldPassWord);

		BtnLogin = new JButton("Đăng nhập");
		BtnLogin.addActionListener(this);
		BtnLogin.setBounds(75, 146, 85, 21);
		panel.add(BtnLogin);

		BtnExit = new JButton("Thoát");
		BtnExit.addActionListener(this);
		BtnExit.setBounds(231, 146, 85, 21);
		panel.add(BtnExit);

		serverStateLB = new JLabel("");
		serverStateLB.setBounds(2, 2, 183, 13);
		panel.add(serverStateLB);

		JLabel lblNewLabel = new JLabel("ĐĂNG NHẬP ADMIN");
		lblNewLabel.setForeground(new Color(0, 0, 255));
		lblNewLabel.setBounds(121, 18, 195, 32);
		panel.add(lblNewLabel);
		lblNewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 20));

		frame.setVisible(true);

	}

	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		this.user = new User();

		if (e.getSource() == BtnLogin) {
			Login();

		} else if (e.getSource() == BtnExit) {
			Exit();
		}
	}

	public void Login() {
		if (this.socket == null) {
			// Lần bật chương trình đầu tiên, đợi kết nối nếu socket = null
			JOptionPane.showMessageDialog(frame, "Không thể kết nối tới máy chủ, vui lòng đợi kết nối!", "Chú Ý!",
					JOptionPane.ERROR_MESSAGE);
		}
		// Đưa ra cảnh báo nếu không nhập đầy đủ tài khoản hoặc mật khẩu
		if (((textFieldPassWord.getPassword().length <= 0) || (textFieldUserName.getText().equals("")))
				&& this.socket != null) {
			JOptionPane.showMessageDialog(frame, "Vui lòng nhập đầy đủ thông tin tài khoản và mật khẩu!", "Chú Ý!",
					JOptionPane.ERROR_MESSAGE);
			return;
		}
		String username = "[a-zA-Z]+";

		if (!textFieldUserName.getText().matches(username)) {
			JOptionPane.showMessageDialog(frame, "Tài khoản không hợp lệ, vui lòng dùng tài khoản của Admin!", "Chú Ý!",
					JOptionPane.ERROR_MESSAGE);

		} else {

			String userName = textFieldUserName.getText() + "";
			char[] pass = textFieldPassWord.getPassword();
			this.user.setEmail(userName);
			String passWord = new String(pass);
			this.user.setPassWord(passWord);

			if (this.socket != null) {
				try {

					System.out.println("Gui Object");
					ObjectOutputStream ooutput = new ObjectOutputStream(this.socket.getOutputStream());
					ooutput.writeObject(user);
					DangNhapAdminStatement adminstate = new DangNhapAdminStatement(socket, frame, userName, url, PORT);
					adminstate.start();
				} catch (IOException e1) {
					JOptionPane.showMessageDialog(frame, "Không thể kết nối tới máy chủ, vui lòng thoát chương trình!",
							"Chú Ý!", JOptionPane.ERROR_MESSAGE);
					this.serverStateLB.setText("Máy chủ đã tắt");
				}
			}

		}

	}

	public void Exit() {
		System.exit(0);
	}

	@Override
	public void run() {
		while (this.socket == null) {
			try {
				this.socket = new Socket(url, PORT);
				this.serverStateLB.setText("Kết nối máy chủ thành công");
			} catch (Exception e) {
				// TODO: handle exception
				System.out.println("Khong the ket noi toi server");
				this.serverStateLB.setText("Không thế kết nối đến máy chủ!");
			}
			try {
				Thread.sleep(100);
			} catch (Exception ex) {
				ex.printStackTrace();

			}
		}

		if (this.socket != null) {
			try {
				writer = new PrintWriter(this.socket.getOutputStream());
				read = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}

		if (this.socket != null) {
			writer.println("DANGNHAP");
			writer.flush();
		}

	}

	public static void main(String[] args) {
		new Admin();
	}

}
