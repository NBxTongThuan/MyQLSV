package view_Client;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.Socket;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class QuenMatKhauStatement extends Thread {
	private Socket socket;
	private String message;
	private JFrame frame;

	public QuenMatKhauStatement(Socket socket, JFrame frame) {
		this.socket = socket;
		this.frame = frame;
	}

	@Override
	public void run() {

		try {
			BufferedReader read = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
			this.message = read.readLine();

			if (message.equals("taikhoankhongtontai")) {
				JOptionPane.showMessageDialog(this.frame, "Tài khoản bạn nhập không tồn tại trong hệ thống!", "Chú Ý!",
						JOptionPane.ERROR_MESSAGE);
			} else if (message.equals("khongthanhcong")) {

				JOptionPane.showMessageDialog(this.frame, "Không thành công!", "Thất bại", JOptionPane.ERROR_MESSAGE);

			} else if (message.equals("capnhatthanhcong")) {

				JOptionPane.showMessageDialog(this.frame,
						"Mật khẩu mới đã được gửi tới email của bạn, vui lòng kiểm tra email và trở lại để đăng nhập",
						"Thành công", JOptionPane.INFORMATION_MESSAGE);

			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
