/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view_Client;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.Socket;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author Tong Thuan
 */
public class DoiMatKhauStatement extends Thread {

    private Socket socket;
    private String message;
    private JFrame frame;

    public DoiMatKhauStatement(Socket socket, JFrame frame) {
        this.socket = socket;
        this.frame = frame;
    }

    @Override
    public void run() {

        try {
            BufferedReader read = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
            this.message = read.readLine();
            if (message.equals("taikhoankhongchinhxac")) {
                JOptionPane.showMessageDialog(this.frame, "Thông tin tài khoản hoặc mật khẩu không chính xác", "Chú Ý!", JOptionPane.ERROR_MESSAGE);
            } else if (message.equals("doimatkhaukhongthanhcong")) {

                JOptionPane.showMessageDialog(this.frame, "Đổi mật khẩu không thành công, lỗi máy chủ", "Lỗi", JOptionPane.ERROR_MESSAGE);

            }else if(message.equals("doimatkhauthanhcong"))
            {
            	JOptionPane.showMessageDialog(this.frame,
						"Đổi mật khẩu thành công, trở lại để đăng nhập",
						"Thành công", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (Exception e) {
        	e.printStackTrace();
        }
    }

}
