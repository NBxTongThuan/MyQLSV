package view_Client;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.RowSorter;
import javax.swing.SortOrder;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import model.GiangVien;
import model.MonHoc;
import model.SinhVien;
import model.User;

import javax.swing.JButton;
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import java.awt.Component;
import javax.swing.Box;
import javax.swing.JComboBox;
import java.awt.FlowLayout;

public class QuanLyMonHoc extends Thread implements ActionListener, ListSelectionListener {

	private JFrame frame;
	private JTextField textFieldSearch;
	private JTextField textFieldID;
	private JTextField textFieldName;
	private DefaultTableModel tbmodel;
	private JTable table;
	private JMenuItem BtnmnExportExcel;
	private JButton BtnSearch, BtnDelete, BtnClear, BtnEdit, BtnAdd, BtnBack, BtnReload;
	private JFrame jframe;
	private Socket socket;
	private int timeLoadData = 0;
	private JComboBox comboBoxGV, comboBoxPPDanhGia, comboBoxSoLuongSV, comboBoxSoTC;
	private JTextArea textAreaMota;

	/**
	 * Launch the application.
	 */
	/**
	 * Create the application.
	 */
	public QuanLyMonHoc(JFrame jframe, Socket socket) {

		this.jframe = jframe;
		this.socket = socket;
		this.tbmodel = new DefaultTableModel();
		initialize();
		this.start();

	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {

		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedLookAndFeelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		frame = new JFrame();
		frame.setBounds(100, 100, 1014, 547);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JPanel panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBackground(new Color(238, 232, 170));
		panel_1.setBounds(10, 68, 306, 432);
		frame.getContentPane().add(panel_1);

		JPanel panel_2 = new JPanel();
		panel_2.setLayout(null);
		panel_2.setBounds(10, 10, 286, 74);
		panel_1.add(panel_2);

		JLabel lblNewLabel = new JLabel("Tìm kiếm");
		lblNewLabel.setBounds(10, 10, 70, 13);
		panel_2.add(lblNewLabel);

		textFieldSearch = new JTextField();
		textFieldSearch.setColumns(10);
		textFieldSearch.setBounds(10, 33, 181, 19);
		panel_2.add(textFieldSearch);

		BtnSearch = new JButton("Search");
		BtnSearch.addActionListener(this);
		BtnSearch.setBounds(201, 32, 75, 21);
		panel_2.add(BtnSearch);

		JLabel lblNewLabel_1 = new JLabel("Nhập tên môn học");
		lblNewLabel_1.setBounds(101, 10, 105, 13);
		panel_2.add(lblNewLabel_1);

		JPanel panel_3 = new JPanel();
		panel_3.setLayout(null);
		panel_3.setBounds(10, 94, 290, 328);
		panel_1.add(panel_3);

		BtnDelete = new JButton("Delete");
		BtnDelete.addActionListener(this);
		BtnDelete.setBounds(199, 272, 85, 21);
		panel_3.add(BtnDelete);

		BtnClear = new JButton("Clear");
		BtnClear.addActionListener(this);
		BtnClear.setBounds(199, 297, 85, 21);
		panel_3.add(BtnClear);

		BtnEdit = new JButton("Edit");
		BtnEdit.addActionListener(this);
		BtnEdit.setBounds(105, 272, 85, 21);
		panel_3.add(BtnEdit);

		BtnAdd = new JButton("Add");
		BtnAdd.addActionListener(this);
		BtnAdd.setBounds(10, 272, 85, 21);
		panel_3.add(BtnAdd);

		JLabel lblNewLabel_2_2 = new JLabel("Mô tả");
		lblNewLabel_2_2.setBounds(10, 86, 45, 13);
		panel_3.add(lblNewLabel_2_2);

		JLabel lblNewLabel_2_1_1 = new JLabel("Mã môn");
		lblNewLabel_2_1_1.setBounds(10, 30, 45, 13);
		panel_3.add(lblNewLabel_2_1_1);

		textFieldID = new JTextField();
		textFieldID.setEditable(false);
		textFieldID.setColumns(10);
		textFieldID.setBounds(79, 30, 188, 19);
		panel_3.add(textFieldID);

		textAreaMota = new JTextArea();
		textAreaMota.setBounds(79, 86, 188, 63);
		panel_3.add(textAreaMota);

		JLabel lblNewLabel_2_1_2 = new JLabel("Số TC");
		lblNewLabel_2_1_2.setBounds(10, 159, 65, 13);
		panel_3.add(lblNewLabel_2_1_2);

		comboBoxGV = new JComboBox<String>();
		comboBoxGV.setBounds(78, 188, 189, 21);
		panel_3.add(comboBoxGV);

		JLabel lblNewLabel_2_1_2_1 = new JLabel("Giảng viên PT");
		lblNewLabel_2_1_2_1.setBounds(10, 192, 65, 13);
		panel_3.add(lblNewLabel_2_1_2_1);

		comboBoxPPDanhGia = new JComboBox<String>();
		comboBoxPPDanhGia.addItem("Thi Tự Luận");
		comboBoxPPDanhGia.addItem("Bài Tập Lớn");
		comboBoxPPDanhGia.addItem("Thi Trên Máy");
		comboBoxPPDanhGia.setBounds(78, 219, 189, 21);
		panel_3.add(comboBoxPPDanhGia);

		JLabel lblNewLabel_2_1_2_1_1 = new JLabel("PP đánh giá");
		lblNewLabel_2_1_2_1_1.setBounds(10, 223, 65, 13);
		panel_3.add(lblNewLabel_2_1_2_1_1);

		comboBoxSoLuongSV = new JComboBox<Integer>();
		comboBoxSoLuongSV.addItem(35);
		comboBoxSoLuongSV.addItem(65);
		comboBoxSoLuongSV.addItem(70);
		comboBoxSoLuongSV.setBounds(78, 246, 45, 21);
		panel_3.add(comboBoxSoLuongSV);

		JLabel lblNewLabel_2_1_2_1_1_1 = new JLabel("Số lượng SV");
		lblNewLabel_2_1_2_1_1_1.setBounds(10, 250, 65, 13);
		panel_3.add(lblNewLabel_2_1_2_1_1_1);

		textFieldName = new JTextField();
		textFieldName.setColumns(10);
		textFieldName.setBounds(79, 57, 188, 19);
		panel_3.add(textFieldName);

		JLabel lblNewLabel_2_1_2_2 = new JLabel("Tên môn");
		lblNewLabel_2_1_2_2.setBounds(10, 57, 65, 13);
		panel_3.add(lblNewLabel_2_1_2_2);

		JLabel lblNewLabel_2 = new JLabel("Action");
		lblNewLabel_2.setBounds(10, 0, 45, 13);
		panel_3.add(lblNewLabel_2);

		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(327, 100, 663, 400);
		frame.getContentPane().add(panel);
		panel.setLayout(new BorderLayout(0, 0));

		JLabel lblQunLMn = new JLabel("QUẢN LÝ MÔN HỌC");
		lblQunLMn.setFont(new Font("Tahoma", Font.PLAIN, 36));
		lblQunLMn.setBounds(10, 10, 325, 48);
		frame.getContentPane().add(lblQunLMn);

		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(326, 70, 50, 22);
		frame.getContentPane().add(menuBar);

		JMenu mnNewMenu = new JMenu("menu");
		menuBar.add(mnNewMenu);

		BtnmnExportExcel = new JMenuItem("Xuất file Excel");
		BtnmnExportExcel.addActionListener(this);
		mnNewMenu.add(BtnmnExportExcel);

		BtnBack = new JButton("Trở về trang QLSV");
		BtnBack.addActionListener(this);
		BtnBack.setBounds(873, 10, 117, 21);
		frame.getContentPane().add(BtnBack);

		BtnReload = new JButton("Reload Data");
		BtnReload.addActionListener(this);
		BtnReload.setBounds(885, 69, 105, 21);
		frame.getContentPane().add(BtnReload);

		// Table

		tbmodel.addColumn("Mã môn học");
		tbmodel.addColumn("Tên môn học");
		tbmodel.addColumn("Mô tả");
		tbmodel.addColumn("Số tín chỉ");
		tbmodel.addColumn("Giảng viên phụ trách");
		tbmodel.addColumn("Phương pháp đánh giá");
		tbmodel.addColumn("Số lượng SV tối đa");
		table = new JTable(tbmodel);
		table.getSelectionModel().addListSelectionListener(this);
		JScrollPane scrollPane = new JScrollPane(table);
		panel.add(scrollPane, BorderLayout.CENTER);
		// Table

		comboBoxSoTC = new JComboBox<Integer>();
		comboBoxSoTC.addItem(1);
		comboBoxSoTC.addItem(2);
		comboBoxSoTC.addItem(3);
		comboBoxSoTC.addItem(4);
		comboBoxSoTC.addItem(5);
		comboBoxSoTC.addItem(6);
		comboBoxSoTC.addItem(9);
		comboBoxSoTC.setBounds(79, 159, 85, 21);
		panel_3.add(comboBoxSoTC);

		comboBoxGV.setSelectedIndex(-1);
		comboBoxPPDanhGia.setSelectedIndex(-1);
		comboBoxSoLuongSV.setSelectedIndex(-1);
		comboBoxSoTC.setSelectedIndex(-1);

		BtnEdit.setEnabled(false);
		BtnDelete.setEnabled(false);
		BtnAdd.setEnabled(true);

		frame.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {

				// Hiển thị hộp thoại xác nhận
				int confirm = JOptionPane.showConfirmDialog(frame, "Bạn có chắc chắn muốn đóng cửa sổ không?",
						"Xác nhận thoát", JOptionPane.YES_NO_OPTION);

				// Đóng cửa sổ nếu người dùng chọn "Yes"
				if (confirm == JOptionPane.YES_OPTION) {

					frame.dispose();
				}
			}
		});

		frame.setVisible(true);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == BtnAdd) {
			Add();
		} else if (e.getSource() == BtnClear) {
			Clear();
		} else if (e.getSource() == BtnDelete) {
			DeleteByID();
		} else if (e.getSource() == BtnEdit) {
			Edit();
		} else if (e.getSource() == BtnSearch) {
			SearchByName();
		} else if (e.getSource() == BtnReload) {
			loadAllData();
		} else if(e.getSource() == BtnBack)
		{
			Back();
		} else if(e.getSource() == BtnmnExportExcel)
		{
			exportToExcel();
		} else if(e.getSource() == BtnmnExit)
		{
			Exit();
		}

	}
	
	public void Exit()
	{
		frame.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {

				// Hiển thị hộp thoại xác nhận
				int confirm = JOptionPane.showConfirmDialog(frame, "Bạn có chắc chắn muốn đóng cửa sổ không?",
						"Xác nhận thoát", JOptionPane.YES_NO_OPTION);

				// Đóng cửa sổ nếu người dùng chọn "Yes"
				if (confirm == JOptionPane.YES_OPTION) {

					frame.dispose();
				}
			}
		});

	}
	
	public void Back()
	{
		this.jframe.setVisible(true);
		this.frame.dispose();
	}

	public void Add() {
		String SubjectName = this.textFieldName.getText();
		String Descript = this.textAreaMota.getText();

		if (SubjectName.equals("") || Descript.equals("") || comboBoxGV.getSelectedIndex() == -1
				|| comboBoxPPDanhGia.getSelectedIndex() == -1 || comboBoxSoLuongSV.getSelectedIndex() == -1
				|| comboBoxSoTC.getSelectedIndex() == -1) {
			JOptionPane.showMessageDialog(frame, "Vui lòng nhập đầy đủ thông tin!", "Chú Ý!",
					JOptionPane.ERROR_MESSAGE);
			return;
		}

		MonHoc monhoc = new MonHoc(SubjectName, Descript, (Integer) comboBoxSoTC.getSelectedItem(),
				(String) comboBoxGV.getSelectedItem(), (String) comboBoxPPDanhGia.getSelectedItem(),
				(Integer) comboBoxSoLuongSV.getSelectedItem());

		try {
			PrintWriter writer = new PrintWriter(this.socket.getOutputStream());
			for (int i = 0; i < 1; i++) {
				writer.println("ADDMH");
				writer.flush();
				try {
					Thread.sleep(10);
				} catch (InterruptedException ex) {
					Logger.getLogger(QuanLySV.class.getName()).log(Level.SEVERE, null, ex);
				}
			}

			ObjectOutputStream ooutput = new ObjectOutputStream(this.socket.getOutputStream());
			ooutput.writeObject(monhoc);
			ooutput.flush();

			BufferedReader reader = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
			String message = reader.readLine();

			System.out.println(message);

			if (message != null) {
				JOptionPane.showMessageDialog(frame, "Thêm môn học thành công", "Thành công!",
						JOptionPane.INFORMATION_MESSAGE);
				loadAllData();
			} else {
				JOptionPane.showMessageDialog(frame, "Thêm không thành công, Lỗi!", "Chú Ý!",
						JOptionPane.ERROR_MESSAGE);
			}
		} catch (IOException ex) {
			ex.printStackTrace();
			Logger.getLogger(QuanLySV.class.getName()).log(Level.SEVERE, null, ex);
		}

	}

	public void loadAllData() {
		try {

			PrintWriter writer = new PrintWriter(this.socket.getOutputStream());
			writer.println("SEARCHALLMH");
			writer.flush();

			timeLoadData = 1;

			ObjectInputStream oinput = new ObjectInputStream(this.socket.getInputStream());
			List<MonHoc> list = new ArrayList<MonHoc>();
			list = (List<MonHoc>) oinput.readObject();
			if (list.size() > 0) {
				TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<DefaultTableModel>(this.tbmodel);
				table.setRowSorter(sorter);

				sorter.setSortKeys(List.of(new RowSorter.SortKey(0, SortOrder.ASCENDING)));
				tbmodel.setRowCount(0);
				for (MonHoc monhoc : list) {

					tbmodel.addRow(new Object[] { monhoc.getId(), monhoc.getTenMonHoc(), monhoc.getMoTaMonHoc(),
							monhoc.getSoTinChi(), monhoc.getGiangVienPhuTrach(), monhoc.getPhuongPhapDanhGia(),
							monhoc.getSoLuongSinhVienToiDa() });
				}
			}

		} catch (Exception e) {
		}

	}

	public void LoadGV() {
		try {

			PrintWriter writer = new PrintWriter(this.socket.getOutputStream());
			writer.println("SEARCHALLGV");
			writer.flush();

			timeLoadData = 1;

			ObjectInputStream oinput = new ObjectInputStream(this.socket.getInputStream());
			List<GiangVien> list = new ArrayList<GiangVien>();
			list = (List<GiangVien>) oinput.readObject();

			if (list.size() > 0) {
				for (GiangVien giangvien : list) {
					comboBoxGV.addItem(giangvien.getTenGiangVien() + " có ID: " + giangvien.getMaGiangVien());
				}
			}

		} catch (Exception e) {
		}
	}

	public void fillData() {
		int row = table.getSelectedRow();
		if (row >= 0) {
			textFieldID.setText(table.getModel().getValueAt(row, 0).toString());
			textFieldName.setText(table.getModel().getValueAt(row, 1).toString());
			textAreaMota.setText(table.getModel().getValueAt(row, 2).toString());
			comboBoxSoTC.setSelectedItem(Integer.parseInt(table.getModel().getValueAt(row, 3).toString()));
			comboBoxGV.setSelectedItem(table.getModel().getValueAt(row, 4).toString());
			comboBoxPPDanhGia.setSelectedItem(table.getModel().getValueAt(row, 5).toString());
			comboBoxSoLuongSV.setSelectedItem(Integer.parseInt(table.getModel().getValueAt(row, 6).toString()));
		}
	}

	@Override
	public void valueChanged(ListSelectionEvent e) {
		fillData();
		BtnEdit.setEnabled(true);
		BtnAdd.setEnabled(false);
		BtnDelete.setEnabled(true);

	}

	public void Clear() {
		textFieldID.setText("");
		textFieldName.setText("");
		textAreaMota.setText("");
		comboBoxGV.setSelectedIndex(-1);
		comboBoxPPDanhGia.setSelectedIndex(-1);
		comboBoxSoLuongSV.setSelectedIndex(-1);
		comboBoxSoTC.setSelectedIndex(-1);
		BtnAdd.setEnabled(true);
		BtnDelete.setEnabled(false);
		BtnEdit.setEnabled(false);

	}

	public void DeleteByID() {
		int id = Integer.parseInt(textFieldID.getText());
		MonHoc mh = new MonHoc(id);

		try {
			PrintWriter writer = new PrintWriter(this.socket.getOutputStream());

			writer.println("DELETEMH");
			writer.flush();

			try {
				Thread.sleep(10);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			ObjectOutputStream ooutput = new ObjectOutputStream(this.socket.getOutputStream());
			ooutput.writeObject(mh);
			ooutput.flush();

			BufferedReader reader = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
			String message = reader.readLine();

			if (message != null) {
				JOptionPane.showMessageDialog(frame, "Xóa thành công", "Thành công!", JOptionPane.INFORMATION_MESSAGE);
				try {
					Thread.sleep(10);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				loadAllData();
			}

		} catch (IOException ex) {
			ex.printStackTrace();
		}

		Clear();

	}
	
	private void exportToExcel() {
		try {
			Workbook workbook = new XSSFWorkbook();
			Sheet sheet = workbook.createSheet("DataMH");

			// Lấy số lượng hàng và cột từ bảng
			int rowCount = table.getRowCount();
			int columnCount = table.getColumnCount();

			// Tiêu đề cột
			Row headerRow = sheet.createRow(0);
			for (int col = 0; col < columnCount; col++) {
				Cell cell = headerRow.createCell(col);
				cell.setCellValue(table.getColumnName(col));
			}

			// Dữ liệu từ bảng
			for (int row = 0; row < rowCount; row++) {
				Row sheetRow = sheet.createRow(row + 1);
				for (int col = 0; col < columnCount; col++) {
					Object value = table.getValueAt(row, col);
					Cell cell = sheetRow.createCell(col);
					if (value != null) {
						if (value instanceof String) {
							cell.setCellValue((String) value);
						} else if (value instanceof Integer) {
							cell.setCellValue((Integer) value);
						} else if (value instanceof Double) {
							cell.setCellValue((Double) value);
						}
					}
				}
			}

			String desktopPath = System.getProperty("user.home") + "/Desktop/";
			String excelFilePath = desktopPath + "DataMonHoc.xlsx";

			// Ghi workbook vào OutputStream (Excel file)

			try {
				FileOutputStream outputStream = new FileOutputStream(excelFilePath);
				workbook.write(outputStream);
			} catch (Exception e) {
				// TODO: handle exception
			}

			JOptionPane.showMessageDialog(this.frame, "Xuất file excel thành công!", "Success",
					JOptionPane.INFORMATION_MESSAGE);
			workbook.close();

		} catch (Exception e) {
			JOptionPane.showMessageDialog(this.frame, "Lỗi : " + e.getMessage(), "Error",
					JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
	}

	public void Edit() {
		String SubjectName = this.textFieldName.getText();
		String Descript = this.textAreaMota.getText();

		if (SubjectName.equals("") || Descript.equals("") || comboBoxGV.getSelectedIndex() == -1
				|| comboBoxPPDanhGia.getSelectedIndex() == -1 || comboBoxSoLuongSV.getSelectedIndex() == -1
				|| comboBoxSoTC.getSelectedIndex() == -1) {
			JOptionPane.showMessageDialog(frame, "Vui lòng nhập đầy đủ thông tin!", "Chú Ý!",
					JOptionPane.ERROR_MESSAGE);
			return;
		}

		MonHoc monhoc = new MonHoc(Integer.parseInt(textFieldID.getText()), SubjectName, Descript,
				(Integer) comboBoxSoTC.getSelectedItem(), (String) comboBoxGV.getSelectedItem(),
				(String) comboBoxPPDanhGia.getSelectedItem(), (Integer) comboBoxSoLuongSV.getSelectedItem());

		try {
			PrintWriter writer = new PrintWriter(this.socket.getOutputStream());
			for (int i = 0; i < 1; i++) {
				writer.println("EDITMH");
				writer.flush();
				try {
					Thread.sleep(10);
				} catch (InterruptedException ex) {
					Logger.getLogger(QuanLySV.class.getName()).log(Level.SEVERE, null, ex);
				}
			}

			ObjectOutputStream ooutput = new ObjectOutputStream(this.socket.getOutputStream());
			ooutput.writeObject(monhoc);
			ooutput.flush();

			BufferedReader reader = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
			String message = reader.readLine();

			System.out.println(message);

			if (message != null) {
				JOptionPane.showMessageDialog(frame, "Sửa môn học thành công", "Thành công!",
						JOptionPane.INFORMATION_MESSAGE);
				loadAllData();
			} else {
				JOptionPane.showMessageDialog(frame, "Sửa không thành công, Lỗi!", "Chú Ý!", JOptionPane.ERROR_MESSAGE);
			}
		} catch (IOException ex) {
			ex.printStackTrace();
			Logger.getLogger(QuanLySV.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

	public void SearchByName() {

		if (this.textFieldSearch.getText().equals("")) {
			JOptionPane.showMessageDialog(frame, "Vui lòng nhập ten môn học cần tìm kiếm! ", "Chú Ý!",
					JOptionPane.ERROR_MESSAGE);
		} else {

			try {
				PrintWriter writer = new PrintWriter(this.socket.getOutputStream());

				writer.println("SEARCHMHBYNAME");
				writer.flush();

				String name = textFieldSearch.getText();
				writer.println(name);
				writer.flush();

				List<MonHoc> list = new ArrayList<MonHoc>();

				ObjectInputStream oinput = new ObjectInputStream(this.socket.getInputStream());
				try {
					list = (List<MonHoc>) oinput.readObject();
				} catch (ClassNotFoundException ex) {
					ex.printStackTrace();
				}
				if (list.size() > 0) {

					tbmodel.setRowCount(0);
					for (MonHoc monhoc : list) {
						tbmodel.addRow(new Object[] { monhoc.getId(), monhoc.getTenMonHoc(), monhoc.getMoTaMonHoc(),
								monhoc.getSoTinChi(), monhoc.getGiangVienPhuTrach(), monhoc.getPhuongPhapDanhGia(),
								monhoc.getSoLuongSinhVienToiDa() });
					}
				} else {

					tbmodel.setRowCount(0);
					JOptionPane.showMessageDialog(frame, "Không có kết quả! ", "Chú Ý!", JOptionPane.PLAIN_MESSAGE);

				}

			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}

	}


	@Override
	public void run() {
		loadAllData();

		try {
			Thread.sleep(20);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		LoadGV();

	}
}
