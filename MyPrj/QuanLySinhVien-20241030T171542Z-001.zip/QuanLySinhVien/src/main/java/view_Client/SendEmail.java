package view_Client;

import java.awt.EventQueue;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.util.Properties;
import java.awt.Color;
import javax.swing.JTextPane;
import javax.swing.JTextArea;
import javax.swing.JSpinner;
import javax.swing.JToggleButton;
import javax.swing.JTree;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.JScrollBar;
import javax.swing.JButton;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SendEmail implements ActionListener {

	private JFrame frame, bossFrame;
	private String ToEmail;
	private JTextArea textAreaContent;
	private JButton BtnSend, BtnBack;

	/**
	 * Launch the application.
	 */

	/**
	 * Create the application.
	 */
	public SendEmail(String ToEmail, JFrame bossFrame) {
		this.ToEmail = ToEmail;
		this.bossFrame = bossFrame;
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {

		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedLookAndFeelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(255, 255, 240));
		frame.setBounds(100, 100, 450, 469);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JPanel panel = new JPanel();
		panel.setBackground(new Color(192, 192, 192));
		panel.setBounds(10, 64, 416, 358);
		frame.getContentPane().add(panel);
		panel.setLayout(null);

		JLabel lblNewLabel_1 = new JLabel("TỚI");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(20, 10, 50, 27);
		panel.add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel(ToEmail);
		lblNewLabel_2.setForeground(new Color(0, 0, 128));
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_2.setBackground(Color.WHITE);
		lblNewLabel_2.setBounds(69, 10, 275, 27);
		panel.add(lblNewLabel_2);

		JLabel lblNewLabel_3 = new JLabel("NỘI DUNG");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_3.setBounds(20, 48, 96, 27);
		panel.add(lblNewLabel_3);

		textAreaContent = new JTextArea();
		textAreaContent.setBounds(20, 80, 370, 209);
		panel.add(textAreaContent);

		BtnSend = new JButton("Gửi thông báo");
		BtnSend.addActionListener(this);
		BtnSend.setBackground(new Color(128, 128, 128));
		BtnSend.setBounds(95, 327, 120, 21);
		panel.add(BtnSend);

		BtnBack = new JButton("Trở về");
		BtnBack.addActionListener(this);
		BtnBack.setBounds(305, 327, 85, 21);
		panel.add(BtnBack);

		JLabel lblNewLabel = new JLabel("GỬI THÔNG BÁO");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel.setBounds(10, 10, 416, 44);
		frame.getContentPane().add(lblNewLabel);

		frame.setVisible(true);
	}

	public void Send() {

		BtnSend.setEnabled(false);
		final String from = "tongthuan15092003@gmail.com";
		final String passWord = "vplymroxjzluvxpx";
		// Thuộc tính
		Properties props = new Properties();
		props.put("mail.smtp.host", "smtp.gmail.com");// SMTP HOST
		props.put("mail.smtp.port", "587");// TSL 587, SSL 465
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.ssl.protocols", "TLSv1.2");

		// Create Authenticator
		Authenticator auth = new Authenticator() {
			@Override
			protected PasswordAuthentication getPasswordAuthentication() {
				// TODO Auto-generated method stub
				return new PasswordAuthentication(from, passWord);
			}

		};

		// phiên làm việc
		Session session = Session.getInstance(props, auth);

		// Tạo một tin nhắn
		MimeMessage msg = new MimeMessage(session);
		try {
			msg.addHeader("Content-type", "text/HTML; charset=UTF-8");
			msg.setFrom();
			msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(ToEmail, false));

			// Tiêu đề
			msg.setSubject("Hệ thống quản lý sinh viên điện tử");

			StringBuilder content = new StringBuilder();
			content.append("Thông báo từ giáo viên : \n");
			content.append(textAreaContent.getText());

			// Nội dung email
			msg.setText(content.toString(), "UTF-8");

			Transport.send(msg);

			JOptionPane.showMessageDialog(frame, "Đã gửi tin nhắn", "Thành công!", JOptionPane.INFORMATION_MESSAGE);

			BtnSend.setEnabled(true);

		} catch (AddressException ex) {
			JOptionPane.showMessageDialog(frame, "Địa chỉ email không hợp lệ!.", "Thất bại!",
					JOptionPane.ERROR_MESSAGE);
		} catch (MessagingException ex) {
			JOptionPane.showMessageDialog(frame, "Có lỗi trong quá trình gửi email!.", "Thất bại!",
					JOptionPane.ERROR_MESSAGE);
		} catch (Exception ex) {
			JOptionPane.showMessageDialog(frame, "Lỗi không xác định!.", "Thất bại!", JOptionPane.ERROR_MESSAGE);
		}
	}

	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource() == BtnSend) {
			Send();
		} else if (e.getSource() == BtnBack) {
			Back();
		}
	}

	private void Back() {
		// TODO Auto-generated method stub
		this.frame.dispose();
		this.bossFrame.setVisible(true);
	}
}
