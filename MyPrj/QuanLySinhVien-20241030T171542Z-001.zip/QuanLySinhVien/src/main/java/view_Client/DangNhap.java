package view_Client;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.io.Serializable;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.UIManager;

import model.User;

import javax.swing.JButton;
import javax.swing.JOptionPane;

public class DangNhap extends Thread implements ActionListener, Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private JFrame frmQunLSinh;
	private JTextField textField;
	private JPasswordField textField_1;
	private Socket socket;
	private JLabel lblNewLabel_4;
	private User user;
	private PrintWriter writer;
	String message_from_server = null;
	private int count = 0;
	private BufferedReader read;
	private static final String url = "localhost";
	private static final int PORT = 1829;
	private int countserverstate = 0;

	/**
	 * Launch the application.
	 */
	/**
	 * Create the application.
	 */
	public DangNhap() {

		initialize();
		this.start();

	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e) {
			e.printStackTrace();
		}

		frmQunLSinh = new JFrame();
		frmQunLSinh.getContentPane().setBackground(new Color(250, 250, 210));
		frmQunLSinh.setTitle("Quản lý sinh viên");
		frmQunLSinh.setBounds(100, 100, 514, 377);
		frmQunLSinh.setLocationRelativeTo(null);
		frmQunLSinh.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		frmQunLSinh.getContentPane().setLayout(null);
		frmQunLSinh.setResizable(false);
		JLabel lblNewLabel_1 = new JLabel("QUẢN LÝ SINH VIÊN");
		lblNewLabel_1.setForeground(Color.DARK_GRAY);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 35));
		lblNewLabel_1.setBackground(Color.WHITE);
		lblNewLabel_1.setBounds(67, 10, 394, 56);
		frmQunLSinh.getContentPane().add(lblNewLabel_1);

		JPanel panel = new JPanel();
		panel.setBounds(54, 64, 394, 244);
		frmQunLSinh.getContentPane().add(panel);
		panel.setLayout(null);

		JLabel lblNewLabel_2 = new JLabel("TÀI KHOẢN");
		lblNewLabel_2.setBounds(57, 73, 76, 13);
		panel.add(lblNewLabel_2);

		textField = new JTextField();
		textField.setBounds(143, 70, 154, 19);
		panel.add(textField);
		textField.setColumns(10);

		JLabel lblNewLabel_3 = new JLabel("MẬT KHẨU");
		lblNewLabel_3.setBounds(57, 102, 76, 13);
		panel.add(lblNewLabel_3);

		textField_1 = new JPasswordField();
		textField_1.setFont(new Font("Tahoma", Font.PLAIN, 10));
		textField_1.setBounds(143, 99, 154, 19);
		panel.add(textField_1);
		textField_1.setColumns(10);

		JButton btnNewButton = new JButton("ĐĂNG NHẬP");
		btnNewButton.setBackground(new Color(250, 250, 210));
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 10));
		btnNewButton.setBounds(95, 146, 96, 20);
		btnNewButton.addActionListener(this);
		panel.add(btnNewButton);

		JButton btnNewButton_1 = new JButton("ĐĂNG KÝ");
		btnNewButton_1.setForeground(new Color(220, 20, 60));
		btnNewButton_1.setBackground(new Color(0, 255, 255));
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 10));
		btnNewButton_1.setBounds(201, 146, 96, 21);
		btnNewButton_1.addActionListener(this);
		panel.add(btnNewButton_1);

		JLabel lblNewLabel = new JLabel("ĐĂNG NHẬP");
		lblNewLabel.setBounds(141, 16, 94, 44);
		panel.add(lblNewLabel);
		lblNewLabel.setForeground(new Color(0, 139, 139));
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel.setBackground(Color.WHITE);

		JButton btnNewButton_2 = new JButton("Quên mật khẩu");
		btnNewButton_2.setFont(new Font("Tahoma", Font.PLAIN, 8));
		btnNewButton_2.setBackground(new Color(211, 211, 211));
		btnNewButton_2.setBounds(168, 189, 96, 21);
		btnNewButton_2.addActionListener(this);
		panel.add(btnNewButton_2);

		lblNewLabel_4 = new JLabel("");
		lblNewLabel_4.setFont(new Font("Verdana", Font.PLAIN, 8));
		lblNewLabel_4.setBounds(0, 1, 174, 13);
		panel.add(lblNewLabel_4);

		JButton btnNewButton_3 = new JButton("Đổi mật khẩu");
		btnNewButton_3.addActionListener(this);
		btnNewButton_3.setBounds(274, 188, 96, 21);
		panel.add(btnNewButton_3);
		frmQunLSinh.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent windowEvent) {

				try {
					socket.close();

				} catch (Exception ex) {
					Logger.getLogger(DangNhap.class.getName()).log(Level.SEVERE, null, ex);
				}

				System.exit(0);
			}
		});
		frmQunLSinh.setVisible(true);

	}

	public void actionPerformed(ActionEvent e) {

		// Lấy hành động người dùng
		String src = e.getActionCommand();

		if (this.socket == null) {
			// Lần bật chương trình đầu tiên, đợi kết nối nếu socket = null
			JOptionPane.showMessageDialog(frmQunLSinh, "Không thể kết nối tới máy chủ, vui lòng đợi kết nối!", "Chú Ý!",
					JOptionPane.ERROR_MESSAGE);

			return;
		}

		this.user = new User();

		// Check xem server có hoạt động hay không
		if (src.equals("ĐĂNG NHẬP")) {
			Login();

		} else if (src.equals("ĐĂNG KÝ")) {
			Register();
		} else if (src.equals("Quên mật khẩu")) {
			ForgotPassword();

		} else if (src.equals("Đổi mật khẩu")) {
			ChangePassword();
		}

	}

	public void Login() {

		// Đưa ra cảnh báo nếu không nhập đầy đủ tài khoản hoặc mật khẩu
		if (((textField_1.getPassword().length <= 0) || (textField.getText().equals(""))) && this.socket != null) {
			JOptionPane.showMessageDialog(frmQunLSinh, "Vui lòng nhập đầy đủ thông tin tài khoản và mật khẩu!",
					"Chú Ý!", JOptionPane.ERROR_MESSAGE);
		} else {

			// Lấy các thông tin tài khoản mật khẩu từ các JtextField
			String userName = textField.getText() + "";
			char[] pass = textField_1.getPassword();
			this.user.setEmail(userName);
			String passWord = new String(pass);
			this.user.setPassWord(passWord);

			if (this.socket != null) {
				try {

					ObjectOutputStream ooutput = new ObjectOutputStream(this.socket.getOutputStream());
					ooutput.writeObject(user);

					DangNhapStatement dnst = new DangNhapStatement(socket, frmQunLSinh, this.user.getEmail(), url,
							PORT);
					dnst.start();
				} catch (IOException e1) {
					JOptionPane.showMessageDialog(frmQunLSinh,
							"Không thể kết nối tới máy chủ, vui lòng thoát chương trình!", "Chú Ý!",
							JOptionPane.ERROR_MESSAGE);
					this.lblNewLabel_4.setText("Máy chủ đã tắt");
				}
			}

		}

	}

	public void Register() {
		if (this.socket!=null) {
			frmQunLSinh.setVisible(false);
			new DangKy(frmQunLSinh, url, PORT);
		} else {
			JOptionPane.showMessageDialog(frmQunLSinh, "Không thể kết nối tới máy chủ!", "Chú Ý!",
					JOptionPane.ERROR_MESSAGE);
		}
	}

	public void ForgotPassword() {
		if (this.socket!=null) {
			frmQunLSinh.setVisible(false);
			new QuenMatKhau(frmQunLSinh, url, PORT);
		} else {
			JOptionPane.showMessageDialog(frmQunLSinh, "Không thể kết nối tới máy chủ!", "Chú Ý!",
					JOptionPane.ERROR_MESSAGE);
		}
	}

	public void ChangePassword() {
		if (this.socket!=null) {
			frmQunLSinh.setVisible(false);
			new DoiMatKhau(frmQunLSinh, url, PORT);
		} else {
			JOptionPane.showMessageDialog(frmQunLSinh, "Không thể kết nối tới máy chủ!", "Chú Ý!",
					JOptionPane.ERROR_MESSAGE);
		}
	}

	@Override
	public void run() {
		while (this.socket == null) {
			try {
				this.socket = new Socket(url, PORT);
				this.lblNewLabel_4.setText("Kết nối máy chủ thành công");
			} catch (Exception e) {
				// TODO: handle exception
				System.out.println("Khong the ket noi toi server");
				this.lblNewLabel_4.setText("Không thế kết nối đến máy chủ!");
			}
			try {
				Thread.sleep(1000);
			} catch (Exception ex) {
				ex.printStackTrace();

			}
		}

		if (this.socket != null) {
			try {
				writer = new PrintWriter(this.socket.getOutputStream());
				read = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
			} catch (IOException ex) {
				ex.printStackTrace();

				return;
			}
		}

		if(this.socket!=null)
		{
			writer.println("DANGNHAP");
			writer.flush();
		}

	}

	public static void main(String[] args) {
		new DangNhap();
	}
}
