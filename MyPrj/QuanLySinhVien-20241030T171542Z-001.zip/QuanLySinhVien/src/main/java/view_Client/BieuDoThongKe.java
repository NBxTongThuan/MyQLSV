package view_Client;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JProgressBar;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Dimension;
import javax.swing.JButton;

public class BieuDoThongKe implements ActionListener {

	private JFrame frame;
	private int khoang01, khoang12, khoang23, khoang34;
	private JButton BtnBack;
	private JFrame jframe;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					BieuDoThongKe window = new BieuDoThongKe(1, 2, 3, 4, null);
//					window.frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the application.
	 */
	public BieuDoThongKe(int k01, int k12, int k23, int k34, JFrame jframe) {
		this.khoang01 = k01;
		this.khoang12 = k12;
		this.khoang23 = k23;
		this.khoang34 = k34;
		this.jframe = jframe;
		initialize();
	}

	private CategoryDataset createDataset() {
		final String khoangGPA1 = "0.0-1.0";
		final String khoangGPA2 = "1.0-2.0";
		final String khoangGPA3 = "2.0-3.0";
		final String khoangGPA4 = "3.0-4.0";

		final DefaultCategoryDataset dataset = new DefaultCategoryDataset();

		dataset.addValue(khoang01, "Số lượng sinh viên", khoangGPA1);
		dataset.addValue(khoang12, "Số lượng sinh viên", khoangGPA2);
		dataset.addValue(khoang23, "Số lượng sinh viên", khoangGPA3);
		dataset.addValue(khoang34, "Số lượng sinh viên", khoangGPA4);

		return dataset;
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {

		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedLookAndFeelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		frame = new JFrame();
		frame.setBounds(100, 100, 784, 522);
		frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setTitle("THỐNG KÊ GPA");
		frame.setLocationRelativeTo(null);

		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(0, 0, 770, 443);
		frame.getContentPane().add(panel);
		panel.setLayout(new BorderLayout(0, 0));

		// Tạo dataset cho biểu đồ
		CategoryDataset dataset = createDataset();

		// Tạo biểu đồ cột từ dataset
		JFreeChart barChart = ChartFactory.createBarChart("Phân phối GPA của sinh viên", // Tiêu đề biểu đồ
				"Khoảng GPA", // Nhãn trục x
				"Số lượng sinh viên", // Nhãn trục y
				dataset, // Dataset
				PlotOrientation.VERTICAL, // Định dạng biểu đồ: dọc
				true, // Có hiển thị đường kẻ lưới không
				true, // Có hiển thị tooltip không
				false // Có hiển thị URL không
		);

		// Tạo panel biểu đồ và thêm vào JFrame
		ChartPanel chartPanel = new ChartPanel(barChart);
		chartPanel.setPreferredSize(new Dimension(800, 600));

		panel.add(chartPanel);

		BtnBack = new JButton("Trở về");
		BtnBack.addActionListener(this);
		BtnBack.setBounds(658, 454, 102, 21);
		frame.getContentPane().add(BtnBack);
		frame.setVisible(true);

	}

	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource() == BtnBack) {
			back();
		}
	}

	public void back() {
		this.frame.dispose();
		this.jframe.setVisible(true);
	}
}
