package view_Client;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.RowSorter;
import javax.swing.SortOrder;
import javax.swing.border.BevelBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JLabel;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.border.MatteBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.border.LineBorder;
import model.SinhVien;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import java.awt.Panel;
import java.awt.BorderLayout;
import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import javax.swing.JRadioButton;
import javax.swing.JComboBox;
import org.apache.poi.ss.usermodel.*;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

public class QuanLySV extends Thread implements ActionListener, ListSelectionListener {

	private JFrame frmQunLSinh;
	private JTextField textFieldSearchByField;
	private JTextField textFieldName;
	private JTextField textFieldGPA;
	private String userName;
	private Socket socketDN;
	private Socket mySocket;
	private JTable table;
	private DefaultTableModel tbmodel;
	private int timeLoadData = 0;
	private JTextField textFieldID;
	private JTextField textFieldNumberOfCredits;
	private JTextField textFieldCumulativeNumberOfCredits;
	private JTextField textFieldPhoneNumber;
	private JTextField textFieldEmail;
	private JRadioButton rbtM;
	private JRadioButton rbtFM;
	private JRadioButton rbtName;
	private JRadioButton rbtAddress;
	private JRadioButton rbtID;
	private ButtonGroup btgr1;
	private JComboBox<String> comboBoxMajor;
	private JButton LoadAllBtn;
	private JComboBox<Integer> comboBoxDayOfBirth, comboBoxMonthOfBirth, comboBoxDayAdmission, comboBoxMonthAdmission,
			comboBoxYearOfBirth, comboBoxYearOfAdmission;
	private JComboBox<String> comboBoxAddress;
	private JButton AddBtn, BtnQLGV, BtnQLMH, BtnEdit, BtnDelete, btnSendEmail, SearchBtn, ClearDataBtn,
			BtnSeeStatistics;
	private JMenuItem BtnmnExportExcel, BtnmnExit, BtnmnLogout;
	private int k01, k12, k23, k34;

	/**
	 * Launch the application.
	 */
	/**
	 * Create the application.
	 *
	 * @wbp.parser.entryPoint
	 */
	public QuanLySV(String userName, Socket socketDN, Socket socket) {
		this.userName = userName;
		this.socketDN = socketDN;
		this.mySocket = socket;

		this.tbmodel = new DefaultTableModel();
		initialize();
		this.start();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedLookAndFeelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

//		Frame
		frmQunLSinh = new JFrame();
		frmQunLSinh.setTitle("Quản lý sinh viên");
		frmQunLSinh.setBounds(100, 100, 1417, 766);
		frmQunLSinh.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmQunLSinh.getContentPane().setLayout(null);
		frmQunLSinh.setLocationRelativeTo(null);
		frmQunLSinh.setResizable(false);

		// EndFrame

		// JPanel
		JPanel panel = new JPanel();
		panel.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		panel.setBackground(new Color(255, 245, 238));
		panel.setBounds(26, 37, 334, 682);
		frmQunLSinh.getContentPane().add(panel);
		panel.setLayout(null);

		JPanel panel_2 = new JPanel();
		panel_2.setBorder(new MatteBorder(1, 1, 1, 1, (Color) Color.ORANGE));
		panel_2.setBounds(10, 48, 314, 41);
		panel.add(panel_2);
		panel_2.setLayout(null);

		JPanel panel_3 = new JPanel();
		panel_3.setBackground(Color.WHITE);
		panel_3.setBorder(new LineBorder(Color.CYAN));
		panel_3.setBounds(10, 140, 314, 530);
		panel.add(panel_3);
		panel_3.setLayout(null);

		Panel panel_1 = new Panel();
		panel_1.setBackground(new Color(255, 255, 255));
		panel_1.setBounds(387, 64, 1006, 621);

		// EndJPanel

//		Button

		SearchBtn = new JButton("Tìm kiếm");
		SearchBtn.addActionListener(this);
		SearchBtn.setBackground(Color.LIGHT_GRAY);
		SearchBtn.setFont(new Font("Tahoma", Font.PLAIN, 8));
		SearchBtn.setBounds(219, 9, 85, 20);
		panel_2.add(SearchBtn);

		AddBtn = new JButton("Thêm");
		AddBtn.addActionListener(this);
		AddBtn.setForeground(new Color(0, 0, 0));
		AddBtn.setFont(new Font("Tahoma", Font.PLAIN, 9));
		AddBtn.setBackground(Color.LIGHT_GRAY);
		AddBtn.setBounds(29, 449, 85, 21);
		panel_3.add(AddBtn);

		ClearDataBtn = new JButton("Xóa tất cả");
		ClearDataBtn.addActionListener(this);
		ClearDataBtn.setFont(new Font("Tahoma", Font.PLAIN, 8));
		ClearDataBtn.setBackground(Color.LIGHT_GRAY);
		ClearDataBtn.setBounds(219, 486, 85, 21);
		panel_3.add(ClearDataBtn);

		LoadAllBtn = new JButton("Reload Data");
		LoadAllBtn.setBounds(1293, 37, 100, 21);
		LoadAllBtn.addActionListener(this);
		frmQunLSinh.getContentPane().add(LoadAllBtn);

		BtnEdit = new JButton("Sửa");
		BtnEdit.addActionListener(this);
		BtnEdit.setBounds(124, 449, 85, 21);
		panel_3.add(BtnEdit);

		BtnDelete = new JButton("Xóa");
		BtnDelete.setBounds(219, 449, 85, 21);
		BtnDelete.addActionListener(this);
		panel_3.add(BtnDelete);

		btnSendEmail = new JButton("Gửi email");
		btnSendEmail.addActionListener(this);
		btnSendEmail.setBounds(124, 485, 85, 21);
		panel_3.add(btnSendEmail);

		BtnEdit.setEnabled(false);
		BtnDelete.setEnabled(false);
		btnSendEmail.setEnabled(false);

//		EndButton

		// TextField
		textFieldSearchByField = new JTextField();
		textFieldSearchByField.setToolTipText("Nhập tên");
		textFieldSearchByField.setBounds(55, 10, 154, 19);
		panel_2.add(textFieldSearchByField);
		textFieldSearchByField.setColumns(10);

		textFieldName = new JTextField();
		textFieldName.setBounds(126, 40, 178, 19);
		panel_3.add(textFieldName);
		textFieldName.setColumns(10);

		textFieldGPA = new JTextField();
		textFieldGPA.setBounds(126, 393, 47, 19);
		panel_3.add(textFieldGPA);
		textFieldGPA.setColumns(10);

		textFieldID = new JTextField();
		textFieldID.setEditable(false);
		textFieldID.setColumns(10);
		textFieldID.setBounds(126, 14, 178, 19);
		panel_3.add(textFieldID);

		textFieldNumberOfCredits = new JTextField();
		textFieldNumberOfCredits.setColumns(10);
		textFieldNumberOfCredits.setBounds(126, 297, 78, 19);
		panel_3.add(textFieldNumberOfCredits);

		textFieldCumulativeNumberOfCredits = new JTextField();
		textFieldCumulativeNumberOfCredits.setColumns(10);
		textFieldCumulativeNumberOfCredits.setBounds(126, 335, 78, 19);
		panel_3.add(textFieldCumulativeNumberOfCredits);

		textFieldPhoneNumber = new JTextField();
		textFieldPhoneNumber.setColumns(10);
		textFieldPhoneNumber.setBounds(126, 364, 111, 19);
		panel_3.add(textFieldPhoneNumber);

		textFieldEmail = new JTextField();
		textFieldEmail.setColumns(10);
		textFieldEmail.setBounds(126, 268, 178, 19);
		panel_3.add(textFieldEmail);

//EndTextField

		// ComboBox

		comboBoxMajor = new JComboBox<String>();
		comboBoxMajor.setBounds(126, 171, 178, 21);
		panel_3.add(comboBoxMajor);

		comboBoxDayOfBirth = new JComboBox<Integer>();
		comboBoxDayOfBirth.setBackground(new Color(255, 250, 240));
		comboBoxDayOfBirth.setBounds(127, 86, 50, 20);
		panel_3.add(comboBoxDayOfBirth);

		comboBoxMonthOfBirth = new JComboBox<Integer>();
		comboBoxMonthOfBirth.setBackground(new Color(255, 250, 240));
		comboBoxMonthOfBirth.setBounds(187, 86, 50, 20);
		panel_3.add(comboBoxMonthOfBirth);

		comboBoxDayAdmission = new JComboBox<Integer>();
		comboBoxDayAdmission.setBackground(new Color(255, 250, 240));
		comboBoxDayAdmission.setBounds(127, 226, 50, 20);
		panel_3.add(comboBoxDayAdmission);

		comboBoxMonthAdmission = new JComboBox<Integer>();
		comboBoxMonthAdmission.setBackground(new Color(255, 250, 240));
		comboBoxMonthAdmission.setBounds(187, 226, 50, 20);
		panel_3.add(comboBoxMonthAdmission);

		comboBoxYearOfBirth = new JComboBox<Integer>();
		comboBoxYearOfBirth.setBackground(new Color(255, 250, 240));
		comboBoxYearOfBirth.setBounds(247, 86, 50, 20);
		panel_3.add(comboBoxYearOfBirth);

		comboBoxYearOfAdmission = new JComboBox<Integer>();
		comboBoxYearOfAdmission.setBackground(new Color(255, 250, 240));
		comboBoxYearOfAdmission.setBounds(247, 226, 50, 20);
		panel_3.add(comboBoxYearOfAdmission);

		comboBoxAddress = new JComboBox<String>();
		comboBoxAddress.setBounds(126, 140, 178, 21);
		panel_3.add(comboBoxAddress);

		for (int i = 1; i <= 31; i++) {
			comboBoxDayOfBirth.addItem(i);
			comboBoxDayAdmission.addItem(i);
		}

		for (int i = 1; i <= 12; i++) {
			comboBoxMonthOfBirth.addItem(i);
			comboBoxMonthAdmission.addItem(i);
		}

		int currentYear = Calendar.getInstance().get(Calendar.YEAR);

		for (int i = currentYear - 12; i >= 1900; i--) {
			comboBoxYearOfBirth.addItem(i);

		}
		for (int i = currentYear; i >= 1912; i--) {
			comboBoxYearOfAdmission.addItem(i);

		}

		String[] provinces = { "An Giang", "Bà Rịa - Vũng Tàu", "Bắc Giang", "Bắc Kạn", "Bạc Liêu", "Bắc Ninh",
				"Bến Tre", "Bình Định", "Bình Dương", "Bình Phước", "Bình Thuận", "Cà Mau", "Cần Thơ", "Cao Bằng",
				"Đà Nẵng", "Đắk Lắk", "Đắk Nông", "Điện Biên", "Đồng Nai", "Đồng Tháp", "Gia Lai", "Hà Giang", "Hà Nam",
				"Hà Nội", "Hà Tĩnh", "Hải Dương", "Hải Phòng", "Hậu Giang", "Hòa Bình", "Hưng Yên", "Khánh Hòa",
				"Kiên Giang", "Kon Tum", "Lai Châu", "Lâm Đồng", "Lạng Sơn", "Lào Cai", "Long An", "Nam Định",
				"Nghệ An", "Ninh Bình", "Ninh Thuận", "Phú Thọ", "Phú Yên", "Quảng Bình", "Quảng Nam", "Quảng Ngãi",
				"Quảng Ninh", "Quảng Trị", "Sóc Trăng", "Sơn La", "Tây Ninh", "Thái Bình", "Thái Nguyên", "Thanh Hóa",
				"Thừa Thiên Huế", "Tiền Giang", "TP Hồ Chí Minh", "Trà Vinh", "Tuyên Quang", "Vĩnh Long", "Vĩnh Phúc",
				"Yên Bái" };

		for (String province : provinces) {
			comboBoxAddress.addItem(province);
		}

		String[] majors = { "Công nghệ thông tin", "Kỹ thuật phần mềm", "Mạng máy tính và truyền thông",
				"An toàn thông tin", "Công nghệ kỹ thuật điện, điện tử", "Công nghệ kỹ thuật cơ điện tử",
				"Công nghệ kỹ thuật ô tô", "Công nghệ kỹ thuật cơ khí", "Công nghệ kỹ thuật nhiệt",
				"Công nghệ kỹ thuật điện tử - viễn thông", "Kỹ thuật điều khiển và tự động hóa", "Kế toán",
				"Quản trị kinh doanh", "Tài chính - Ngân hàng", "Marketing", "Quản trị nhân lực", "Kinh tế quốc tế",
				"Ngôn ngữ Anh", "Ngôn ngữ Trung Quốc", "Ngôn ngữ Nhật", "Công nghệ dệt, may", "Thiết kế thời trang",
				"Công nghệ hóa học", "Công nghệ sinh học", "Quản lý công nghiệp", "Logistics và quản lý chuỗi cung ứng",
				"Thương mại điện tử", "Khoa học máy tính", "Truyền thông và mạng máy tính" };

		for (String major : majors) {
			comboBoxMajor.addItem(major);
		}

		comboBoxAddress.setSelectedIndex(-1);
		comboBoxDayAdmission.setSelectedIndex(-1);
		comboBoxDayOfBirth.setSelectedIndex(-1);
		comboBoxMajor.setSelectedIndex(-1);
		comboBoxMonthAdmission.setSelectedIndex(-1);
		comboBoxMonthOfBirth.setSelectedIndex(-1);
		comboBoxYearOfAdmission.setSelectedIndex(-1);
		comboBoxYearOfBirth.setSelectedIndex(-1);

		JLabel NumberOfCreditsLb = new JLabel("Số tín chỉ");
		NumberOfCreditsLb.setFont(new Font("Tahoma", Font.PLAIN, 12));
		NumberOfCreditsLb.setBounds(10, 299, 120, 13);
		panel_3.add(NumberOfCreditsLb);

		JLabel DateOfBirthLb = new JLabel("Ngày sinh");
		DateOfBirthLb.setFont(new Font("Tahoma", Font.PLAIN, 12));
		DateOfBirthLb.setBounds(10, 90, 120, 13);
		panel_3.add(DateOfBirthLb);

		JLabel AddressLb = new JLabel("Địa chỉ");
		AddressLb.setFont(new Font("Tahoma", Font.PLAIN, 12));
		AddressLb.setBounds(10, 148, 120, 13);
		panel_3.add(AddressLb);

		JLabel FullNameLb = new JLabel("Họ và tên");
		FullNameLb.setFont(new Font("Tahoma", Font.PLAIN, 12));
		FullNameLb.setBounds(10, 43, 120, 13);
		panel_3.add(FullNameLb);

		JLabel EmailLb = new JLabel("Email");
		EmailLb.setFont(new Font("Tahoma", Font.PLAIN, 12));
		EmailLb.setBounds(10, 270, 120, 13);
		panel_3.add(EmailLb);

		JLabel SexLb = new JLabel("Giới tính");
		SexLb.setFont(new Font("Tahoma", Font.PLAIN, 12));
		SexLb.setBounds(10, 117, 120, 13);
		panel_3.add(SexLb);

		JLabel IDLb = new JLabel("Mã sinh viên");
		IDLb.setFont(new Font("Tahoma", Font.PLAIN, 12));
		IDLb.setBounds(10, 17, 120, 13);
		panel_3.add(IDLb);

		JLabel MajorLb = new JLabel("Ngành học");
		MajorLb.setFont(new Font("Tahoma", Font.PLAIN, 12));
		MajorLb.setBounds(10, 175, 120, 13);
		panel_3.add(MajorLb);

		JLabel DateAdmissionLb = new JLabel("Ngày nhập học");
		DateAdmissionLb.setFont(new Font("Tahoma", Font.PLAIN, 12));
		DateAdmissionLb.setBounds(10, 230, 120, 13);
		panel_3.add(DateAdmissionLb);

		JLabel GPALb = new JLabel("Điểm GPA");
		GPALb.setFont(new Font("Tahoma", Font.PLAIN, 12));
		GPALb.setBounds(10, 396, 120, 13);
		panel_3.add(GPALb);

		JLabel lblNewLabel_8_3_1_1 = new JLabel("Số tín chỉ tích lũy");
		lblNewLabel_8_3_1_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_8_3_1_1.setBounds(10, 337, 120, 13);
		panel_3.add(lblNewLabel_8_3_1_1);

		JLabel SearchLb = new JLabel("Tìm kiếm theo:");
		SearchLb.setBounds(10, 25, 100, 13);
		panel.add(SearchLb);
		SearchLb.setFont(new Font("Tahoma", Font.ITALIC, 12));

		JLabel FillSearchLb = new JLabel("Nhập ");
		FillSearchLb.setFont(new Font("Tahoma", Font.PLAIN, 9));
		FillSearchLb.setBounds(10, 10, 51, 19);
		panel_2.add(FillSearchLb);

		JLabel PhoneNumberLb = new JLabel("Số điện thoại");
		PhoneNumberLb.setFont(new Font("Tahoma", Font.PLAIN, 12));
		PhoneNumberLb.setBounds(10, 367, 120, 13);
		panel_3.add(PhoneNumberLb);

		JLabel DayOfBirthLb = new JLabel("Ngày");
		DayOfBirthLb.setBounds(126, 69, 45, 13);
		panel_3.add(DayOfBirthLb);

		JLabel MonthOfBirthLb = new JLabel("Tháng");
		MonthOfBirthLb.setBounds(187, 69, 45, 13);
		panel_3.add(MonthOfBirthLb);

		JLabel YearOfBirthLb = new JLabel("Năm");
		YearOfBirthLb.setBounds(247, 69, 45, 13);
		panel_3.add(YearOfBirthLb);

		JLabel DayAdmissionLb = new JLabel("Ngày");
		DayAdmissionLb.setBounds(128, 203, 45, 13);
		panel_3.add(DayAdmissionLb);

		JLabel MonthAdmissonLb = new JLabel("Tháng");
		MonthAdmissonLb.setBounds(185, 203, 45, 13);
		panel_3.add(MonthAdmissonLb);

		JLabel YearAdmissonLb = new JLabel("Năm");
		YearAdmissonLb.setBounds(248, 203, 45, 13);
		panel_3.add(YearAdmissonLb);

		JLabel lblNewLabel_4 = new JLabel("Các hành động");
		lblNewLabel_4.setBounds(10, 117, 100, 13);
		panel.add(lblNewLabel_4);
		lblNewLabel_4.setFont(new Font("Tahoma", Font.ITALIC, 12));

		JLabel lblNewLabel = new JLabel("XIN CHÀO");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel.setForeground(Color.BLUE);
		lblNewLabel.setBounds(26, 10, 100, 28);
		frmQunLSinh.getContentPane().add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel(this.userName);
		lblNewLabel_1.setForeground(new Color(255, 0, 0));
		lblNewLabel_1.setFont(new Font("Tahoma", Font.ITALIC, 15));
		lblNewLabel_1.setBounds(107, 10, 253, 28);
		frmQunLSinh.getContentPane().add(lblNewLabel_1);

		JLabel lblNewLabel_9 = new JLabel("DANH SÁCH SINH VIÊN");
		lblNewLabel_9.setForeground(Color.BLUE);
		lblNewLabel_9.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_9.setBounds(387, 37, 246, 21);
		frmQunLSinh.getContentPane().add(lblNewLabel_9);

		// EndLabel

		// RadioButton & ButtonGroup
		rbtName = new JRadioButton("Tên");
		rbtName.setBounds(102, 21, 57, 21);
		panel.add(rbtName);

		rbtAddress = new JRadioButton("Địa chỉ");
		rbtAddress.setBounds(267, 22, 57, 21);
		panel.add(rbtAddress);

		rbtID = new JRadioButton("ID");
		rbtID.setBounds(185, 22, 57, 21);
		panel.add(rbtID);

		ButtonGroup btgr2 = new ButtonGroup();
		btgr2.add(rbtName);
		btgr2.add(rbtAddress);
		btgr2.add(rbtID);

		rbtM = new JRadioButton("Nam");
		rbtM.setBackground(Color.WHITE);
		rbtM.setBounds(126, 113, 47, 21);
		panel_3.add(rbtM);

		rbtFM = new JRadioButton("Nữ");
		rbtFM.setBackground(Color.WHITE);
		rbtFM.setBounds(175, 113, 47, 21);
		panel_3.add(rbtFM);

		btgr1 = new ButtonGroup();
		btgr1.add(rbtM);
		btgr1.add(rbtFM);

		// EndRadioButton & ButtonGroup

		// Table

		tbmodel.addColumn("Mã sinh viên");
		tbmodel.addColumn("Họ và tên");
		tbmodel.addColumn("Ngày sinh");
		tbmodel.addColumn("Giới tính");
		tbmodel.addColumn("Địa chỉ");
		tbmodel.addColumn("Ngành học");
		tbmodel.addColumn("Ngày nhập học");
		tbmodel.addColumn("email");
		tbmodel.addColumn("Số điện thoại");
		tbmodel.addColumn("Số tín chỉ");
		tbmodel.addColumn("Số TC TL");
		tbmodel.addColumn("GPA");
		table = new JTable(tbmodel);
		table.getSelectionModel().addListSelectionListener(this);
		JScrollPane scrollPane = new JScrollPane(table);
		panel_1.setLayout(new BorderLayout(0, 0));
		panel_1.add(scrollPane, BorderLayout.CENTER);

		TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<DefaultTableModel>(this.tbmodel);
		table.setRowSorter(sorter);

		sorter.setSortKeys(List.of(new RowSorter.SortKey(0, SortOrder.ASCENDING)));

		// EndTable

		frmQunLSinh.getContentPane().add(panel_1);

		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(387, 10, 40, 22);
		frmQunLSinh.getContentPane().add(menuBar);

		JMenu mnNewMenu = new JMenu("Menu");
		menuBar.add(mnNewMenu);
		mnNewMenu.setBackground(Color.DARK_GRAY);

		BtnmnExportExcel = new JMenuItem("Xuất File Excel");
		mnNewMenu.add(BtnmnExportExcel);
		BtnmnExportExcel.addActionListener(this);

		BtnmnExit = new JMenuItem("Thoát");
		mnNewMenu.add(BtnmnExit);
		BtnmnExit.addActionListener(this);

		BtnmnLogout = new JMenuItem("Đăng Xuất");
		mnNewMenu.add(BtnmnLogout);

		BtnSeeStatistics = new JButton("Xem thống kê GPA");
		BtnSeeStatistics.addActionListener(this);
		BtnSeeStatistics.setBounds(1158, 37, 125, 21);
		frmQunLSinh.getContentPane().add(BtnSeeStatistics);

		BtnQLMH = new JButton("Sang QLMH");
		BtnQLMH.addActionListener(this);
		BtnQLMH.setBounds(1270, 698, 123, 21);
		frmQunLSinh.getContentPane().add(BtnQLMH);

		BtnQLGV = new JButton("Sang QLGV");
		BtnQLGV.addActionListener(this);
		BtnQLGV.setBounds(1135, 698, 125, 21);
		frmQunLSinh.getContentPane().add(BtnQLGV);
		BtnmnLogout.addActionListener(this);

//		menuBar.add(mnNewMenu);

		frmQunLSinh.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {

				// Hiển thị hộp thoại xác nhận
				int confirm = JOptionPane.showConfirmDialog(frmQunLSinh, "Bạn có chắc chắn muốn đóng cửa sổ không?",
						"Xác nhận thoát", JOptionPane.YES_NO_OPTION);

				// Đóng cửa sổ nếu người dùng chọn "Yes"
				if (confirm == JOptionPane.YES_OPTION) {

					frmQunLSinh.dispose();
				}
			}
		});

		frmQunLSinh.setVisible(true);
	}

	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == BtnmnLogout) {
			Logout();
		} else if (e.getSource() == AddBtn) {
			Add();
		} else if (e.getSource() == SearchBtn && timeLoadData == 1) {
			if (rbtName.isSelected()) {
				SearchByName();
			} else if (rbtID.isSelected()) {
				SearchByID();
			} else if (rbtAddress.isSelected()) {
				SearchByAddress();
			} else {
				JOptionPane.showMessageDialog(frmQunLSinh, "Vui lòng chọn loại tìm kiếm", "Chú Ý!",
						JOptionPane.ERROR_MESSAGE);
			}
		} else if (e.getSource() == ClearDataBtn) {
			ClearData();
		} else if (e.getSource() == LoadAllBtn) {
			loadAllData();
		} else if (e.getSource() == BtnDelete) {
			Delete();
		} else if (e.getSource() == BtnEdit) {
			Edit();
		} else if (e.getSource() == btnSendEmail) {
			sendEmail();
		} else if (e.getSource() == BtnmnExportExcel) {
			exportToExcel();
		} else if (e.getSource() == BtnmnExit) {
			Exit();
		} else if (e.getSource() == BtnSeeStatistics) {
			new BieuDoThongKe(k01, k12, k23, k34, frmQunLSinh);
		} else if (e.getSource() == BtnQLMH) {
			QLMH();
		} else if (e.getSource() == BtnQLGV) {
			QLGV();
		}
	}

	private void Exit() {
		System.exit(0);
	}

	public void Logout() {
		PrintWriter writer;
		try {
			writer = new PrintWriter(this.mySocket.getOutputStream());
			writer.println("DANGXUAT");
			writer.flush();
		} catch (IOException ex) {
			Logger.getLogger(QuanLySV.class.getName()).log(Level.SEVERE, null, ex);
		}

		try {
			this.mySocket.close();
			if (this.mySocket.isClosed() == true) {
				System.out.println("dong socket quan ly");
			}
			this.socketDN.close();
		} catch (IOException ex) {
			Logger.getLogger(QuanLySV.class.getName()).log(Level.SEVERE, null, ex);
		}
		frmQunLSinh.dispose();
		new DangNhap();
	}

	public void Add() {

		String studentName = this.textFieldName.getText();
		String numberOfCredits = this.textFieldNumberOfCredits.getText();
		String cumulativeNumberOfCredits = this.textFieldCumulativeNumberOfCredits.getText();
		String PhoneNumber = this.textFieldPhoneNumber.getText();
		String Email = this.textFieldEmail.getText();
		String ScoreGPA = this.textFieldGPA.getText();

		if (studentName.equals("") || ScoreGPA.equals("") || (rbtM.isSelected() == false & rbtFM.isSelected() == false)
				|| comboBoxDayOfBirth.getSelectedIndex() == -1 || comboBoxDayAdmission.getSelectedIndex() == -1
				|| comboBoxMajor.getSelectedIndex() == -1 || comboBoxMonthAdmission.getSelectedIndex() == -1
				|| comboBoxMonthOfBirth.getSelectedIndex() == -1 || comboBoxYearOfBirth.getSelectedIndex() == -1
				|| comboBoxYearOfAdmission.getSelectedIndex() == -1 || comboBoxAddress.getSelectedIndex() == -1
				|| numberOfCredits.equals("") || cumulativeNumberOfCredits.equals("") || PhoneNumber.equals("")
				|| Email.equals("") || ScoreGPA.equals("")) {
			JOptionPane.showMessageDialog(frmQunLSinh, "Vui lòng nhập đầy đủ thông tin!", "Chú Ý!",
					JOptionPane.ERROR_MESSAGE);

			return;
		}

		int dayOfBirth = (Integer) comboBoxDayOfBirth.getSelectedItem();
		int monthOfBirth = (Integer) comboBoxMonthOfBirth.getSelectedItem();
		int yearOfBirth = (Integer) comboBoxYearOfBirth.getSelectedItem();

		if (CheckDate.checkDate(dayOfBirth, monthOfBirth, yearOfBirth) == false) {
			JOptionPane.showMessageDialog(frmQunLSinh, "Ngày sinh bạn vừa nhập không hợp lệ! ", "Chú Ý!",
					JOptionPane.ERROR_MESSAGE);
			return;
		}

		int dayOfAdmission = (Integer) comboBoxDayAdmission.getSelectedItem();
		int monthOfAdmission = (Integer) comboBoxMonthAdmission.getSelectedItem();
		int yearOfAdmission = (Integer) comboBoxYearOfAdmission.getSelectedItem();

		if (CheckDate.checkDate(dayOfAdmission, monthOfAdmission, yearOfAdmission) == false) {
			JOptionPane.showMessageDialog(frmQunLSinh, "Ngày nhập học bạn vừa nhập không hợp lệ! ", "Chú Ý!",
					JOptionPane.ERROR_MESSAGE);
			return;
		}

		if (yearOfAdmission - yearOfBirth < 16) {
			JOptionPane.showMessageDialog(frmQunLSinh,
					"Ngày nhập học bạn vừa nhập không hợp lệ, xem lại ngày sinh và ngày nhập học! ", "Chú Ý!",
					JOptionPane.ERROR_MESSAGE);
			return;
		}

		String emailregex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:gmail)\\.(?:com)$";
		if (Email.matches(emailregex) == false) {
			JOptionPane.showMessageDialog(frmQunLSinh, "Email bạn vừa nhập không hợp lệ !", "Chú Ý!",
					JOptionPane.ERROR_MESSAGE);
			return;
		}

		String Creditspattern = "^(0|[1-9]\\d{0,2})$";

		if (numberOfCredits.matches(Creditspattern) == false) {
			JOptionPane.showMessageDialog(frmQunLSinh, "Vui lòng nhập số tín chỉ nhỏ hơn 300 !", "Chú Ý!",
					JOptionPane.ERROR_MESSAGE);

			return;
		}

		if (cumulativeNumberOfCredits.matches(Creditspattern) == false) {
			JOptionPane.showMessageDialog(frmQunLSinh, "Vui lòng nhập số tín chỉ tích nhỏ hơn 300 !", "Chú Ý!",
					JOptionPane.ERROR_MESSAGE);

			return;
		}

		String GPAregex = "^(4(\\.0{1,2})?|[0-3](\\.\\d{1,2})?)$";
		if (ScoreGPA.matches(GPAregex) == false) {
			JOptionPane.showMessageDialog(frmQunLSinh,
					"Vui lòng nhập điểm theo đúng định dạng số thực lớn hơn hoặc bằng 0 và nhỏ hơn hoặc bằng 4.0 !",
					"Chú Ý!", JOptionPane.ERROR_MESSAGE);
			return;
		}

		String gender;
		if (rbtM.isSelected() == true) {
			gender = "Nam";
		} else {
			gender = "Nữ";
		}
		LocalDate StudentDateOfBirth = LocalDate.of(yearOfBirth, monthOfBirth, dayOfBirth);
		LocalDate StudentDateAdmission = LocalDate.of(yearOfAdmission, monthOfAdmission, dayOfAdmission);
		String studentAddress = (String) comboBoxAddress.getSelectedItem();
		String major = (String) comboBoxMajor.getSelectedItem();
		int NumberOfCredits = Integer.parseInt(numberOfCredits);
		int CumulativeNumberOfCredits = Integer.parseInt(cumulativeNumberOfCredits);
		double GPA = Double.parseDouble(ScoreGPA);

		try {
			PrintWriter writer = new PrintWriter(this.mySocket.getOutputStream());
			for (int i = 0; i < 1; i++) {
				writer.println("ADD");
				writer.flush();
				try {
					Thread.sleep(10);
				} catch (InterruptedException ex) {
					Logger.getLogger(QuanLySV.class.getName()).log(Level.SEVERE, null, ex);
				}
			}

			SinhVien sinhvien = new SinhVien(studentName, StudentDateOfBirth, gender, studentAddress, major,
					StudentDateAdmission, Email, PhoneNumber, NumberOfCredits, CumulativeNumberOfCredits, GPA);
			ObjectOutputStream ooutput = new ObjectOutputStream(this.mySocket.getOutputStream());
			ooutput.writeObject(sinhvien);
			ooutput.flush();

			BufferedReader reader = new BufferedReader(new InputStreamReader(this.mySocket.getInputStream()));
			String message = reader.readLine();

			if (message != null) {
				JOptionPane.showMessageDialog(frmQunLSinh, "Thêm sinh viên thành công", "Thành công!",
						JOptionPane.INFORMATION_MESSAGE);
				loadAllData();
			}

		} catch (IOException ex) {
			ex.printStackTrace();
			Logger.getLogger(QuanLySV.class.getName()).log(Level.SEVERE, null, ex);
		}

		AddBtn.setEnabled(true);
		BtnEdit.setEnabled(false);
		btnSendEmail.setEnabled(false);
		BtnDelete.setEnabled(false);

	}

	public void Edit() {

		String studentName = this.textFieldName.getText();
		String numberOfCredits = this.textFieldNumberOfCredits.getText();
		String cumulativeNumberOfCredits = this.textFieldCumulativeNumberOfCredits.getText();
		String PhoneNumber = this.textFieldPhoneNumber.getText();
		String Email = this.textFieldEmail.getText();
		String ScoreGPA = this.textFieldGPA.getText();

		if (studentName.equals("") || ScoreGPA.equals("") || (rbtM.isSelected() == false & rbtFM.isSelected() == false)
				|| comboBoxDayOfBirth.getSelectedIndex() == -1 || comboBoxDayAdmission.getSelectedIndex() == -1
				|| comboBoxMajor.getSelectedIndex() == -1 || comboBoxMonthAdmission.getSelectedIndex() == -1
				|| comboBoxMonthOfBirth.getSelectedIndex() == -1 || comboBoxYearOfBirth.getSelectedIndex() == -1
				|| comboBoxYearOfAdmission.getSelectedIndex() == -1 || comboBoxAddress.getSelectedIndex() == -1
				|| numberOfCredits.equals("") || cumulativeNumberOfCredits.equals("") || PhoneNumber.equals("")
				|| Email.equals("") || ScoreGPA.equals("")) {
			JOptionPane.showMessageDialog(frmQunLSinh, "Vui lòng nhập đầy đủ thông tin!", "Chú Ý!",
					JOptionPane.ERROR_MESSAGE);

			return;
		}

		int dayOfBirth = (Integer) comboBoxDayOfBirth.getSelectedItem();
		int monthOfBirth = (Integer) comboBoxMonthOfBirth.getSelectedItem();
		int yearOfBirth = (Integer) comboBoxYearOfBirth.getSelectedItem();

		if (CheckDate.checkDate(dayOfBirth, monthOfBirth, yearOfBirth) == false) {
			JOptionPane.showMessageDialog(frmQunLSinh, "Ngày sinh bạn vừa nhập không hợp lệ! ", "Chú Ý!",
					JOptionPane.ERROR_MESSAGE);
			return;
		}

		int dayOfAdmission = (Integer) comboBoxDayAdmission.getSelectedItem();
		int monthOfAdmission = (Integer) comboBoxMonthAdmission.getSelectedItem();
		int yearOfAdmission = (Integer) comboBoxYearOfAdmission.getSelectedItem();

		if (CheckDate.checkDate(dayOfAdmission, monthOfAdmission, yearOfAdmission) == false) {
			JOptionPane.showMessageDialog(frmQunLSinh, "Ngày nhập học bạn vừa nhập không hợp lệ! ", "Chú Ý!",
					JOptionPane.ERROR_MESSAGE);
			return;
		}

		if (yearOfAdmission - yearOfBirth < 16) {
			JOptionPane.showMessageDialog(frmQunLSinh,
					"Ngày nhập học bạn vừa nhập không hợp lệ, xem lại ngày sinh và ngày nhập học! ", "Chú Ý!",
					JOptionPane.ERROR_MESSAGE);
			return;
		}

		String emailregex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:gmail)\\.(?:com)$";
		if (Email.matches(emailregex) == false) {
			JOptionPane.showMessageDialog(frmQunLSinh, "Email bạn vừa nhập không hợp lệ !", "Chú Ý!",
					JOptionPane.ERROR_MESSAGE);
			return;
		}

		String Creditspattern = "^(0|[1-9]\\d{0,2})$";

		if (numberOfCredits.matches(Creditspattern) == false) {
			JOptionPane.showMessageDialog(frmQunLSinh, "Vui lòng nhập số tín chỉ nhỏ hơn 300 !", "Chú Ý!",
					JOptionPane.ERROR_MESSAGE);

			return;
		}

		if (cumulativeNumberOfCredits.matches(Creditspattern) == false) {
			JOptionPane.showMessageDialog(frmQunLSinh, "Vui lòng nhập số tín chỉ tích lũy nhỏ hơn 300 !", "Chú Ý!",
					JOptionPane.ERROR_MESSAGE);

			return;
		}

		String GPAregex = "^(4(\\.0{1,2})?|[0-3](\\.\\d{1,2})?)$";
		if (ScoreGPA.matches(GPAregex) == false) {
			JOptionPane.showMessageDialog(frmQunLSinh,
					"Vui lòng nhập điểm theo đúng định dạng số thực lớn hơn hoặc bằng 0 và nhỏ hơn hoặc bằng 4.0 !",
					"Chú Ý!", JOptionPane.ERROR_MESSAGE);
			return;
		}

		String gender = rbtM.isSelected() ? "Nam" : "Nữ";
		LocalDate StudentDateOfBirth = LocalDate.of(yearOfBirth, monthOfBirth, dayOfBirth);
		LocalDate StudentDateAdmission = LocalDate.of(yearOfAdmission, monthOfAdmission, dayOfAdmission);
		String studentAddress = (String) comboBoxAddress.getSelectedItem();
		String major = (String) comboBoxMajor.getSelectedItem();
		int NumberOfCredits = Integer.parseInt(numberOfCredits);
		int CumulativeNumberOfCredits = Integer.parseInt(cumulativeNumberOfCredits);
		double GPA = Double.parseDouble(ScoreGPA);

		SinhVien sinhvien = new SinhVien(Integer.parseInt(textFieldID.getText()), studentName, StudentDateOfBirth,
				gender, studentAddress, major, StudentDateAdmission, Email, PhoneNumber, NumberOfCredits,
				CumulativeNumberOfCredits, GPA);

		try {
			PrintWriter writer = new PrintWriter(this.mySocket.getOutputStream());

			writer.println("EDIT");
			writer.flush();
			try {
				Thread.sleep(10);
			} catch (InterruptedException ex) {
				Logger.getLogger(QuanLySV.class.getName()).log(Level.SEVERE, null, ex);
			}

			ObjectOutputStream ooutput = new ObjectOutputStream(this.mySocket.getOutputStream());
			ooutput.writeObject(sinhvien);
			ooutput.flush();

			BufferedReader reader = new BufferedReader(new InputStreamReader(this.mySocket.getInputStream()));
			String message = reader.readLine();

			if (message.compareTo("EDITS") == 65464) {
				JOptionPane.showMessageDialog(frmQunLSinh, "Sửa thông tin thành công", "Thành công!",
						JOptionPane.INFORMATION_MESSAGE);
				loadAllData();
			}

		} catch (IOException ex) {
			ex.printStackTrace();
			Logger.getLogger(QuanLySV.class.getName()).log(Level.SEVERE, null, ex);
		}

	}

	public void ClearData() {

		textFieldID.setText("");
		textFieldName.setText("");
		textFieldGPA.setText("");
		textFieldNumberOfCredits.setText("");
		textFieldCumulativeNumberOfCredits.setText("");
		textFieldPhoneNumber.setText("");
		textFieldEmail.setText("");
		btgr1.clearSelection();
		comboBoxDayAdmission.setSelectedIndex(-1);
		comboBoxDayOfBirth.setSelectedIndex(-1);
		comboBoxMajor.setSelectedIndex(-1);
		comboBoxMonthAdmission.setSelectedIndex(-1);
		comboBoxMonthOfBirth.setSelectedIndex(-1);
		comboBoxYearOfAdmission.setSelectedIndex(-1);
		comboBoxYearOfBirth.setSelectedIndex(-1);
		comboBoxAddress.setSelectedIndex(-1);

		AddBtn.setEnabled(true);
		BtnEdit.setEnabled(false);
		btnSendEmail.setEnabled(false);
		BtnDelete.setEnabled(false);

	}

	public void Delete() {
		int id = Integer.parseInt(textFieldID.getText());

		SinhVien sv = new SinhVien(id);

		try {
			PrintWriter writer = new PrintWriter(this.mySocket.getOutputStream());

			writer.println("DELETE");
			writer.flush();

			try {
				Thread.sleep(10);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			ObjectOutputStream ooutput = new ObjectOutputStream(this.mySocket.getOutputStream());
			ooutput.writeObject(sv);
			ooutput.flush();

			BufferedReader reader = new BufferedReader(new InputStreamReader(this.mySocket.getInputStream()));
			String message = reader.readLine();

			if (message.compareTo("DELETES") == 65465) {
				JOptionPane.showMessageDialog(frmQunLSinh, "Xóa thành công", "Thành công!",
						JOptionPane.INFORMATION_MESSAGE);
				try {
					Thread.sleep(10);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				loadAllData();
			}

		} catch (IOException ex) {
			ex.printStackTrace();
		}

		ClearData();
	}

	public void SearchByName() {

		if (this.textFieldSearchByField.getText().equals("")) {
			JOptionPane.showMessageDialog(frmQunLSinh, "Vui lòng nhập tên cần tìm kiếm! ", "Chú Ý!",
					JOptionPane.ERROR_MESSAGE);
		} else {

			try {
				PrintWriter writer = new PrintWriter(this.mySocket.getOutputStream());

				writer.println("SEARCHBYNAME");
				writer.flush();

				String studentName = textFieldSearchByField.getText();
				writer.println(studentName);
				writer.flush();

				List<SinhVien> list = new ArrayList<SinhVien>();

				ObjectInputStream oinput = new ObjectInputStream(this.mySocket.getInputStream());
				try {
					list = (List<SinhVien>) oinput.readObject();
				} catch (ClassNotFoundException ex) {
					ex.printStackTrace();
				}
				if (list.size() > 0) {
					tbmodel.setRowCount(0);
					for (SinhVien sinhVien : list) {
						tbmodel.addRow(new Object[] { sinhVien.getStudent_ID(), sinhVien.getStudent_Name(),
								sinhVien.getStudent_DateOfBirth() + "", sinhVien.getStudent_Gender(),
								sinhVien.getStudent_Address(), sinhVien.getStudent_Major(),
								sinhVien.getStudent_DayAdmission() + "", sinhVien.getEmail(),
								sinhVien.getStudent_PhoneNumber(), sinhVien.getStudent_NumberOfCredits(),
								sinhVien.getStudent_CumulativeNumberOfCredits(), sinhVien.getGPA() });
					}
				} else {
					tbmodel.setRowCount(0);
					JOptionPane.showMessageDialog(frmQunLSinh, "Không có kêt quả! ", "Chú Ý!",
							JOptionPane.PLAIN_MESSAGE);

				}

			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
		AddBtn.setEnabled(true);
	}

	public void SearchByAddress() {

		if (this.textFieldSearchByField.getText().equals("")) {
			JOptionPane.showMessageDialog(frmQunLSinh, "Vui lòng nhập địa chỉ cần tìm kiếm! ", "Chú Ý!",
					JOptionPane.ERROR_MESSAGE);
		} else {

			try {
				PrintWriter writer = new PrintWriter(this.mySocket.getOutputStream());

				writer.println("SEARCHBYADDRESS");
				writer.flush();

				String studentAddrees = textFieldSearchByField.getText();
				writer.println(studentAddrees);
				writer.flush();

				List<SinhVien> list = new ArrayList<SinhVien>();

				ObjectInputStream oinput = new ObjectInputStream(this.mySocket.getInputStream());
				try {
					list = (List<SinhVien>) oinput.readObject();
				} catch (ClassNotFoundException ex) {
					ex.printStackTrace();
				}
				if (list.size() > 0) {
					TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<DefaultTableModel>(this.tbmodel);
					table.setRowSorter(sorter);

					sorter.setSortKeys(List.of(new RowSorter.SortKey(0, SortOrder.ASCENDING)));

					tbmodel.setRowCount(0);
					for (SinhVien sinhVien : list) {
						tbmodel.addRow(new Object[] { sinhVien.getStudent_ID(), sinhVien.getStudent_Name(),
								sinhVien.getStudent_DateOfBirth() + "", sinhVien.getStudent_Gender(),
								sinhVien.getStudent_Address(), sinhVien.getStudent_Major(),
								sinhVien.getStudent_DayAdmission() + "", sinhVien.getEmail(),
								sinhVien.getStudent_PhoneNumber(), sinhVien.getStudent_NumberOfCredits(),
								sinhVien.getStudent_CumulativeNumberOfCredits(), sinhVien.getGPA() });
					}
				} else {
					tbmodel.setRowCount(0);
					JOptionPane.showMessageDialog(frmQunLSinh, "Không có kêt quả! ", "Chú Ý!",
							JOptionPane.PLAIN_MESSAGE);

				}

			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
		AddBtn.setEnabled(true);
	}

	public void SearchByID() {

		if (this.textFieldSearchByField.getText().equals("")) {
			JOptionPane.showMessageDialog(frmQunLSinh, "Vui lòng nhập mã sinh viên cần tìm kiếm! ", "Chú Ý!",
					JOptionPane.ERROR_MESSAGE);
		} else if (textFieldSearchByField.getText().matches("\\d*") == false) {
			JOptionPane.showMessageDialog(frmQunLSinh, "Vui lòng nhập mã sinh viên hợp lệ! ", "Chú Ý!",
					JOptionPane.ERROR_MESSAGE);
		} else {

			try {
				PrintWriter writer = new PrintWriter(this.mySocket.getOutputStream());

				writer.println("SEARCHBYID");
				writer.flush();

				String studentID = textFieldSearchByField.getText();
				writer.println(studentID);
				writer.flush();

				List<SinhVien> list = new ArrayList<SinhVien>();

				ObjectInputStream oinput = new ObjectInputStream(this.mySocket.getInputStream());
				try {
					list = (List<SinhVien>) oinput.readObject();
				} catch (ClassNotFoundException ex) {
					ex.printStackTrace();
				}
				if (list.size() > 0) {
					TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<DefaultTableModel>(this.tbmodel);
					table.setRowSorter(sorter);

					sorter.setSortKeys(List.of(new RowSorter.SortKey(0, SortOrder.ASCENDING)));
					tbmodel.setRowCount(0);
					for (SinhVien sinhVien : list) {
						tbmodel.addRow(new Object[] { sinhVien.getStudent_ID(), sinhVien.getStudent_Name(),
								sinhVien.getStudent_DateOfBirth() + "", sinhVien.getStudent_Gender(),
								sinhVien.getStudent_Address(), sinhVien.getStudent_Major(),
								sinhVien.getStudent_DayAdmission() + "", sinhVien.getEmail(),
								sinhVien.getStudent_PhoneNumber(), sinhVien.getStudent_NumberOfCredits(),
								sinhVien.getStudent_CumulativeNumberOfCredits(), sinhVien.getGPA() });
					}
				} else {
					tbmodel.setRowCount(0);
					JOptionPane.showMessageDialog(frmQunLSinh, "Không có kêt quả! ", "Chú Ý!",
							JOptionPane.PLAIN_MESSAGE);

				}

			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
		AddBtn.setEnabled(true);
	}

	public void loadAllData() {
		try {

			k01 = 0;
			k12 = 0;
			k23 = 0;
			k34 = 0;

			PrintWriter writer = new PrintWriter(this.mySocket.getOutputStream());
			writer.println("SEARCHALL");
			writer.flush();

			timeLoadData = 1;

			ObjectInputStream oinput = new ObjectInputStream(this.mySocket.getInputStream());
			List<SinhVien> list = new ArrayList<SinhVien>();
			list = (List<SinhVien>) oinput.readObject();
			if (list.size() > 0) {
				TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<DefaultTableModel>(this.tbmodel);
				table.setRowSorter(sorter);

				sorter.setSortKeys(List.of(new RowSorter.SortKey(0, SortOrder.ASCENDING)));
				tbmodel.setRowCount(0);
				for (SinhVien sinhVien : list) {

					if (sinhVien.getGPA() > 0 && sinhVien.getGPA() <= 1) {
						k01++;
					} else if (sinhVien.getGPA() > 1 && sinhVien.getGPA() <= 2) {
						k12++;
					} else if (sinhVien.getGPA() > 2 && sinhVien.getGPA() <= 3) {
						k23++;
					} else {
						k34++;
					}

					tbmodel.addRow(new Object[] { sinhVien.getStudent_ID(), sinhVien.getStudent_Name(),
							sinhVien.getStudent_DateOfBirth() + "", sinhVien.getStudent_Gender(),
							sinhVien.getStudent_Address(), sinhVien.getStudent_Major(),
							sinhVien.getStudent_DayAdmission() + "", sinhVien.getEmail(),
							sinhVien.getStudent_PhoneNumber(), sinhVien.getStudent_NumberOfCredits(),
							sinhVien.getStudent_CumulativeNumberOfCredits(), sinhVien.getGPA() });
				}
			}

		} catch (Exception e) {
		}
	}

	public void sendEmail() {
		String emailTo = textFieldEmail.getText();

		if (emailTo.equals("")) {
			JOptionPane.showMessageDialog(this.frmQunLSinh, "Email đang trống!.", "Lỗi!", JOptionPane.ERROR_MESSAGE);
			return;
		}

		String emailregex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:gmail)\\.(?:com)$";
		if (emailTo.matches(emailregex) == false) {
			JOptionPane.showMessageDialog(this.frmQunLSinh, "Email không hợp lệ!.", "Lỗi!", JOptionPane.ERROR_MESSAGE);
			return;
		}

		frmQunLSinh.setVisible(false);
		SendEmail send = new SendEmail(emailTo, this.frmQunLSinh);
	}

	public void fillStudentFromSelectedRow() {
		// lấy chỉ số của hàng được chọn
		int row = table.getSelectedRow();
		if (row >= 0) {
			textFieldID.setText(table.getModel().getValueAt(row, 0).toString());
			textFieldName.setText(table.getModel().getValueAt(row, 1).toString());

			String[] arrDateOfBirth = table.getModel().getValueAt(row, 2).toString().split("-");
			int dayOfBirth = Integer.parseInt(arrDateOfBirth[2]);
			int monthOfBirth = Integer.parseInt(arrDateOfBirth[1]);
			int yearOfBirth = Integer.parseInt(arrDateOfBirth[0]);

			comboBoxDayOfBirth.setSelectedItem(dayOfBirth);
			comboBoxMonthOfBirth.setSelectedItem(monthOfBirth);
			comboBoxYearOfBirth.setSelectedItem(yearOfBirth);

			String gender = table.getModel().getValueAt(row, 3).toString();
			if (gender.equals("Nam")) {
				rbtM.setSelected(true);
			} else {
				rbtFM.setSelected(true);
			}

			String Address = table.getModel().getValueAt(row, 4).toString();
			comboBoxAddress.setSelectedItem(Address);

			String major = table.getModel().getValueAt(row, 5).toString();
			comboBoxMajor.setSelectedItem(major);

			String[] arrDateAdmission = table.getModel().getValueAt(row, 6).toString().split("-");
			int dayAdmission = Integer.parseInt(arrDateAdmission[2]);
			int monthAdmission = Integer.parseInt(arrDateAdmission[1]);
			int yearAdmission = Integer.parseInt(arrDateAdmission[0]);

			comboBoxDayAdmission.setSelectedItem(dayAdmission);
			comboBoxMonthAdmission.setSelectedItem(monthAdmission);
			comboBoxYearOfAdmission.setSelectedItem(yearAdmission);

			textFieldEmail.setText(table.getModel().getValueAt(row, 7).toString());

			textFieldPhoneNumber.setText(table.getModel().getValueAt(row, 8).toString());

			textFieldNumberOfCredits.setText(table.getModel().getValueAt(row, 9).toString());

			textFieldCumulativeNumberOfCredits.setText(table.getModel().getValueAt(row, 10).toString());

			textFieldGPA.setText(table.getModel().getValueAt(row, 11).toString());

		}
	}

	private void exportToExcel() {
		try {
			Workbook workbook = new XSSFWorkbook();
			Sheet sheet = workbook.createSheet("Data");

			// Lấy số lượng hàng và cột từ bảng
			int rowCount = table.getRowCount();
			int columnCount = table.getColumnCount();

			// Tiêu đề cột
			Row headerRow = sheet.createRow(0);
			for (int col = 0; col < columnCount; col++) {
				Cell cell = headerRow.createCell(col);
				cell.setCellValue(table.getColumnName(col));
			}

			// Dữ liệu từ bảng
			for (int row = 0; row < rowCount; row++) {
				Row sheetRow = sheet.createRow(row + 1);
				for (int col = 0; col < columnCount; col++) {
					Object value = table.getValueAt(row, col);
					Cell cell = sheetRow.createCell(col);
					if (value != null) {
						if (value instanceof String) {
							cell.setCellValue((String) value);
						} else if (value instanceof Integer) {
							cell.setCellValue((Integer) value);
						} else if (value instanceof Double) {
							cell.setCellValue((Double) value);
						}
					}
				}
			}

			String desktopPath = System.getProperty("user.home") + "/Desktop/";
			String excelFilePath = desktopPath + "Data.xlsx";

			// Ghi workbook vào OutputStream (Excel file)

			try {
				FileOutputStream outputStream = new FileOutputStream(excelFilePath);
				workbook.write(outputStream);
			} catch (Exception e) {
				// TODO: handle exception
			}

			JOptionPane.showMessageDialog(this.frmQunLSinh, "Xuất file excel thành công!", "Success",
					JOptionPane.INFORMATION_MESSAGE);
			workbook.close();

		} catch (Exception e) {
			JOptionPane.showMessageDialog(this.frmQunLSinh, "Lỗi : " + e.getMessage(), "Error",
					JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
	}

	public void valueChanged(ListSelectionEvent e) {
		fillStudentFromSelectedRow();
		BtnEdit.setEnabled(true);
		btnSendEmail.setEnabled(true);
		AddBtn.setEnabled(false);
		BtnDelete.setEnabled(true);

	}

	public void QLMH() {
		new QuanLyMonHoc(frmQunLSinh, mySocket);
		this.frmQunLSinh.setVisible(false);
	}

	public void QLGV() {
		new QuanLyGiangVien(frmQunLSinh, mySocket);
		this.frmQunLSinh.setVisible(false);
	}

	@Override
	public void run() {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException ex) {
			Logger.getLogger(QuanLySV.class.getName()).log(Level.SEVERE, null, ex);
		}

		loadAllData();

	}
}
