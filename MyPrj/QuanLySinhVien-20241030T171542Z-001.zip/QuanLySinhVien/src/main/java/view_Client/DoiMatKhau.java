package view_Client;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.UIManager;

import model.User;

import javax.swing.JButton;
import javax.swing.JPasswordField;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.border.LineBorder;

public class DoiMatKhau extends Thread implements ActionListener {

	private JFrame frame;
	private Socket mysocket;
	private JTextField textField;
	private JPasswordField passwordField;
	private JPasswordField passwordField_1;
	private JPasswordField passwordField_2;
	private BufferedReader reader;
	private PrintWriter writer;
	String message_from_server = null;
	private JFrame jframe_;
	private String URL;
	private int PORT;

	/**
	 * Launch the application.
	 */

	/**
	 * Create the application.
	 */
	public DoiMatKhau(JFrame jFrame, String url, int port) {

		this.jframe_ = jFrame;
		this.URL = url;
		this.PORT = port;

		initialize();
		this.start();

	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {

		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(211, 211, 211));
		frame.setBounds(100, 100, 523, 350);
		frame.setTitle("Đổi mật khẩu");
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(169, 169, 169)));
		panel.setBackground(new Color(255, 250, 240));
		panel.setBounds(31, 10, 448, 290);
		frame.getContentPane().add(panel);
		panel.setLayout(null);

		JLabel lblNewLabel = new JLabel("ĐỔI MẬT KHẨU");
		lblNewLabel.setBounds(100, 10, 242, 43);
		panel.add(lblNewLabel);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 35));

		textField = new JTextField();
		textField.setBounds(198, 80, 204, 19);
		panel.add(textField);
		textField.setColumns(10);

		passwordField = new JPasswordField();
		passwordField.setBounds(198, 109, 204, 19);
		panel.add(passwordField);

		passwordField_1 = new JPasswordField();
		passwordField_1.setBounds(198, 138, 204, 19);
		panel.add(passwordField_1);

		passwordField_2 = new JPasswordField();
		passwordField_2.setBounds(198, 167, 204, 19);
		panel.add(passwordField_2);

		JLabel lblNewLabel_1 = new JLabel("Tài khoản");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_1.setBounds(65, 83, 86, 16);
		panel.add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("Mật khẩu cũ");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_2.setBounds(65, 112, 104, 13);
		panel.add(lblNewLabel_2);

		JLabel lblNewLabel_2_1 = new JLabel("Mật khẩu mới");
		lblNewLabel_2_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_2_1.setBounds(65, 141, 104, 13);
		panel.add(lblNewLabel_2_1);

		JLabel lblNewLabel_2_2 = new JLabel("Xác nhận mật khẩu mới");
		lblNewLabel_2_2.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_2_2.setBounds(65, 170, 133, 13);
		panel.add(lblNewLabel_2_2);

		JButton btnNewButton = new JButton("Đổi mật khẩu");
		btnNewButton.setBounds(153, 214, 115, 21);
		panel.add(btnNewButton);

		JButton btnNewButton_1 = new JButton("Trở về");
		btnNewButton_1.addActionListener(this);
		btnNewButton_1.setBounds(300, 250, 115, 21);
		panel.add(btnNewButton_1);
		btnNewButton.addActionListener(this);

		frame.setVisible(true);
	}

	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		String src = e.getActionCommand();

		if (src.equals("Đổi mật khẩu")) {
			changePassword();
		} else if (src.equals("Trở về")) {
			Back();
		}

	}

	public void Back() {

		if (this.mysocket != null) {
			User us = new User("OUT", "OUT OUT");

			ObjectOutputStream Ooutput;
			try {
				Ooutput = new ObjectOutputStream(this.mysocket.getOutputStream());
				Ooutput.writeObject(us);
			} catch (IOException e) {
				JOptionPane.showMessageDialog(frame, "Không thể kết nối tới máy chủ, vui lòng thoát chương trình!",
						"Chú Ý!", JOptionPane.ERROR_MESSAGE);
				return;
			}

			try {
				this.mysocket.close();
			} catch (IOException ex) {
				Logger.getLogger(DangKy.class.getName()).log(Level.SEVERE, null, ex);
			}
		}

		frame.dispose();
		this.jframe_.setVisible(true);

	}

	public void changePassword() {
		String account = textField.getText();
		String oldpass = new String(passwordField.getPassword());
		String newpass1 = new String(passwordField_1.getPassword());
		String newpass2 = new String(passwordField_2.getPassword());

		String passregex = "^(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*()-+])[a-zA-Z0-9!@#$%^&*()-+]{8,16}$";

		if (account.equals("") || oldpass.equals("") || newpass1.equals("") || newpass2.equals("")) {
			JOptionPane.showMessageDialog(frame, "Vui lòng điền đầy đủ thông tin!", "Chú Ý!",
					JOptionPane.ERROR_MESSAGE);
		} else if (!newpass1.equals(newpass2)) {
			JOptionPane.showMessageDialog(frame, "Mật khẩu mới phải giống nhau!", "Chú Ý!", JOptionPane.ERROR_MESSAGE);
		} else if (newpass1.matches(passregex) == false) {
			JOptionPane.showMessageDialog(frame,
					"Mật khẩu phải có từ 8 - 16 ký tự, bao gồm ít nhất 1 chữ số, 1 chữ cái in hoa và 1 ký tự đặc biệt",
					"Chú Ý!", JOptionPane.ERROR_MESSAGE);
		} else {
			String pass = oldpass + " " + newpass1;

			User user = new User(account, pass);

			if (this.mysocket != null) {
				try {

					ObjectOutputStream Ooutput = new ObjectOutputStream(this.mysocket.getOutputStream());
					Ooutput.writeObject(user);

					DoiMatKhauStatement dmk = new DoiMatKhauStatement(mysocket, frame);
					dmk.start();

				} catch (IOException e1) {

					JOptionPane.showMessageDialog(frame, "Không thể kết nối tới máy chủ, vui lòng thoát chương trình!",
							"Chú Ý!", JOptionPane.ERROR_MESSAGE);
					e1.printStackTrace();
				}
			}

		}
	}

	@Override
	public void run() {

		try {
			this.mysocket = new Socket(URL, PORT);
		} catch (Exception e) {

			JOptionPane.showMessageDialog(frame, "Không thể kết nối tới máy chủ, vui lòng thoát chương trình!",
					"Chú Ý!", JOptionPane.ERROR_MESSAGE);

		}
		if (this.mysocket != null) {
			try {
				writer = new PrintWriter(this.mysocket.getOutputStream());
				reader = new BufferedReader(new InputStreamReader(this.mysocket.getInputStream()));
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}

		if (this.mysocket != null) {
			writer.println("DOIMATKHAU");
			writer.flush();
		}

	}

}
