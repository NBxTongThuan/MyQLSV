package view_Client;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Properties;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.Timer;
import javax.swing.UIManager;

import model.User;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.JButton;

public class DangKy extends Thread implements ActionListener {

	private JFrame frmQunLSinh;
	private JTextField textField;
	private JPasswordField textField_1;
	private JPasswordField textField_2;
	private Socket socket;
	private JFrame frame;
	private BufferedReader read;
	private PrintWriter writer;
	private JTextField textField_3;
	private String OTP = null;
	private JButton btnNewButton_2;
	private Timer timer;
	private String URL;
	private int PORT;

	/**
	 * Launch the application.
	 */
	/**
	 * Create the application.
	 *
	 * @wbp.parser.entryPoint
	 */
	public DangKy(JFrame frame, String url, int port) {
		this.frame = frame;
		this.PORT = port;
		this.URL = url;
		initialize();
		this.start();

	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e) {
			e.printStackTrace();
		}
		frmQunLSinh = new JFrame();
		frmQunLSinh.setTitle("Đăng ký tài khoản");
		frmQunLSinh.setBounds(100, 100, 450, 300);
		frmQunLSinh.getContentPane().setLayout(null);
		frmQunLSinh.setLocationRelativeTo(null);
		frmQunLSinh.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JLabel lblNewLabel = new JLabel("ĐĂNG KÝ TÀI KHOẢN");
		lblNewLabel.setForeground(Color.RED);
		lblNewLabel.setBackground(Color.WHITE);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		lblNewLabel.setBounds(21, 22, 246, 32);
		frmQunLSinh.getContentPane().add(lblNewLabel);

		JPanel panel = new JPanel();
		panel.setBackground(new Color(211, 211, 211));
		panel.setLayout(null);
		panel.setBounds(21, 52, 394, 201);
		frmQunLSinh.getContentPane().add(panel);

		JLabel lblNewLabel_2 = new JLabel("EMAIL");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 10));
		lblNewLabel_2.setBounds(40, 37, 110, 13);
		panel.add(lblNewLabel_2);

		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(160, 34, 169, 19);
		panel.add(textField);

		JLabel lblNewLabel_3 = new JLabel("MẬT KHẨU");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 10));
		lblNewLabel_3.setBounds(40, 98, 110, 13);
		panel.add(lblNewLabel_3);

		textField_1 = new JPasswordField();
		textField_1.setColumns(10);
		textField_1.setBounds(160, 95, 169, 19);
		panel.add(textField_1);

		JButton btnNewButton_1 = new JButton("ĐĂNG KÝ");
		btnNewButton_1.addActionListener(this);
		btnNewButton_1.setForeground(new Color(220, 20, 60));
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 10));
		btnNewButton_1.setBackground(Color.CYAN);
		btnNewButton_1.setBounds(77, 159, 96, 21);
		panel.add(btnNewButton_1);

		JLabel lblNewLabel_3_1 = new JLabel("XÁC NHẬN MẬT KHẨU");
		lblNewLabel_3_1.setFont(new Font("Tahoma", Font.PLAIN, 10));
		lblNewLabel_3_1.setBounds(40, 127, 134, 13);
		panel.add(lblNewLabel_3_1);

		textField_2 = new JPasswordField();
		textField_2.setColumns(10);
		textField_2.setBounds(160, 124, 169, 19);
		panel.add(textField_2);

		JButton btnNewButton = new JButton("TRỞ VỀ");
		btnNewButton.addActionListener(this);
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 9));
		btnNewButton.setForeground(new Color(128, 0, 128));
		btnNewButton.setBackground(Color.WHITE);
		btnNewButton.setBounds(223, 159, 96, 21);
		panel.add(btnNewButton);

		JLabel lblNewLabel_1 = new JLabel("MÃ XÁC NHẬN");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 10));
		lblNewLabel_1.setBounds(40, 70, 110, 13);
		panel.add(lblNewLabel_1);

		textField_3 = new JTextField();
		textField_3.setBounds(160, 66, 86, 19);
		panel.add(textField_3);
		textField_3.setColumns(10);

		btnNewButton_2 = new JButton("Gửi mã");
		btnNewButton_2.setFont(new Font("Tahoma", Font.PLAIN, 9));
		btnNewButton_2.addActionListener(this);
		btnNewButton_2.setBackground(Color.LIGHT_GRAY);
		btnNewButton_2.setBounds(248, 65, 81, 21);
		panel.add(btnNewButton_2);

		frmQunLSinh.setVisible(true);
	}

	/**
	 * @wbp.parser.entryPoint
	 */
//	public static void main(String[] args) {
//		new DangKy();
//	}
	public void actionPerformed(ActionEvent e) {
		String src = e.getActionCommand();
		timer = new Timer(60000, new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OTP = null;
				btnNewButton_2.setEnabled(true); // Kích hoạt nút bấm sau khi hết thời gian
				((Timer) e.getSource()).stop(); // Dừng đếm ngược
			}
		});

		if (src.equals("ĐĂNG KÝ")) {
			Register();
		} else if (src.equals("TRỞ VỀ")) {
			Back();
		} else if (src.equals("Gửi mã")) {
			OTP = null;
			btnNewButton_2.setEnabled(false);
			RanOTP();
			SendOTP();
			timer.restart();
		}
	}

	public void Register() {

		if (this.socket == null) {
			JOptionPane.showMessageDialog(frmQunLSinh,
					"Máy chủ đã tắt, không thể thực hiện thao tác này, vui lòng thoát chương trình!", "Chú Ý!",
					JOptionPane.ERROR_MESSAGE);
			return;
		}

		String pass1 = new String(textField_1.getPassword());
		String pass2 = new String(textField_2.getPassword());
		String email = textField.getText();
		String passregex = "^(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*()-+])[a-zA-Z0-9!@#$%^&*()-+]{8,16}$";
		String emailregex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:gmail)\\.(?:com)$";
		if ((email.equals("")) || (pass1.length() <= 0) || (pass2.length() <= 0)) {
			JOptionPane.showMessageDialog(frmQunLSinh, "Vui lòng nhập đầy đủ thông tin email và xác nhận mật khẩu!",
					"Chú Ý!", JOptionPane.ERROR_MESSAGE);
		} else if (email.matches(emailregex) == false) {
			JOptionPane.showMessageDialog(frmQunLSinh, "Gmail không đúng định dạng!", "Chú Ý!",
					JOptionPane.ERROR_MESSAGE);
		} else if (textField_3.getText().equals("") == true) {
			JOptionPane.showMessageDialog(frmQunLSinh, "Vui lòng nhập mã xác nhận được gửi tới email!", "Chú Ý!",
					JOptionPane.ERROR_MESSAGE);
		} else if (!textField_3.getText().equals(OTP)) {
			JOptionPane.showMessageDialog(frmQunLSinh, "Mã xác nhận không đúng!", "Chú Ý!", JOptionPane.ERROR_MESSAGE);
		} else if (!pass1.equals(pass2)) {
			JOptionPane.showMessageDialog(frmQunLSinh, "Mật khẩu xác nhận không đúng!", "Chú Ý!",
					JOptionPane.ERROR_MESSAGE);
		} else if (!(pass1.toString().matches(passregex))) {
			JOptionPane.showMessageDialog(frmQunLSinh,
					"Mật khẩu phải có từ 8 - 16 ký tự, bao gồm ít nhất 1 chữ số, 1 chữ cái in hoa và 1 ký tự đặc biệt",
					"Chú Ý!", JOptionPane.ERROR_MESSAGE);
		} else {

			User user = new User(email, pass1);

			if (this.socket != null) {
				try {

					ObjectOutputStream Ooutput = new ObjectOutputStream(this.socket.getOutputStream());
					Ooutput.writeObject(user);

					DangKyStatement dk = new DangKyStatement(socket, frmQunLSinh);
					dk.start();
				} catch (IOException e1) {
					JOptionPane.showMessageDialog(frmQunLSinh,
							"Không thể kết nối tới máy chủ, vui lòng thoát chương trình!", "Chú Ý!",
							JOptionPane.ERROR_MESSAGE);
				}
			}

		}

	}

	public void Back() {

		User us = new User("OUT", "OUT");
		
		try {
			ObjectOutputStream Ooutput = new ObjectOutputStream(this.socket.getOutputStream());
			Ooutput.writeObject(us);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(frmQunLSinh,
					"Không thể kết nối tới máy chủ, vui lòng thoát chương trình!", "Chú Ý!",
					JOptionPane.ERROR_MESSAGE);
			return;
		}

		if (this.socket != null) {
			try {
				this.socket.close();
			} catch (IOException ex) {
				Logger.getLogger(DangKy.class.getName()).log(Level.SEVERE, null, ex);
			}
		}

		frmQunLSinh.dispose();
		this.frame.setVisible(true);

	}

	public String RanOTP() {
		OTP = "";
		Random random = new Random();
		for (int i = 0; i < 6; i++) {
			int value = random.nextInt(10);
			OTP += value;
		}
		return OTP;

	}

	public void SendOTP() {
		final String from = "tongthuan15092003@gmail.com";
		final String passWord = "vplymroxjzluvxpx";
		// Thuộc tính
		Properties props = new Properties();
		props.put("mail.smtp.host", "smtp.gmail.com");// SMTP HOST
		props.put("mail.smtp.port", "587");// TSL 587, SSL 465
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.ssl.protocols", "TLSv1.2");

		// Create Authenticator
		Authenticator auth = new Authenticator() {
			@Override
			protected PasswordAuthentication getPasswordAuthentication() {
				// TODO Auto-generated method stub
				return new PasswordAuthentication(from, passWord);
			}

		};

		// phiên làm việc
		Session session = Session.getInstance(props, auth);

		// Gửi email
		final String to = textField.getText();

		// Tạo một tin nhắn
		MimeMessage msg = new MimeMessage(session);
		try {
			msg.addHeader("Content-type", "text/HTML; charset=UTF-8");
			msg.setFrom();
			msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to, false));

			// Tiêu đề
			msg.setSubject("Quản Lý Sinh Viên");

			// Nội dung email
			msg.setText("Mã xác nhận đăng ký tài khoản quản lý sinh viên là : " + OTP
					+ " mã này chỉ có hiệu lực trong 60 giây", "UTF-8");

			Transport.send(msg);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void run() {

		try {
			this.socket = new Socket(URL, PORT);
		} catch (IOException ex) {
			JOptionPane.showMessageDialog(frmQunLSinh,
					"Không thể kết nối tới máy chủ, vui lòng thoát chương trình!", "Chú Ý!",
					JOptionPane.ERROR_MESSAGE);
			return;
		}

		if (this.socket != null) {
			try {
				writer = new PrintWriter(this.socket.getOutputStream());
				read = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}

		if(this.socket!=null)
		{
			writer.println("DANGKY");
			writer.flush();
		}

	}

}
