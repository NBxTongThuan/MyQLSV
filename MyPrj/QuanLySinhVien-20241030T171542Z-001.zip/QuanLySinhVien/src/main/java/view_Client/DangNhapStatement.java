/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view_Client;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author Tong Thuan
 */
public class DangNhapStatement extends Thread {

	private Socket socket;
	private String message;
	private JFrame frame;
	private String userName;
	private String url;
	private int PORT;

	public DangNhapStatement(Socket socket, JFrame frame, String userName, String url, int PORT) {
		this.socket = socket;
		this.frame = frame;
		this.userName = userName;
		this.url = url;
		this.PORT = PORT;

	}

	@Override
	public void run() {

		try {
			BufferedReader read = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
			this.message = read.readLine();
			if (message.equals("DANGNHAPTHANHCONG")) {
				frame.dispose();
				Socket qlSocket = new Socket(url, PORT);
				PrintWriter writer = new PrintWriter(qlSocket.getOutputStream());
				writer.println("QUANLY");
				writer.flush();
				new QuanLySV(this.userName, this.socket, qlSocket);
			} else if (message.equals("THONGTINKHONGDUNG")) {

				JOptionPane.showMessageDialog(frame, "Thông tin tài khoản hoặc mật khẩu không chính xác!", "Chú Ý!",
						JOptionPane.ERROR_MESSAGE);

			} else if (message.equals("DADANGNHAPONOIKHAC")) {
				JOptionPane.showMessageDialog(frame, "Tài khoản đã đăng nhập ở nơi khác!", "Chú Ý!",
						JOptionPane.ERROR_MESSAGE);
			}
		} catch (Exception e) {

		}
	}

}
