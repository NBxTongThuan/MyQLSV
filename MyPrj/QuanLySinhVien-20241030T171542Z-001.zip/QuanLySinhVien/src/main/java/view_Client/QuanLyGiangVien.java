package view_Client;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import java.awt.Color;
import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.RowSorter;
import javax.swing.SortOrder;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import model.GiangVien;
import model.MonHoc;

import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

public class QuanLyGiangVien extends Thread implements ActionListener, ListSelectionListener {

	private JFrame frame;
	private JTextField textFieldSearch;
	private JTextField textFieldID;
	private JTextField textFieldName;
	private JTextField textFieldEmail;
	private JTextField textFieldPhoneNumber;
	private JButton BtnDelete, BtnReload, BtnBack, BtnClear, BtnEdit, BtnAdd, BtnSearch;
	private JFrame jframe;
	private Socket socket;
	private int timeLoadData = 0;
	private DefaultTableModel tbmodel;
	private JTable table;
	private JMenuItem BtnmnExportExcel;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					QuanLyGiangVien window = new QuanLyGiangVien();
//					window.frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the application.
	 */
	public QuanLyGiangVien(JFrame jframe, Socket socket) {

		this.socket = socket;
		this.jframe = jframe;
		this.tbmodel = new DefaultTableModel();
		initialize();
		this.start();

	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {

		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedLookAndFeelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		frame = new JFrame();
		frame.setBounds(100, 100, 962, 488);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JLabel GVLB = new JLabel("QUẢN LÝ GIẢNG VIÊN");
		GVLB.setFont(new Font("Tahoma", Font.PLAIN, 31));
		GVLB.setBounds(11, 21, 316, 48);
		frame.getContentPane().add(GVLB);

		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(326, 110, 612, 331);
		frame.getContentPane().add(panel);
		panel.setLayout(new BorderLayout(0, 0));

		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.LIGHT_GRAY);
		panel_1.setBounds(10, 79, 306, 361);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);

		JPanel panel_2 = new JPanel();
		panel_2.setBounds(10, 30, 286, 74);
		panel_1.add(panel_2);
		panel_2.setLayout(null);

		JLabel lblNewLabel = new JLabel("Tìm kiếm");
		lblNewLabel.setBounds(10, 10, 70, 13);
		panel_2.add(lblNewLabel);

		textFieldSearch = new JTextField();
		textFieldSearch.setBounds(10, 33, 181, 19);
		panel_2.add(textFieldSearch);
		textFieldSearch.setColumns(10);

		BtnSearch = new JButton("Search");
		BtnSearch.addActionListener(this);
		BtnSearch.setBounds(201, 32, 75, 21);
		panel_2.add(BtnSearch);

		JLabel lblNewLabel_1 = new JLabel("Nhập tên giảng viên");
		lblNewLabel_1.setBounds(101, 10, 105, 13);
		panel_2.add(lblNewLabel_1);

		JPanel panel_3 = new JPanel();
		panel_3.setBounds(6, 132, 290, 216);
		panel_1.add(panel_3);
		panel_3.setLayout(null);

		BtnDelete = new JButton("Delete");
		BtnDelete.addActionListener(this);
		BtnDelete.setBounds(195, 156, 85, 21);
		panel_3.add(BtnDelete);

		BtnClear = new JButton("Clear");
		BtnClear.addActionListener(this);
		BtnClear.setBounds(195, 187, 85, 21);
		panel_3.add(BtnClear);

		BtnEdit = new JButton("Edit");
		BtnEdit.addActionListener(this);
		BtnEdit.setBounds(101, 156, 85, 21);
		panel_3.add(BtnEdit);

		BtnAdd = new JButton("Add");
		BtnAdd.addActionListener(this);
		BtnAdd.setBounds(6, 156, 85, 21);
		panel_3.add(BtnAdd);

		JLabel lblNewLabel_2_1 = new JLabel("Mã GV");
		lblNewLabel_2_1.setBounds(6, 40, 45, 13);
		panel_3.add(lblNewLabel_2_1);

		JLabel lblNewLabel_2_2 = new JLabel("Tên GV");
		lblNewLabel_2_2.setBounds(6, 66, 45, 13);
		panel_3.add(lblNewLabel_2_2);

		JLabel lblNewLabel_2_3 = new JLabel("Email");
		lblNewLabel_2_3.setBounds(6, 92, 45, 13);
		panel_3.add(lblNewLabel_2_3);

		JLabel lblNewLabel_2_4 = new JLabel("Số điện thoại");
		lblNewLabel_2_4.setBounds(6, 118, 71, 13);
		panel_3.add(lblNewLabel_2_4);

		textFieldID = new JTextField();
		textFieldID.setEditable(false);
		textFieldID.setBounds(75, 37, 63, 19);
		panel_3.add(textFieldID);
		textFieldID.setColumns(10);

		textFieldName = new JTextField();
		textFieldName.setBounds(75, 63, 188, 19);
		panel_3.add(textFieldName);
		textFieldName.setColumns(10);

		textFieldEmail = new JTextField();
		textFieldEmail.setColumns(10);
		textFieldEmail.setBounds(75, 89, 171, 19);
		panel_3.add(textFieldEmail);

		textFieldPhoneNumber = new JTextField();
		textFieldPhoneNumber.setColumns(10);
		textFieldPhoneNumber.setBounds(75, 115, 116, 19);
		panel_3.add(textFieldPhoneNumber);

		JLabel lblNewLabel_2 = new JLabel("Action");
		lblNewLabel_2.setBounds(6, 10, 45, 13);
		panel_3.add(lblNewLabel_2);

		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(325, 79, 45, 22);
		frame.getContentPane().add(menuBar);

		JMenu mnNewMenu = new JMenu("menu");
		menuBar.add(mnNewMenu);

		BtnmnExportExcel = new JMenuItem("Export Excel");
		BtnmnExportExcel.addActionListener(this);
		mnNewMenu.add(BtnmnExportExcel);

		BtnReload = new JButton("Reload Data");
		BtnReload.addActionListener(this);
		BtnReload.setBounds(833, 79, 105, 21);
		frame.getContentPane().add(BtnReload);

		BtnBack = new JButton("Trở về trang QLSV");
		BtnBack.addActionListener(this);
		BtnBack.setBounds(821, 10, 117, 21);
		frame.getContentPane().add(BtnBack);

		tbmodel.addColumn("Mã giảng viên");
		tbmodel.addColumn("Tên giảng viên");
		tbmodel.addColumn("Email");
		tbmodel.addColumn("Số điện thoại");
		table = new JTable(tbmodel);
		table.getSelectionModel().addListSelectionListener(this);
		JScrollPane scrollPane = new JScrollPane(table);
		panel.add(scrollPane, BorderLayout.CENTER);

		frame.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {

				// Hiển thị hộp thoại xác nhận
				int confirm = JOptionPane.showConfirmDialog(frame, "Bạn có chắc chắn muốn đóng cửa sổ không?",
						"Xác nhận thoát", JOptionPane.YES_NO_OPTION);

				// Đóng cửa sổ nếu người dùng chọn "Yes"
				if (confirm == JOptionPane.YES_OPTION) {

					frame.dispose();
				}
			}
		});

		frame.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == BtnAdd) {
			Add();
		} else if (e.getSource() == BtnClear) {
			Clear();
		} else if (e.getSource() == BtnSearch) {
			SearchByName();
		} else if (e.getSource() == BtnEdit) {
			Edit();
		} else if (e.getSource() == BtnDelete) {
			DeleteByID();
		} else if (e.getSource() == BtnBack) {
			Back();
		} else if (e.getSource() == BtnmnExportExcel) {
			exportToExcel();
		} else if (e.getSource() == BtnReload) {
			loadAllData();
		}

	}

	public void Exit() {
		frame.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {

				// Hiển thị hộp thoại xác nhận
				int confirm = JOptionPane.showConfirmDialog(frame, "Bạn có chắc chắn muốn đóng cửa sổ không?",
						"Xác nhận thoát", JOptionPane.YES_NO_OPTION);

				// Đóng cửa sổ nếu người dùng chọn "Yes"
				if (confirm == JOptionPane.YES_OPTION) {

					frame.dispose();
				}
			}
		});

	}

	private void exportToExcel() {
		try {
			Workbook workbook = new XSSFWorkbook();
			Sheet sheet = workbook.createSheet("DataGV");

			// Lấy số lượng hàng và cột từ bảng
			int rowCount = table.getRowCount();
			int columnCount = table.getColumnCount();

			// Tiêu đề cột
			Row headerRow = sheet.createRow(0);
			for (int col = 0; col < columnCount; col++) {
				Cell cell = headerRow.createCell(col);
				cell.setCellValue(table.getColumnName(col));
			}

			// Dữ liệu từ bảng
			for (int row = 0; row < rowCount; row++) {
				Row sheetRow = sheet.createRow(row + 1);
				for (int col = 0; col < columnCount; col++) {
					Object value = table.getValueAt(row, col);
					Cell cell = sheetRow.createCell(col);
					if (value != null) {
						if (value instanceof String) {
							cell.setCellValue((String) value);
						} else if (value instanceof Integer) {
							cell.setCellValue((Integer) value);
						} else if (value instanceof Double) {
							cell.setCellValue((Double) value);
						}
					}
				}
			}

			String desktopPath = System.getProperty("user.home") + "/Desktop/";
			String excelFilePath = desktopPath + "DataGV.xlsx";

			// Ghi workbook vào OutputStream (Excel file)

			try {
				FileOutputStream outputStream = new FileOutputStream(excelFilePath);
				workbook.write(outputStream);
			} catch (Exception e) {
				// TODO: handle exception
			}

			JOptionPane.showMessageDialog(this.frame, "Xuất file excel thành công!", "Success",
					JOptionPane.INFORMATION_MESSAGE);
			workbook.close();

		} catch (Exception e) {
			JOptionPane.showMessageDialog(this.frame, "Lỗi : " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
	}

	public void Back() {
		this.frame.dispose();
		this.jframe.setVisible(true);
	}

	public void loadAllData() {
		try {

			PrintWriter writer = new PrintWriter(this.socket.getOutputStream());
			writer.println("SEARCHALLGV");
			writer.flush();

			timeLoadData = 1;

			ObjectInputStream oinput = new ObjectInputStream(this.socket.getInputStream());
			List<GiangVien> list = new ArrayList<GiangVien>();
			list = (List<GiangVien>) oinput.readObject();
			if (list.size() > 0) {
				TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<DefaultTableModel>(this.tbmodel);
				table.setRowSorter(sorter);
				sorter.setSortKeys(List.of(new RowSorter.SortKey(0, SortOrder.ASCENDING)));
				tbmodel.setRowCount(0);
				for (GiangVien giangvien : list) {
					tbmodel.addRow(new Object[] { giangvien.getMaGiangVien(), giangvien.getTenGiangVien(),
							giangvien.getEmail(), giangvien.getSoDienThoai() });
				}
			}

		} catch (Exception e) {
		}

	}

	public void Add() {
		String GVName = textFieldName.getText();
		String Email = textFieldEmail.getText();
		String PhoneNB = textFieldPhoneNumber.getText();

		if (GVName.equals("") || Email.equals("") || PhoneNB.equals("")) {
			JOptionPane.showMessageDialog(frame, "Vui lòng nhập đầy đủ thông tin!", "Chú Ý!",
					JOptionPane.ERROR_MESSAGE);
			return;
		}

		GiangVien gv = new GiangVien(GVName, Email, PhoneNB);

		try {
			PrintWriter writer = new PrintWriter(this.socket.getOutputStream());
			for (int i = 0; i < 1; i++) {
				writer.println("ADDGV");
				writer.flush();
				try {
					Thread.sleep(10);
				} catch (InterruptedException ex) {
					Logger.getLogger(QuanLySV.class.getName()).log(Level.SEVERE, null, ex);
				}
			}

			ObjectOutputStream ooutput = new ObjectOutputStream(this.socket.getOutputStream());
			ooutput.writeObject(gv);
			ooutput.flush();

			BufferedReader reader = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
			String message = reader.readLine();

			System.out.println(message);

			if (message != null) {
				JOptionPane.showMessageDialog(frame, "Thêm môn học thành công", "Thành công!",
						JOptionPane.INFORMATION_MESSAGE);
				loadAllData();
			} else {
				JOptionPane.showMessageDialog(frame, "Thêm không thành công, Lỗi!", "Chú Ý!",
						JOptionPane.ERROR_MESSAGE);
			}
		} catch (IOException ex) {
			ex.printStackTrace();
			Logger.getLogger(QuanLySV.class.getName()).log(Level.SEVERE, null, ex);
		}

	}

	public void DeleteByID() {
		int id = Integer.parseInt(textFieldID.getText());
		GiangVien gv = new GiangVien(id);

		try {
			PrintWriter writer = new PrintWriter(this.socket.getOutputStream());

			writer.println("DELETEGV");
			writer.flush();

			try {
				Thread.sleep(10);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			ObjectOutputStream ooutput = new ObjectOutputStream(this.socket.getOutputStream());
			ooutput.writeObject(gv);
			ooutput.flush();

			BufferedReader reader = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
			String message = reader.readLine();

			if (message != null) {
				JOptionPane.showMessageDialog(frame, "Xóa thành công", "Thành công!", JOptionPane.INFORMATION_MESSAGE);
				try {
					Thread.sleep(10);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				loadAllData();
			}

		} catch (IOException ex) {
			ex.printStackTrace();
		}

		Clear();

	}

	public void Edit() {

		String GVName = textFieldName.getText();
		String Email = textFieldEmail.getText();
		String PhoneNB = textFieldPhoneNumber.getText();

		if (GVName.equals("") || Email.equals("") || PhoneNB.equals("")) {
			JOptionPane.showMessageDialog(frame, "Vui lòng nhập đầy đủ thông tin!", "Chú Ý!",
					JOptionPane.ERROR_MESSAGE);
			return;
		}

		GiangVien gv = new GiangVien(Integer.parseInt(textFieldID.getText()), GVName, Email, PhoneNB);

		try {
			PrintWriter writer = new PrintWriter(this.socket.getOutputStream());
			for (int i = 0; i < 1; i++) {
				writer.println("EDITGV");
				writer.flush();
				try {
					Thread.sleep(10);
				} catch (InterruptedException ex) {
					Logger.getLogger(QuanLySV.class.getName()).log(Level.SEVERE, null, ex);
				}
			}

			ObjectOutputStream ooutput = new ObjectOutputStream(this.socket.getOutputStream());
			ooutput.writeObject(gv);
			ooutput.flush();

			BufferedReader reader = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
			String message = reader.readLine();

			System.out.println(message);

			if (message != null) {
				JOptionPane.showMessageDialog(frame, "Sửa giảng viên thành công", "Thành công!",
						JOptionPane.INFORMATION_MESSAGE);
				loadAllData();
			} else {
				JOptionPane.showMessageDialog(frame, "Sửa không thành công, Lỗi!", "Chú Ý!", JOptionPane.ERROR_MESSAGE);
			}
		} catch (IOException ex) {
			ex.printStackTrace();
			Logger.getLogger(QuanLySV.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

	public void SearchByName() {

		if (this.textFieldSearch.getText().equals("")) {
			JOptionPane.showMessageDialog(frame, "Vui lòng nhập ten môn học cần tìm kiếm! ", "Chú Ý!",
					JOptionPane.ERROR_MESSAGE);
		} else {

			try {
				PrintWriter writer = new PrintWriter(this.socket.getOutputStream());

				writer.println("SEARCHGVBYNAME");
				writer.flush();

				String name = textFieldSearch.getText();
				writer.println(name);
				writer.flush();

				List<GiangVien> list = new ArrayList<GiangVien>();

				ObjectInputStream oinput = new ObjectInputStream(this.socket.getInputStream());
				try {
					list = (List<GiangVien>) oinput.readObject();
				} catch (ClassNotFoundException ex) {
					ex.printStackTrace();
				}
				if (list.size() > 0) {

					tbmodel.setRowCount(0);
					for (GiangVien giangvien : list) {
						tbmodel.addRow(new Object[] { giangvien.getMaGiangVien(), giangvien.getTenGiangVien(),
								giangvien.getEmail(), giangvien.getSoDienThoai() });
					}
				} else {

					tbmodel.setRowCount(0);
					JOptionPane.showMessageDialog(frame, "Không có kết quả! ", "Chú Ý!", JOptionPane.PLAIN_MESSAGE);

				}

			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}

	}

	public void Clear() {
		this.textFieldID.setText("");
		this.textFieldName.setText("");
		this.textFieldEmail.setText("");
		this.textFieldPhoneNumber.setText("");

		BtnDelete.setEnabled(false);
		BtnEdit.setEnabled(false);
		BtnAdd.setEnabled(true);

	}

	public void fillData() {
		int row = table.getSelectedRow();
		if (row >= 0) {
			textFieldID.setText(table.getModel().getValueAt(row, 0).toString());
			textFieldName.setText(table.getModel().getValueAt(row, 1).toString());
			textFieldEmail.setText(table.getModel().getValueAt(row, 2).toString());
			textFieldPhoneNumber.setText(table.getModel().getValueAt(row, 3).toString());
		}
	}

	@Override
	public void run() {
		loadAllData();
	}

	@Override
	public void valueChanged(ListSelectionEvent e) {
		fillData();
		BtnAdd.setEnabled(false);
		BtnDelete.setEnabled(true);
		BtnEdit.setEnabled(true);

	}

}
