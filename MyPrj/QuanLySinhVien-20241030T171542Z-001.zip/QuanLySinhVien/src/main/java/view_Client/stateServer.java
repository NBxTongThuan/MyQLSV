/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view_Client;

import java.io.IOException;
import java.net.Socket;
import java.net.SocketException;

/**
 *
 * @author Tong Thuan
 */
public class stateServer {

	public static boolean isServerSocketRunning(String host, int port) {
		try {

			Socket socket = new Socket(host, port);

			socket.close();

			return true;

		} catch (SocketException e) {

			System.out.println("Server da tat");
			return false;
		} catch (IOException e) {

			e.printStackTrace();
			return false;
		}
	}
}
