package view_Client;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import java.awt.BorderLayout;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import model.SinhVien;
import model.User;

import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JPasswordField;

public class QuanLyTaiKhoan extends Thread implements ActionListener, ListSelectionListener {

	private JFrame frmQunLTi;
	private JTextField textField;
	private JTextField textFieldUserName;
	private Socket socketDN;
	private Socket mySocket;
	private DefaultTableModel tbmodel;
	private int timeLoadData = 0;
	private JTable table;
	private JButton BtnEdit, BtnDelete, BtnClearData, BtnReload, btnNewButton;
	private JMenuItem BtnmnExportExcel, BtnmnLogout, BtnmnExit;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	/**
	 * Create the application.
	 */
	public QuanLyTaiKhoan(Socket socketDN, Socket socket) {
		this.socketDN = socketDN;
		this.mySocket = socket;

		this.tbmodel = new DefaultTableModel();
		initialize();
		this.start();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedLookAndFeelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		frmQunLTi = new JFrame();
		frmQunLTi.setTitle("Quản lý tài khoản");
		frmQunLTi.setBounds(100, 100, 774, 330);
		frmQunLTi.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmQunLTi.getContentPane().setLayout(null);

		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		panel.setBounds(323, 63, 430, 223);
		frmQunLTi.getContentPane().add(panel);
		panel.setLayout(new BorderLayout(0, 0));

		JLabel lblNewLabel = new JLabel("Danh sách tài khoản");
		lblNewLabel.setBounds(323, 43, 126, 13);
		frmQunLTi.getContentPane().add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("Xin chào admin");
		lblNewLabel_1.setBounds(10, 10, 83, 13);
		frmQunLTi.getContentPane().add(lblNewLabel_1);

		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(255, 245, 238));
		panel_1.setBounds(10, 43, 310, 243);
		frmQunLTi.getContentPane().add(panel_1);
		panel_1.setLayout(null);

		JLabel lblNewLabel_2 = new JLabel("Tìm kiếm");
		lblNewLabel_2.setBounds(10, 10, 56, 13);
		panel_1.add(lblNewLabel_2);

		textField = new JTextField();
		textField.setBounds(10, 49, 197, 19);
		panel_1.add(textField);
		textField.setColumns(10);

		btnNewButton = new JButton("Tìm kiếm");

		btnNewButton.addActionListener(this);

		btnNewButton.setBounds(212, 48, 85, 21);
		panel_1.add(btnNewButton);

		JLabel lblNewLabel_3 = new JLabel("Nhập vào tài khoản bạn cần tìm kiếm");
		lblNewLabel_3.setBounds(10, 26, 220, 15);
		panel_1.add(lblNewLabel_3);

		JPanel panel_2 = new JPanel();
		panel_2.setBounds(10, 102, 290, 131);
		panel_1.add(panel_2);
		panel_2.setLayout(null);

		JLabel lblNewLabel_6 = new JLabel("Tài khoản");
		lblNewLabel_6.setBounds(10, 39, 45, 13);
		panel_2.add(lblNewLabel_6);

		JLabel lblNewLabel_5 = new JLabel("Action");
		lblNewLabel_5.setBounds(10, 10, 45, 13);
		panel_2.add(lblNewLabel_5);

		textFieldUserName = new JTextField();
		textFieldUserName.setEditable(false);
		textFieldUserName.setBounds(65, 36, 187, 19);
		panel_2.add(textFieldUserName);
		textFieldUserName.setColumns(10);

		JLabel lblNewLabel_7 = new JLabel("Mật khẩu");
		lblNewLabel_7.setBounds(10, 65, 53, 13);
		panel_2.add(lblNewLabel_7);

		BtnEdit = new JButton("Edit");
		BtnEdit.addActionListener(this);
		BtnEdit.setBounds(10, 96, 85, 21);
		panel_2.add(BtnEdit);

		BtnDelete = new JButton("Delete");
		BtnDelete.addActionListener(this);
		BtnDelete.setBounds(105, 96, 85, 21);
		panel_2.add(BtnDelete);

		BtnClearData = new JButton("Clear");
		BtnClearData.addActionListener(this);
		BtnClearData.setBounds(195, 96, 85, 21);
		panel_2.add(BtnClearData);

		passwordField = new JPasswordField();
		passwordField.setText("");
		passwordField.setBounds(65, 65, 187, 19);
		panel_2.add(passwordField);

		JLabel lblNewLabel_4 = new JLabel("QUẢN LÝ TÀI KHOẢN");
		lblNewLabel_4.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblNewLabel_4.setBounds(438, 3, 201, 30);
		frmQunLTi.getContentPane().add(lblNewLabel_4);

		panel.setLayout(new BorderLayout());

		tbmodel.addColumn("Tài khoản");
		tbmodel.addColumn("Mật khẩu");

		table = new JTable(tbmodel);
		table.getSelectionModel().addListSelectionListener(this);

		JScrollPane scrollPane = new JScrollPane(table);

		panel.add(scrollPane, BorderLayout.CENTER);

		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(320, 0, 45, 22);
		frmQunLTi.getContentPane().add(menuBar);

		JMenu mnNewMenu = new JMenu("Menu");
		menuBar.add(mnNewMenu);

		BtnmnExportExcel = new JMenuItem("Export Excel");
		BtnmnExportExcel.addActionListener(this);
		mnNewMenu.add(BtnmnExportExcel);

		BtnmnLogout = new JMenuItem("Logout");
		BtnmnLogout.addActionListener(this);
		mnNewMenu.add(BtnmnLogout);

		BtnmnExit = new JMenuItem("Exit");
		BtnmnExit.addActionListener(this);
		mnNewMenu.add(BtnmnExit);

		BtnReload = new JButton("Reload");
		BtnReload.addActionListener(this);
		BtnReload.setBounds(668, 39, 85, 21);
		frmQunLTi.getContentPane().add(BtnReload);
		BtnDelete.setEnabled(false);
		BtnEdit.setEnabled(false);

		frmQunLTi.setVisible(true);

	}

	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource() == BtnReload) {
			loadAllData();
		} else if (e.getSource() == BtnmnExportExcel) {
			exportToExcel();
		} else if (e.getSource() == BtnmnLogout) {
			Logout();
		} else if (e.getSource() == BtnmnExit) {
			Exit();
		} else if (e.getSource() == btnNewButton) {
			SearchByID();
		} else if (e.getSource() == BtnEdit) {
			Edit();
		} else if (e.getSource() == BtnDelete) {
			Delete();
		} else if (e.getSource() == BtnClearData) {
			ClearData();
		}

	}

	public void loadAllData() {
		try {

			PrintWriter writer = new PrintWriter(this.mySocket.getOutputStream());
			writer.println("SEARCHALL");
			writer.flush();

			timeLoadData = 1;

			ObjectInputStream oinput = new ObjectInputStream(this.mySocket.getInputStream());
			List<User> list = new ArrayList<User>();
			list = (List<User>) oinput.readObject();
			if (list.size() > 0) {
				tbmodel.setRowCount(0);
				for (User user : list) {
					tbmodel.addRow(new Object[] { user.getEmail(), user.getPassWord() });
				}
			}
		} catch (Exception e) {
		}
	}

	public void fillSelectedRow() {
		// lấy chỉ số của hàng được chọn
		int row = table.getSelectedRow();
		if (row >= 0) {
			textFieldUserName.setText(table.getModel().getValueAt(row, 0).toString());
		}
	}

	public void Edit() {
		if (textFieldUserName.getText().equals("") || passwordField.getPassword().length <= 0) {
			JOptionPane.showMessageDialog(this.frmQunLTi, "Vui lòng nhập đầy đủ thông tin tài khoản và mật khẩu!",
					"Error", JOptionPane.ERROR_MESSAGE);
			return;
		}

		String email = textFieldUserName.getText();

		String emailregex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:gmail)\\.(?:com)$";

		if (email.matches(emailregex) == false) {
			JOptionPane.showMessageDialog(this.frmQunLTi, "Email không hợp lệ!", "Error", JOptionPane.ERROR_MESSAGE);
			return;
		}

		String passregex = "^(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*()-+])[a-zA-Z0-9!@#$%^&*()-+]{8,16}$";

		String pass = new String(passwordField.getPassword());

		if (pass.matches(passregex) == false) {
			JOptionPane.showMessageDialog(frmQunLTi,
					"Mật khẩu phải có từ 8 - 16 ký tự, bao gồm ít nhất 1 chữ số, 1 chữ cái in hoa và 1 ký tự đặc biệt",
					"Chú Ý!", JOptionPane.ERROR_MESSAGE);
			return;
		}

		User us = new User(email, pass);

		try {
			PrintWriter writer = new PrintWriter(this.mySocket.getOutputStream());
			for (int i = 0; i < 1; i++) {
				writer.println("EDIT");
				writer.flush();
				try {
					Thread.sleep(10);
				} catch (InterruptedException ex) {
					Logger.getLogger(QuanLySV.class.getName()).log(Level.SEVERE, null, ex);
				}
			}

			ObjectOutputStream ooutput = new ObjectOutputStream(this.mySocket.getOutputStream());
			ooutput.writeObject(us);
			ooutput.flush();

			BufferedReader reader = new BufferedReader(new InputStreamReader(this.mySocket.getInputStream()));
			String message = reader.readLine();
			if (message.compareTo("EDITSUCCESS") == 65464) {
				JOptionPane.showMessageDialog(frmQunLTi, "Cập nhật thành công", "Thành công!",
						JOptionPane.INFORMATION_MESSAGE);
				loadAllData();
			}

		} catch (IOException ex) {
			ex.printStackTrace();
			Logger.getLogger(QuanLySV.class.getName()).log(Level.SEVERE, null, ex);
		}

		BtnEdit.setEnabled(false);
		BtnDelete.setEnabled(false);
	}

	public void valueChanged(ListSelectionEvent e) {
		fillSelectedRow();
		BtnDelete.setEnabled(true);
		BtnEdit.setEnabled(true);

	}

	private void exportToExcel() {
		try {
			Workbook workbook = new XSSFWorkbook();
			Sheet sheet = workbook.createSheet("Data");

			// Lấy số lượng hàng và cột từ bảng
			int rowCount = table.getRowCount();
			int columnCount = table.getColumnCount();

			// Tiêu đề cột
			Row headerRow = sheet.createRow(0);
			for (int col = 0; col < columnCount; col++) {
				Cell cell = headerRow.createCell(col);
				cell.setCellValue(table.getColumnName(col));
			}

			// Dữ liệu từ bảng
			for (int row = 0; row < rowCount; row++) {
				Row sheetRow = sheet.createRow(row + 1);
				for (int col = 0; col < columnCount; col++) {
					Object value = table.getValueAt(row, col);
					Cell cell = sheetRow.createCell(col);
					if (value != null) {
						if (value instanceof String) {
							cell.setCellValue((String) value);
						} else if (value instanceof Integer) {
							cell.setCellValue((Integer) value);
						} else if (value instanceof Double) {
							cell.setCellValue((Double) value);
						}
					}
				}
			}

			String desktopPath = System.getProperty("user.home") + "/Desktop/";
			String excelFilePath = desktopPath + "DataTaiKhoan.xlsx";

			// Ghi workbook vào OutputStream (Excel file)

			try {
				FileOutputStream outputStream = new FileOutputStream(excelFilePath);
				workbook.write(outputStream);
			} catch (Exception e) {
				// TODO: handle exception
			}

			JOptionPane.showMessageDialog(frmQunLTi, "Xuất file excel thành công!", "Success",
					JOptionPane.INFORMATION_MESSAGE);
			workbook.close();

		} catch (Exception e) {
			JOptionPane.showMessageDialog(this.frmQunLTi, "Lỗi : " + e.getMessage(), "Error",
					JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
	}

	public void Exit() {
		System.exit(0);
	}

	public void ClearData() {
		textFieldUserName.setText("");
		passwordField.setText("");
		BtnDelete.setEnabled(false);
		BtnEdit.setEnabled(false);

	}

	public void SearchByID() {
		int result = 0;

		if (this.textField.getText().equals("")) {
			JOptionPane.showMessageDialog(frmQunLTi, "Vui lòng nhập mã sinh viên cần tìm kiếm! ", "Chú Ý!",
					JOptionPane.ERROR_MESSAGE);
		} else {

			try {
				PrintWriter writer = new PrintWriter(this.mySocket.getOutputStream());

				writer.println("SEARCHBYID");
				writer.flush();

				String ID = textField.getText();
				writer.println(ID);
				writer.flush();

				List<User> list = new ArrayList<User>();

				ObjectInputStream oinput = new ObjectInputStream(this.mySocket.getInputStream());
				try {
					list = (List<User>) oinput.readObject();
				} catch (ClassNotFoundException ex) {
					ex.printStackTrace();
				}
				if (list.size() > 0) {

					tbmodel.setRowCount(0);
					for (User user : list) {
						tbmodel.addRow(new Object[] { user.getEmail(), user.getPassWord() });
					}
				} else {

					tbmodel.setRowCount(0);
					JOptionPane.showMessageDialog(frmQunLTi, "Không có kêt quả! ", "Chú Ý!", JOptionPane.PLAIN_MESSAGE);

				}

			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}

	}

	public void Delete() {
		String id = textFieldUserName.getText();

		String emailregex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:gmail)\\.(?:com)$";

		if (id.equals("")) {
			JOptionPane.showMessageDialog(this.frmQunLTi, "Email không được để trống", "Error",
					JOptionPane.ERROR_MESSAGE);
			return;
		}

		if (id.matches(emailregex) == false)

		{
			JOptionPane.showMessageDialog(this.frmQunLTi, "Email không hợp lệ", "Error", JOptionPane.ERROR_MESSAGE);
			return;
		}

		User us = new User(id);

		try {
			PrintWriter writer = new PrintWriter(this.mySocket.getOutputStream());
			writer.println("DELETE");
			writer.flush();

			try {
				Thread.sleep(10);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			ObjectOutputStream ooutput = new ObjectOutputStream(this.mySocket.getOutputStream());
			ooutput.writeObject(us);
			ooutput.flush();

			BufferedReader reader = new BufferedReader(new InputStreamReader(this.mySocket.getInputStream()));
			String message = reader.readLine();

			if (message != null) {
				System.out.println(message.compareTo("DELETESUCCESS"));
				JOptionPane.showMessageDialog(frmQunLTi, "Xóa thành công", "Thành công!",
						JOptionPane.INFORMATION_MESSAGE);
				try {
					Thread.sleep(10);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				loadAllData();
			}

		} catch (IOException ex) {
			ex.printStackTrace();
		}

		ClearData();
	}

	public void Logout() {
		PrintWriter writer;
		try {
			writer = new PrintWriter(this.mySocket.getOutputStream());
			writer.println("DANGXUAT");
			writer.flush();
		} catch (IOException ex) {
			Logger.getLogger(QuanLySV.class.getName()).log(Level.SEVERE, null, ex);
		}

		try {
			this.mySocket.close();
			if (this.mySocket.isClosed() == true) {
				System.out.println("dong socket quan ly tai khoan");
			}
			this.socketDN.close();
		} catch (IOException ex) {
			Logger.getLogger(QuanLySV.class.getName()).log(Level.SEVERE, null, ex);
		}
		frmQunLTi.dispose();
		new Admin();
	}


	@Override
	public void run() {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException ex) {

		}

		loadAllData();
	}
}
