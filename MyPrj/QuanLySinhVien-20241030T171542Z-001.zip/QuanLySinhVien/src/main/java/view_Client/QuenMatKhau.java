package view_Client;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Properties;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JTextField;
import javax.swing.Timer;
import javax.swing.UIManager;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.JButton;
import javax.swing.JPanel;
import java.awt.Color;

public class QuenMatKhau extends Thread implements ActionListener {

	private JFrame frame;
	private JTextField textField;
	private Socket mysocket;
	private JFrame frame_;
	private String URL;
	private int PORT;
	private PrintWriter writer;
	private BufferedReader reader;
	private JTextField textField_1;
	private String OTP;
	private Timer timer;
	private JButton btnNewButton_2;

	/**
	 * Launch the application.
	 */

	/**
	 * Create the application.
	 * 
	 * @wbp.parser.entryPoint
	 */

	public QuenMatKhau(JFrame frame, String url, int PORT) {
		this.frame_ = frame;
		this.URL = url;
		this.PORT = PORT;
		initialize();
		this.start();

	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {

		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(220, 220, 220));
		frame.setBounds(100, 100, 536, 356);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("Quên mật khẩu");
		frame.setLocationRelativeTo(null);
		frame.getContentPane().setLayout(null);

		JPanel panel = new JPanel();
		panel.setBackground(new Color(240, 255, 255));
		panel.setBounds(57, 21, 399, 274);
		frame.getContentPane().add(panel);
		panel.setLayout(null);

		JLabel lblNewLabel_1 = new JLabel("Mã xác nhận");
		lblNewLabel_1.setBounds(36, 132, 86, 19);
		panel.add(lblNewLabel_1);
		lblNewLabel_1.setFont(new Font("Arial", Font.PLAIN, 15));

		JLabel lblNewLabel = new JLabel("Tài khoản");
		lblNewLabel.setBounds(36, 93, 86, 13);
		panel.add(lblNewLabel);
		lblNewLabel.setFont(new Font("Arial", Font.PLAIN, 15));

		textField = new JTextField();
		textField.setBounds(131, 91, 188, 19);
		panel.add(textField);
		textField.setColumns(10);

		textField_1 = new JTextField();
		textField_1.setBounds(131, 131, 100, 19);
		panel.add(textField_1);
		textField_1.setColumns(10);

		btnNewButton_2 = new JButton("Gửi mã");
		btnNewButton_2.setBounds(234, 130, 85, 21);
		panel.add(btnNewButton_2);

		JButton btnNewButton = new JButton("Gửi mật khẩu mới");
		btnNewButton.setBounds(115, 179, 141, 21);
		panel.add(btnNewButton);

		JButton btnNewButton_1 = new JButton("Trở về");
		btnNewButton_1.setBounds(290, 226, 85, 21);
		panel.add(btnNewButton_1);

		JLabel lblNewLabel_2 = new JLabel("QUÊN MẬT KHẨU");
		lblNewLabel_2.setBounds(90, 21, 245, 42);
		panel.add(lblNewLabel_2);
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 30));
		btnNewButton_1.addActionListener(this);
		btnNewButton.addActionListener(this);
		btnNewButton_2.addActionListener(this);

		frame.setVisible(true);
	}

	public void actionPerformed(ActionEvent e) {
		String src = e.getActionCommand();
		timer = new Timer(60000, new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OTP = null;
				btnNewButton_2.setEnabled(true); // Kích hoạt nút bấm sau khi hết thời gian
				((Timer) e.getSource()).stop(); // Dừng đếm ngược
			}
		});

		String emailregex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:gmail)\\.(?:com)$";
		String email = textField.getText();
		if (src.equals("Gửi mật khẩu mới")) {

			sendNewPass();

		} else if (src.equals("Gửi mã")) {

			if (textField.getText().matches(emailregex) == false) {
				JOptionPane.showMessageDialog(this.frame, "Email không hợp lệ!", "Chú Ý!", JOptionPane.ERROR_MESSAGE);
			} else {

				OTP = null;
				btnNewButton_2.setEnabled(false);
				RanOTP();
				SendOTP();
				timer.restart();
			}

		} else if (src.equals("Trở về")) {
			Back();
		}

	}

	public void sendNewPass() {
		String emailregex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:gmail)\\.(?:com)$";
		String email = textField.getText();

		if (email.matches(emailregex) == false) {
			JOptionPane.showMessageDialog(this.frame, "Email không hợp lệ!", "Chú Ý!", JOptionPane.ERROR_MESSAGE);
		} else if (textField_1.getText().equals("") == true) {

			JOptionPane.showMessageDialog(this.frame, "Vui lòng nhập mã xác nhận được gửi tới Email!", "Chú Ý!",
					JOptionPane.ERROR_MESSAGE);
		} else if (!textField_1.getText().equals(OTP)) {
			JOptionPane.showMessageDialog(this.frame, "Mã xác nhận không đúng!", "Chú Ý!", JOptionPane.ERROR_MESSAGE);
		} else {

			if (this.mysocket != null) {
				try {

					this.writer.println(email);
					writer.flush();

					QuenMatKhauStatement state = new QuenMatKhauStatement(mysocket, frame);
					state.start();
				} catch (Exception e1) {
					JOptionPane.showMessageDialog(frame, "Không thể kết nối tới máy chủ, vui lòng thoát chương trình!",
							"Chú Ý!", JOptionPane.ERROR_MESSAGE);
				}
			}

		}

	}

	public String RanOTP() {
		OTP = "";
		Random random = new Random();
		for (int i = 0; i < 6; i++) {
			int value = random.nextInt(10);
			OTP += value;
		}
		return OTP;

	}

	public void Back() {
		

		if (this.mysocket != null) {
			this.writer.println("OUT");
			writer.flush();
			try {
				this.mysocket.close();
			} catch (IOException ex) {
				Logger.getLogger(DangKy.class.getName()).log(Level.SEVERE, null, ex);
			}
		}

		frame.dispose();
		this.frame_.setVisible(true);

	}

	public void SendOTP() {
		final String from = "tongthuan15092003@gmail.com";
		final String passWord = "vplymroxjzluvxpx";
		// Thuộc tính
		Properties props = new Properties();
		props.put("mail.smtp.host", "smtp.gmail.com");// SMTP HOST
		props.put("mail.smtp.port", "587");// TSL 587, SSL 465
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.ssl.protocols", "TLSv1.2");

		// Create Authenticator
		Authenticator auth = new Authenticator() {
			@Override
			protected PasswordAuthentication getPasswordAuthentication() {
				// TODO Auto-generated method stub
				return new PasswordAuthentication(from, passWord);
			}

		};

		// phiên làm việc
		Session session = Session.getInstance(props, auth);

		// Gửi email
		final String to = textField.getText();

		// Tạo một tin nhắn
		MimeMessage msg = new MimeMessage(session);
		try {
			msg.addHeader("Content-type", "text/HTML; charset=UTF-8");
			msg.setFrom();
			msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to, false));

			// Tiêu đề
			msg.setSubject("Quản Lý Sinh Viên");

			// Nội dung email
			msg.setText(
					"Mã xác nhận quên mật khẩu quản lý sinh viên là : " + OTP + " mã này chỉ có hiệu lực trong 60 giây",
					"UTF-8");

			Transport.send(msg);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void run() {

		try {
			this.mysocket = new Socket(URL, PORT);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(frame, "Không thể kết nối tới máy chủ, vui lòng thoát chương trình!",
					"Chú Ý!", JOptionPane.ERROR_MESSAGE);
			
			return;
		}
		try {
			writer = new PrintWriter(this.mysocket.getOutputStream());
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		try {
			reader = new BufferedReader(new InputStreamReader(this.mysocket.getInputStream()));
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		if (this.mysocket != null) {
			writer.println("QUENMATKHAU");
			writer.flush();
		}
	}

}
