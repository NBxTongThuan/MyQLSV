package view_Client;

public class CheckDate {

    public static boolean checkDate(int day, int month, int year) {
        boolean result = false;
        if (year < 1900 || month < 1 || day < 1) {
            result = false;
        } else if (year % 4 == 0) {
            if (month == 2 && day > 29) {
                result = false;
            } else if ((month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) && day > 31) {
                result = false;
            } else if ((month == 4 || month == 6 || month == 9 || month == 11) && day > 30) {
                result = false;
            } else {
                result = true;
            }

        } else{
            if (month == 2 && day > 28) {
                result = false;
            } else if ((month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) && day > 31) {
                result = false;
            } else if ((month == 4 || month == 6 || month == 9 || month == 11) && day > 30) {
                result = false;
            } else {
                result = true;
            }
        }

        return result;

    }

}
