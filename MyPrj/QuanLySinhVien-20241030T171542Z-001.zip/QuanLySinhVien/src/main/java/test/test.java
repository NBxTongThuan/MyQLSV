package test;

import java.sql.Date;
import java.util.List;

import org.hibernate.SessionFactory;

import dao.sinhVienDAO;
import dao.userDAO;
import model.SinhVien;
import model.User;
import util.HibernateUtil;

public class test {
public static void main(String[] args) {
	
userDAO userdao = new userDAO();

User user = new User("tongthuan15092003@gmail.com", "123123");

userdao.Login(user);

//SinhVien sv = new SinhVien("Nguyen Van A","Phu Tho",new Date(1999-1900,12-1,31), 9);
//sinhVienDAO svDao= new sinhVienDAO();
//    System.out.println(svDao.intsert(sv));
}
}
