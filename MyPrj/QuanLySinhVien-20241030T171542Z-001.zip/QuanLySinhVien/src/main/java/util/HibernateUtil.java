package util;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateUtil {

    public static final SessionFactory sessionFactory = builSessionFactory();

    private static SessionFactory builSessionFactory() {
        // TODO Auto-generated method stub
        try {

            return new Configuration().configure().buildSessionFactory();
        } catch (Exception e) {
            // TODO: handle exception
            return null;
        }

    }

    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public static void shutDown() {
        getSessionFactory().close();
    }

}
