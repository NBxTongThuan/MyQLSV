package model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "giang_vien")
public class GiangVien implements Serializable {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int maGiangVien;
	private String tenGiangVien;
	private String email;
	private String soDienThoai;



	public GiangVien() {

	}

	public GiangVien(int maGiangVien) {

		this.maGiangVien = maGiangVien;
	}

	public GiangVien(int maGiangVien, String tenGiangVien, String email, String soDienThoai) {

		this.maGiangVien = maGiangVien;
		this.tenGiangVien = tenGiangVien;
		this.email = email;
		this.soDienThoai = soDienThoai;
	}

	// Constructor
	public GiangVien(String tenGiangVien, String email, String soDienThoai) {
		this.tenGiangVien = tenGiangVien;
		this.email = email;
		this.soDienThoai = soDienThoai;
	}

	// Getters and Setters
	public String getTenGiangVien() {
		return tenGiangVien;
	}

	public void setTenGiangVien(String tenGiangVien) {
		this.tenGiangVien = tenGiangVien;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getSoDienThoai() {
		return soDienThoai;
	}

	public void setSoDienThoai(String soDienThoai) {
		this.soDienThoai = soDienThoai;
	}

	public int getMaGiangVien() {
		return maGiangVien;
	}

	public void setMaGiangVien(int maGiangVien) {
		this.maGiangVien = maGiangVien;
	}

	
	@Override
	public String toString() {
		return "GiangVien{" + "tenGiangVien='" + tenGiangVien + '\'' + ", email='" + email + '\'' + ", soDienThoai='"
				+ soDienThoai + '\'';
	}

}
