package model;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class SinhVien implements Serializable {

	/**
	 *
	 */

	@Id
	@GeneratedValue
	@Column(name = "Student_ID")
	private int Student_ID;

	@Column(name = "Student_Name")
	private String Student_Name;

	@Column(name = "Student_DateOfBirth")
	private LocalDate Student_DateOfBirth;

	@Column(name = "Student_Gender")
	private String Student_Gender;

	@Column(name = "Student_Address")
	private String Student_Address;

	@Column(name = "Student_Major")
	private String Student_Major;

	@Column(name = "Student_DayAdmission")
	private LocalDate Student_DayAdmission;

	@Column(name = "email")
	private String email;

	@Column(name = "Student_PhoneNumber")
	private String Student_PhoneNumber;

	@Column(name = "Student_NumberOfCredits")
	private int Student_NumberOfCredits;

	@Column(name = "Student_CumulativeNumberOfCredits")
	private int Student_CumulativeNumberOfCredits;

	@Column(name = "GPA")
	private double GPA;

	public SinhVien() {

	}

	public SinhVien(int student_ID) {
		Student_ID = student_ID;
	}

	public SinhVien(String student_Name, LocalDate student_DateOfBirth, String student_Gender, String student_Address,
			String student_Major, LocalDate student_DayAdmission, String email, String student_PhoneNumber,
			int student_NumberOfCredits, int student_CumulativeNumberOfCredits, double gPA) {

		Student_Name = student_Name;
		Student_DateOfBirth = student_DateOfBirth;
		Student_Gender = student_Gender;
		Student_Address = student_Address;
		Student_Major = student_Major;
		Student_DayAdmission = student_DayAdmission;
		this.email = email;
		Student_PhoneNumber = student_PhoneNumber;
		Student_NumberOfCredits = student_NumberOfCredits;
		Student_CumulativeNumberOfCredits = student_CumulativeNumberOfCredits;
		GPA = gPA;
	}

	public SinhVien(int student_ID, String student_Name, LocalDate student_DateOfBirth, String student_Gender,
			String student_Address, String student_Major, LocalDate student_DayAdmission, String email,
			String student_PhoneNumber, int student_NumberOfCredits, int student_CumulativeNumberOfCredits,
			double gPA) {

		Student_ID = student_ID;
		Student_Name = student_Name;
		Student_DateOfBirth = student_DateOfBirth;
		Student_Gender = student_Gender;
		Student_Address = student_Address;
		Student_Major = student_Major;
		Student_DayAdmission = student_DayAdmission;
		this.email = email;
		Student_PhoneNumber = student_PhoneNumber;
		Student_NumberOfCredits = student_NumberOfCredits;
		Student_CumulativeNumberOfCredits = student_CumulativeNumberOfCredits;
		GPA = gPA;
	}

	public int getStudent_ID() {
		return Student_ID;
	}

	public void setStudent_ID(int student_ID) {
		Student_ID = student_ID;
	}

	public String getStudent_Name() {
		return Student_Name;
	}

	public void setStudent_Name(String student_Name) {
		Student_Name = student_Name;
	}

	public LocalDate getStudent_DateOfBirth() {
		return Student_DateOfBirth;
	}

	public void setStudent_DateOfBirth(LocalDate student_DateOfBirth) {
		Student_DateOfBirth = student_DateOfBirth;
	}

	public String getStudent_Gender() {
		return Student_Gender;
	}

	public void setStudent_Sex(String student_Gender) {
		Student_Gender = student_Gender;
	}

	public String getStudent_Address() {
		return Student_Address;
	}

	public void setStudent_Address(String student_Address) {
		Student_Address = student_Address;
	}

	public String getStudent_Major() {
		return Student_Major;
	}

	public void setStudent_Major(String student_Major) {
		Student_Major = student_Major;
	}

	public LocalDate getStudent_DayAdmission() {
		return Student_DayAdmission;
	}

	public void setStudent_DayAdmission(LocalDate student_DayAdmission) {
		Student_DayAdmission = student_DayAdmission;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getStudent_PhoneNumber() {
		return Student_PhoneNumber;
	}

	public void setStudent_PhoneNumber(String student_PhoneNumber) {
		Student_PhoneNumber = student_PhoneNumber;
	}

	public int getStudent_NumberOfCredits() {
		return Student_NumberOfCredits;
	}

	public void setStudent_NumberOfCredits(int student_NumberOfCredits) {
		Student_NumberOfCredits = student_NumberOfCredits;
	}

	public int getStudent_CumulativeNumberOfCredits() {
		return Student_CumulativeNumberOfCredits;
	}

	public void setStudent_CumulativeNumberOfCredits(int student_CumulativeNumberOfCredits) {
		Student_CumulativeNumberOfCredits = student_CumulativeNumberOfCredits;
	}

	public double getGPA() {
		return GPA;
	}

	public void setGPA(double gPA) {
		GPA = gPA;
	}

	@Override
	public String toString() {
		return "SinhVien [Student_ID=" + Student_ID + ", Student_Name=" + Student_Name + ", Student_DateOfBirth="
				+ Student_DateOfBirth + ", Student_Sex=" + Student_Gender + ", Student_Address=" + Student_Address
				+ ", Student_Major=" + Student_Major + ", Student_DayAdmission=" + Student_DayAdmission + ", email="
				+ email + ", Student_PhoneNumber=" + Student_PhoneNumber + ", Student_NumberOfCredits="
				+ Student_NumberOfCredits + ", Student_CumulativeNumberOfCredits=" + Student_CumulativeNumberOfCredits
				+ ", GPA=" + GPA + "]";
	}

}
