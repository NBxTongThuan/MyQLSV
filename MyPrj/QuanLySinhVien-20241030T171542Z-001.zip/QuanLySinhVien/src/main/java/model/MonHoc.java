package model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "mon_hoc")
public class MonHoc implements Serializable {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	private String tenMonHoc;
	private String moTaMonHoc;
	private int soTinChi;

	private String giangVienPhuTrach;

	private String phuongPhapDanhGia;
	private int soLuongSinhVienToiDa;

	public MonHoc() {

	}

	public MonHoc(int id) {

		this.id = id;
	}

	// Constructor
	public MonHoc(String tenMonHoc, String moTaMonHoc, int soTinChi, String giangVienPhuTrach, String phuongPhapDanhGia,
			int soLuongSinhVienToiDa) {
		this.tenMonHoc = tenMonHoc;

		this.moTaMonHoc = moTaMonHoc;
		this.soTinChi = soTinChi;
		this.giangVienPhuTrach = giangVienPhuTrach;
		this.phuongPhapDanhGia = phuongPhapDanhGia;
		this.soLuongSinhVienToiDa = soLuongSinhVienToiDa;
	}

	public MonHoc(int id, String tenMonHoc, String moTaMonHoc, int soTinChi, String giangVienPhuTrach,
			String phuongPhapDanhGia, int soLuongSinhVienToiDa) {

		this.id = id;
		this.tenMonHoc = tenMonHoc;
		this.moTaMonHoc = moTaMonHoc;
		this.soTinChi = soTinChi;
		this.giangVienPhuTrach = giangVienPhuTrach;
		this.phuongPhapDanhGia = phuongPhapDanhGia;
		this.soLuongSinhVienToiDa = soLuongSinhVienToiDa;
	}

	// Getters and Setters
	public String getTenMonHoc() {
		return tenMonHoc;
	}

	public void setTenMonHoc(String tenMonHoc) {
		this.tenMonHoc = tenMonHoc;
	}

	public String getMoTaMonHoc() {
		return moTaMonHoc;
	}

	public void setMoTaMonHoc(String moTaMonHoc) {
		this.moTaMonHoc = moTaMonHoc;
	}

	public int getSoTinChi() {
		return soTinChi;
	}

	public void setSoTinChi(int soTinChi) {
		this.soTinChi = soTinChi;
	}

	public String getGiangVienPhuTrach() {
		return giangVienPhuTrach;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setGiangVienPhuTrach(String giangVienPhuTrach) {
		this.giangVienPhuTrach = giangVienPhuTrach;
	}

	public String getPhuongPhapDanhGia() {
		return phuongPhapDanhGia;
	}

	public void setPhuongPhapDanhGia(String phuongPhapDanhGia) {
		this.phuongPhapDanhGia = phuongPhapDanhGia;
	}

	public int getSoLuongSinhVienToiDa() {
		return soLuongSinhVienToiDa;
	}

	public void setSoLuongSinhVienToiDa(int soLuongSinhVienToiDa) {
		this.soLuongSinhVienToiDa = soLuongSinhVienToiDa;
	}

	@Override
	public String toString() {
		return "MonHoc [id=" + id + ", tenMonHoc=" + tenMonHoc + ", moTaMonHoc=" + moTaMonHoc + ", soTinChi=" + soTinChi
				+ ", giangVienPhuTrach=" + giangVienPhuTrach + ", phuongPhapDanhGia=" + phuongPhapDanhGia
				+ ", soLuongSinhVienToiDa=" + soLuongSinhVienToiDa + "]";
	}



}
