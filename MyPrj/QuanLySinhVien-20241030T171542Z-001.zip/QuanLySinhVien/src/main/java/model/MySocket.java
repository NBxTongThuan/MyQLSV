package model;

import java.net.Socket;

public class MySocket {

	private Socket socket;
	private String currentTime;

	public MySocket(Socket socket, String currentTime) {
		this.socket = socket;
		this.currentTime = currentTime;
	}

	public Socket getSocket() {
		return socket;
	}

	public void setSocket(Socket socket) {
		this.socket = socket;
	}

	public String getCurrentTime() {
		return currentTime;
	}

	public void setCurrentTime(String currentTime) {
		this.currentTime = currentTime;
	}

}
