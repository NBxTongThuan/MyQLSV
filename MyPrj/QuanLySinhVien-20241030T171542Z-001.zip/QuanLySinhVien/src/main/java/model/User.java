package model;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class User implements Serializable {
	@Id
	private String email;
	private String passWord;

	public User() {

	}

	public User(String email) {
		this.email = email;
	}

	public User(String email, String passWord) {

		this.email = email;
		this.passWord = passWord;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassWord() {
		return passWord;
	}

	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}

	@Override
	public String toString() {
		return "User [email=" + email + ", passWord=" + passWord + "]";
	}

}
